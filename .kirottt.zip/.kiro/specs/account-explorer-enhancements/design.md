# Account Explorer Enhancements Design

## Overview

The Account Explorer Enhancements design is built around high-performance virtual tables (vtables) for handling massive datasets efficiently. Every data display prioritizes vtable UX patterns with virtual scrolling, dynamic filtering, column management, and real-time updates.

## VTable-First Architecture

### Core VTable Principles

1. **Virtual Rendering**: Only render visible rows (typically 20-50 rows)
2. **Dynamic Heights**: Support variable row heights for rich content
3. **Column Virtualization**: Virtualize columns for wide tables
4. **Incremental Loading**: Load data in chunks as user scrolls
5. **Real-time Streaming**: Update rows without full re-render
6. **Memory Efficiency**: Recycle DOM elements for performance

### VTable Performance Targets

- **Initial Load**: < 100ms for first 50 rows
- **Scroll Performance**: 60fps smooth scrolling
- **Memory Usage**: < 50MB for 100k+ rows
- **Update Latency**: < 16ms for real-time updates
- **Search/Filter**: < 200ms for 1M+ rows

## Layout Design Scheme

### Account Detail Page Layout (`/account/[address]`)

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                            Account Explorer (VTable-First)                         │
│                                                                                     │
│  ┌─────────────────────────────────────────────────────────────────────────────────┐ │
│  │ 📍 0x1234...abcd • 💰 125.45 SOL ($12,545) • 📊 Portfolio: $45,230 • ⚡ Live   │ │
│  └─────────────────────────────────────────────────────────────────────────────────┘ │
│                                                                                     │
│  ┌─────────────────────────────────────────────────────────────────────────────────┐ │
│  │ 🔍 Global Search: [________________] | 📊 View: [Tokens▼] | ⚙️ Columns | 📤 Export│ │
│  └─────────────────────────────────────────────────────────────────────────────────┘ │
│                                                                                     │
│  ┌─────────────────────────────────────────────────────────────────────────────────┐ │
│  │                          Primary VTable Container                               │ │
│  │ ┌─────────────────────────────────────────────────────────────────────────────┐ │ │
│  │ │ 🔧 Token Holdings VTable Controls                                           │ │ │
│  │ │ 🏷️ [All Tokens▼] 💰 [$0-∞] ✅ [Verified] 📈 [Sort: Value▼] 📄 [50 rows▼]   │ │ │
│  │ │ 📌 Pin: [Top 5] 🔄 [Auto-refresh: 30s] 👁️ [Hide: Zero balances]            │ │ │
│  │ └─────────────────────────────────────────────────────────────────────────────┘ │ │
│  │                                                                                 │ │
│  │ ┌─────────────────────────────────────────────────────────────────────────────┐ │ │
│  │ │                        Virtual Token Table                                  │ │ │
│  │ │ ┌─┬─────────┬──────────┬───────────┬────────┬──────┬─────────┬──────────┐   │ │ │
│  │ │ │📌│Token ▲  │Balance   │USD Value▼│24h Δ   │%Port │Sparkline│Actions ⚡│   │ │ │
│  │ │ │ ├─────────┼──────────┼───────────┼────────┼──────┼─────────┼──────────┤   │ │ │
│  │ │ │📌│🟡 SOL   │125.45    │$12,545.00 │+2.8% 📈│45.2% │╱╲╱╲╱    │[•••]     │   │ │ │
│  │ │ │📌│🔵 USDC  │8,234.56  │$8,234.56  │+0.1% → │29.7% │──────   │[•••]     │   │ │ │
│  │ │ │📌│🟠 BONK  │1.2M      │$3,456.78  │-5.2% 📉│12.5% │╲╱╲╱╲    │[•••]     │   │ │ │
│  │ │ │ │🟢 RAY   │234.56    │$2,345.67  │+12.3%🚀│8.5%  │╱╱╱╱╱    │[•••]     │   │ │ │
│  │ │ │ │🔴 ORCA  │89.12     │$1,234.56  │+5.7% 📈│4.4%  │╱╲──╱    │[•••]     │   │ │ │
│  │ │ │ │⚪ MNDE  │456.78    │$987.65    │-2.1% 📉│3.5%  │╲╲╱╱╲    │[•••]     │   │ │ │
│  │ │ │ │🟣 JUP   │123.45    │$654.32    │+8.9% 📈│2.3%  │╱╱╲╱╱    │[•••]     │   │ │ │
│  │ │ │ │🟤 PYTH  │67.89     │$432.10    │+1.5% → │1.5%  │──╱╲─    │[•••]     │   │ │ │
│  │ │ │ │⚫ WIF   │234.56    │$321.09    │-7.3% 📉│1.1%  │╲╲╲╱╱    │[•••]     │   │ │ │
│  │ │ │ │🔵 USDT  │198.76    │$198.76    │0.0% →  │0.7%  │──────   │[•••]     │   │ │ │
│  │ │ │ │┊        │┊         │┊          │┊       │┊     │┊        │┊         │   │ │ │
│  │ │ │ │[Virtual scrolling viewport - only visible rows rendered]              │   │ │ │
│  │ │ │ │┊        │┊         │┊          │┊       │┊     │┊        │┊         │   │ │ │
│  │ │ └─┴─────────┴──────────┴───────────┴────────┴──────┴─────────┴──────────┘   │ │ │
│  │ │ 📊 Showing 10 of 1,247 tokens • 💰 Total: $45,230.50 • 📈 24h: +$1,234    │ │ │
│  │ │ 🔄 Updated: 2s ago • ⚡ Hover for actions • 📌 3 pinned • 🎯 Filtered: 247  │ │ │
│  │ └─────────────────────────────────────────────────────────────────────────────┘ │ │
│  └─────────────────────────────────────────────────────────────────────────────────┘ │
│                                                                                     │
│  ┌─────────────────────────────────────────────────────────────────────────────────┐ │
│  │                        VTable View Switcher                                    │ │
│  │ [💰 Tokens] [📊 Transactions] [🖼️ NFTs] [⚙️ Programs] [📈 Analytics] [🔗 Relations]│ │
│  └─────────────────────────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────────────────────┘
```

### Transaction History VTable Layout

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                        Transaction History VTable                                  │
│                                                                                     │
│  ┌─────────────────────────────────────────────────────────────────────────────────┐ │
│  │ 🔧 Transaction VTable Controls                                                  │ │
│  │ 🔍 [Search sigs/addresses] 📅 [Last 30d▼] 🏷️ [All types▼] 💰 [$0-∞] ✅ [Success]│ │
│  │ 📊 [Group by: Date▼] 🔄 [Auto-refresh] 📌 [Pin: Failed] 👁️ [Hide: Dust]        │ │
│  └─────────────────────────────────────────────────────────────────────────────────┘ │
│                                                                                     │
│  ┌─────────────────────────────────────────────────────────────────────────────────┐ │
│  │                      Virtual Transaction Table                                  │ │
│  │ ┌─┬──────────┬────────┬─────────┬──────────┬────────┬────────┬─────────┬──────┐ │ │
│  │ │📌│Signature │Type    │Amount   │From/To   │Time    │Status  │Fee      │Graph │ │ │
│  │ │ ├──────────┼────────┼─────────┼──────────┼────────┼────────┼─────────┼──────┤ │ │
│  │ │ │5Gx7...   │Transfer│+100 USDC│0x1234... │2h ago  │✅ Success│0.005 SOL│[📊] │ │ │
│  │ │ │8Kj2...   │Swap    │-5 SOL   │Jupiter   │4h ago  │✅ Success│0.012 SOL│[📊] │ │ │
│  │ │ │3Mn9...   │Transfer│-5 SOL   │0x5678... │1d ago  │✅ Success│0.005 SOL│[📊] │ │ │
│  │ │📌│7Qp4...   │Mint    │+1 NFT   │Magic Eden│2d ago  │❌ Failed │0.025 SOL│[📊] │ │ │
│  │ │ │2Rt8...   │Stake   │50 SOL   │Marinade  │3d ago  │✅ Success│0.008 SOL│[📊] │ │ │
│  │ │ │9Kl3...   │Unstake │25 SOL   │Marinade  │4d ago  │✅ Success│0.008 SOL│[📊] │ │ │
│  │ │ │4Nm7...   │Swap    │-100 USDC│Orca      │5d ago  │✅ Success│0.015 SOL│[📊] │ │ │
│  │ │ │6Pl1...   │Transfer│+0.1 SOL │0x9abc... │6d ago  │✅ Success│0.005 SOL│[📊] │ │ │
│  │ │ │1Qr5...   │Vote    │0 SOL    │Validator │7d ago  │✅ Success│0.002 SOL│[📊] │ │ │
│  │ │ │8Ws9...   │Burn    │-1000 BONK│Token Prog│8d ago  │✅ Success│0.005 SOL│[📊] │ │ │
│  │ │ │┊         │┊       │┊        │┊         │┊       │┊       │┊        │┊     │ │ │
│  │ │ │[Virtual scrolling - 50,000+ transactions available]                      │ │ │
│  │ │ │┊         │┊       │┊        │┊         │┊       │┊       │┊        │┊     │ │ │
│  │ └─┴──────────┴────────┴─────────┴──────────┴────────┴────────┴─────────┴──────┘ │ │
│  │ 📊 Showing 10 of 52,847 transactions • 💰 Volume: $2.3M • ✅ Success: 98.7%    │ │
│  │ 🔄 Live updates • 📌 1 pinned • 🎯 Filtered: 1,247 • ⚡ Hover for details      │ │
│  └─────────────────────────────────────────────────────────────────────────────────┘ │
│                                                                                     │
│  ┌─────────────────────────────────────────────────────────────────────────────────┐ │
│  │                        Transaction Analytics Bar                                │ │
│  │ 📈 Volume: $2.3M (↑12%) • 🔄 Count: 52,847 (↑8%) • ⚡ Avg Fee: 0.008 SOL      │ │
│  │ 📊 Success: 98.7% • 🎯 Most Active: Jupiter (23%) • 📅 Peak: 2-4 PM UTC        │ │
│  └─────────────────────────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────────────────────┘
```

### NFT Collection VTable Layout

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                           NFT Collection VTable                                    │
│                                                                                     │
│  ┌─────────────────────────────────────────────────────────────────────────────────┐ │
│  │ 🔧 NFT VTable Controls                                                          │ │
│  │ 🔍 [Search names/collections] 🏷️ [All collections▼] 💰 [Floor: $0-∞] 🎨 [Rarity▼]│ │
│  │ 📊 [View: Grid▼] 📌 [Pin: Rare] ✅ [Verified only] 🔄 [Auto-refresh prices]    │ │
│  └─────────────────────────────────────────────────────────────────────────────────┘ │
│                                                                                     │
│  ┌─────────────────────────────────────────────────────────────────────────────────┐ │
│  │                        Virtual NFT Grid Table                                  │ │
│  │ ┌─┬─────────┬──────────┬──────────┬────────┬────────┬─────────┬──────────────┐ │ │
│  │ │📌│Preview  │Name      │Collection│Rarity  │Floor   │Estimated│Last Activity │ │ │
│  │ │ ├─────────┼──────────┼──────────┼────────┼────────┼─────────┼──────────────┤ │ │
│  │ │📌│[IMG]    │Degen #123│Degen Apes│15% 🔥  │2.1 SOL │$234     │Listed 2h ago │ │ │
│  │ │📌│[IMG]    │BAYC #567 │Bored Apes│5% 💎   │45 SOL  │$4,500   │Sold 1d ago   │ │ │
│  │ │ │[IMG]    │Bear #890 │Okay Bears│25% 🟢  │1.8 SOL │$180     │Minted 3d ago │ │ │
│  │ │ │[IMG]    │SMB #234  │Sol Monkeys│10% 🟡  │3.2 SOL │$320     │Transfer 5d   │ │ │
│  │ │ │[IMG]    │Orca #456 │Orca NFTs │30% 🟢  │0.5 SOL │$50      │Minted 1w ago │ │ │
│  │ │ │[IMG]    │Taiyo #789│Taiyo Robot│8% 🟡   │2.8 SOL │$280     │Listed 2w ago │ │ │
│  │ │ │[IMG]    │Pepe #012 │Pepe Sol  │45% 🟢  │0.1 SOL │$10      │Minted 1m ago │ │ │
│  │ │ │[IMG]    │Dust #345 │Dust Devils│60% ⚪  │0.05 SOL│$5       │Airdrop 2m    │ │ │
│  │ │ │[IMG]    │Rare #678 │Rare Gems │2% 💎   │15 SOL  │$1,500   │Bought 3m ago │ │ │
│  │ │ │[IMG]    │Common #90│Commons   │80% ⚪  │0.01 SOL│$1       │Minted 6m ago │ │ │
│  │ │ │┊        │┊         │┊         │┊       │┊       │┊        │┊             │ │ │
│  │ │ │[Virtual scrolling - 10,000+ NFTs with lazy image loading]               │ │ │
│  │ │ │┊        │┊         │┊         │┊       │┊       │┊        │┊             │ │ │
│  │ └─┴─────────┴──────────┴──────────┴────────┴────────┴─────────┴──────────────┘ │ │
│  │ 📊 Showing 10 of 10,247 NFTs • 💰 Est. Value: $12,345 • 🏆 Collections: 89    │ │
│  │ 🔄 Prices updated: 5m ago • 📌 2 pinned • 🎯 Filtered: 1,247 • 💎 Rare: 23   │ │
│  └─────────────────────────────────────────────────────────────────────────────────┘ │
│                                                                                     │
│  ┌─────────────────────────────────────────────────────────────────────────────────┐ │
│  │                         Collection Analytics Bar                                │ │
│  │ 🏆 Top Collection: Degen Apes (15 items) • 💎 Rarest: 2% • 📈 Avg Floor: 2.1 SOL│ │
│  │ 📊 Total Collections: 89 • 🔥 Most Valuable: BAYC #567 • 📅 Latest: 2h ago     │ │
│  └─────────────────────────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────────────────────┘
```