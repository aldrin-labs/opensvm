# AI Agentic Navigation System Design

## Overview

The AI Agentic Navigation System is a sophisticated autonomous exploration engine that enables the OpenSVM AI assistant to navigate through the website independently to achieve complex user-requested tasks. The system transforms the AI from a passive assistant into an active blockchain explorer capable of multi-step investigations, pattern discovery, and comprehensive analysis across the entire platform.

## Architecture

### High-Level Architecture

```mermaid
graph TB
    User[User Interface] --> NavigationController[Navigation Controller]
    NavigationController --> PathPlanner[Path Planner]
    NavigationController --> ExecutionEngine[Execution Engine]
    NavigationController --> ProgressTracker[Progress Tracker]
    
    PathPlanner --> TemplateManager[Template Manager]
    PathPlanner --> ComplexityEstimator[Complexity Estimator]
    
    ExecutionEngine --> NavigationDriver[Navigation Driver]
    ExecutionEngine --> DataExtractor[Data Extractor]
    ExecutionEngine --> StateManager[State Manager]
    
    NavigationDriver --> Router[Next.js Router]
    DataExtractor --> PageAnalyzer[Page Analyzer]
    DataExtractor --> DataValidator[Data Validator]
    
    StateManager --> UserProfile[User Profile]
    StateManager --> InvestigationCache[Investigation Cache]
    
    ProgressTracker --> NotificationSystem[Notification System]
    ProgressTracker --> VisualizationEngine[Visualization Engine]
```

### Core Components

#### 1. Navigation Controller
Central orchestrator that manages the entire agentic navigation process.

```typescript
interface NavigationController {
  // Main execution interface
  executeInvestigation(request: InvestigationRequest): Promise<InvestigationResult>;
  pauseInvestigation(sessionId: string): Promise<void>;
  resumeInvestigation(sessionId: string): Promise<void>;
  cancelInvestigation(sessionId: string): Promise<void>;
  
  // Session management
  createSession(request: InvestigationRequest): Promise<NavigationSession>;
  getSession(sessionId: string): Promise<NavigationSession>;
  updateSession(sessionId: string, updates: Partial<NavigationSession>): Promise<void>;
  
  // Progress monitoring
  subscribeToProgress(sessionId: string, callback: ProgressCallback): void;
  getProgressStatus(sessionId: string): Promise<ProgressStatus>;
}

interface InvestigationRequest {
  objective: string;
  context: PageContext;
  constraints: InvestigationConstraints;
  userPreferences: UserPreferences;
  templateId?: string;
}

interface NavigationSession {
  id: string;
  request: InvestigationRequest;
  plan: NavigationPlan;
  currentStep: number;
  status: 'planning' | 'executing' | 'paused' | 'completed' | 'failed';
  findings: Finding[];
  errors: NavigationError[];
  startTime: number;
  estimatedEndTime: number;
  checkpoints: SessionCheckpoint[];
}
```

#### 2. Path Planner
Intelligent planning system that creates optimal navigation strategies.

```typescript
interface PathPlanner {
  // Plan generation
  createNavigationPlan(request: InvestigationRequest): Promise<NavigationPlan>;
  optimizePlan(plan: NavigationPlan, constraints: PlanConstraints): Promise<NavigationPlan>;
  adaptPlan(plan: NavigationPlan, newFindings: Finding[]): Promise<NavigationPlan>;
  
  // Plan analysis
  estimateComplexity(plan: NavigationPlan): Promise<ComplexityEstimate>;
  validatePlan(plan: NavigationPlan): Promise<PlanValidationResult>;
  suggestAlternatives(plan: NavigationPlan): Promise<NavigationPlan[]>;
}

interface NavigationPlan {
  id: string;
  objective: string;
  steps: NavigationStep[];
  estimatedDuration: number;
  complexity: ComplexityLevel;
  riskFactors: RiskFactor[];
  successProbability: number;
  alternatives: AlternativePlan[];
}

interface NavigationStep {
  id: string;
  type: NavigationActionType;
  target: string;
  parameters: Record<string, any>;
  reasoning: string;
  dependencies: string[];
  estimatedDuration: number;
  priority: number;
  retryPolicy: RetryPolicy;
}

type NavigationActionType = 
  | 'navigate_to_page'
  | 'extract_data'
  | 'analyze_content'
  | 'search_entities'
  | 'follow_relationships'
  | 'compare_entities'
  | 'validate_findings';
```

#### 3. Execution Engine
Handles the actual execution of navigation plans with error handling and recovery.

```typescript
interface ExecutionEngine {
  // Execution control
  executePlan(plan: NavigationPlan, session: NavigationSession): Promise<ExecutionResult>;
  executeStep(step: NavigationStep, context: ExecutionContext): Promise<StepResult>;
  handleStepFailure(step: NavigationStep, error: Error, context: ExecutionContext): Promise<RecoveryAction>;
  
  // State management
  saveCheckpoint(session: NavigationSession): Promise<void>;
  restoreCheckpoint(sessionId: string, checkpointId: string): Promise<NavigationSession>;
  
  // Resource management
  allocateResources(plan: NavigationPlan): Promise<ResourceAllocation>;
  releaseResources(allocation: ResourceAllocation): Promise<void>;
}

interface ExecutionContext {
  session: NavigationSession;
  currentPage: PageContext;
  extractedData: ExtractedData;
  findings: Finding[];
  resourceAllocation: ResourceAllocation;
  timeRemaining: number;
}

interface StepResult {
  success: boolean;
  data: any;
  insights: Insight[];
  nextSuggestions: NavigationStep[];
  executionTime: number;
  resourcesUsed: ResourceUsage;
  errors?: Error[];
}
```

#### 4. Data Extractor
Sophisticated data extraction system with configurable rules and validation.

```typescript
interface DataExtractor {
  // Extraction operations
  extractFromPage(pageType: string, context: PageContext): Promise<ExtractedData>;
  extractRelationships(entity: EntityReference): Promise<RelationshipData>;
  extractPatterns(data: ExtractedData[]): Promise<PatternData>;
  
  // Rule management
  registerExtractionRule(rule: ExtractionRule): void;
  updateExtractionRule(ruleId: string, updates: Partial<ExtractionRule>): void;
  validateExtractionRules(): Promise<ValidationResult>;
}

interface ExtractionRule {
  id: string;
  pageType: string;
  selectors: SelectorMap;
  transformers: TransformerMap;
  validators: ValidatorMap;
  priority: number;
  enabled: boolean;
}

interface SelectorMap {
  [key: string]: {
    selector: string;
    attribute?: string;
    multiple?: boolean;
    required?: boolean;
  };
}

interface TransformerMap {
  [key: string]: (rawData: any) => any;
}

interface ValidatorMap {
  [key: string]: (data: any) => ValidationResult;
}

interface ExtractedData {
  pageType: string;
  url: string;
  timestamp: number;
  data: Record<string, any>;
  metadata: ExtractionMetadata;
  quality: DataQuality;
}
```

#### 5. Progress Tracker
Real-time progress monitoring and user communication system.

```typescript
interface ProgressTracker {
  // Progress monitoring
  trackProgress(session: NavigationSession): void;
  updateProgress(sessionId: string, update: ProgressUpdate): void;
  getProgressSnapshot(sessionId: string): Promise<ProgressSnapshot>;
  
  // Notification management
  sendProgressNotification(sessionId: string, notification: ProgressNotification): void;
  subscribeToUpdates(sessionId: string, callback: ProgressCallback): void;
  unsubscribeFromUpdates(sessionId: string, callback: ProgressCallback): void;
  
  // Visualization
  generateProgressVisualization(sessionId: string): Promise<ProgressVisualization>;
  generateNavigationMap(session: NavigationSession): Promise<NavigationMap>;
}

interface ProgressSnapshot {
  sessionId: string;
  currentStep: number;
  totalSteps: number;
  completedSteps: NavigationStep[];
  currentAction: string;
  timeElapsed: number;
  estimatedTimeRemaining: number;
  keyFindings: Finding[];
  errors: NavigationError[];
  resourceUsage: ResourceUsage;
}

interface ProgressNotification {
  type: 'step_started' | 'step_completed' | 'insight_discovered' | 'error_encountered' | 'investigation_completed';
  message: string;
  data?: any;
  timestamp: number;
  severity: 'info' | 'warning' | 'error' | 'success';
}
```

## Components and Interfaces

### Navigation Driver
Handles virtual navigation and data fetching without affecting the user's current page context.

```typescript
interface NavigationDriver {
  // Virtual navigation operations (no actual browser navigation)
  fetchPageData(url: string): Promise<NavigationResult>;
  getCurrentUserContext(): Promise<PageContext>;
  getVirtualContext(): Promise<NavigationContext>;
  
  // Data fetching without navigation
  fetchAccountData(address: string): Promise<AccountData>;
  fetchTransactionData(signature: string): Promise<TransactionData>;
  fetchTokenData(mint: string): Promise<TokenData>;
  fetchBlockData(slot: number): Promise<BlockData>;
  
  // Context management
  preserveUserContext(): void;
  restoreUserContext(): void;
  updateVirtualContext(context: NavigationContext): void;
  
  // Virtual page interaction
  extractDataFromResponse(response: APIResponse): Promise<ExtractedData>;
  simulatePageVisit(url: string): Promise<VirtualPageState>;
}

interface NavigationResult {
  success: boolean;
  url: string;
  pageType: string;
  fetchTime: number;
  errors?: Error[];
  context: PageContext;
  data: any; // Fetched page data
}

interface VirtualPageState {
  url: string;
  pageType: string;
  content: string;
  extractedData: ExtractedData;
  metadata: PageMetadata;
  timestamp: number;
}

interface NavigationContext {
  // AI's virtual navigation state
  currentInvestigationPage: string;
  virtualPageStack: VirtualPageState[];
  investigationPath: NavigationStep[];
  extractedDataCache: Map<string, ExtractedData>;
  
  // User's preserved context
  userCurrentPage: string;
  userScrollPosition: number;
  userPageState: any;
}
```

### Template Manager
Manages investigation templates and workflows.

```typescript
interface TemplateManager {
  // Template operations
  getTemplate(templateId: string): Promise<InvestigationTemplate>;
  listTemplates(category?: string): Promise<InvestigationTemplate[]>;
  createTemplate(template: InvestigationTemplate): Promise<string>;
  updateTemplate(templateId: string, updates: Partial<InvestigationTemplate>): Promise<void>;
  
  // Template execution
  instantiateTemplate(templateId: string, parameters: TemplateParameters): Promise<NavigationPlan>;
  validateTemplate(template: InvestigationTemplate): Promise<ValidationResult>;
  
  // Community features
  shareTemplate(templateId: string, permissions: SharingPermissions): Promise<string>;
  importTemplate(sharedTemplateId: string): Promise<string>;
  rateTemplate(templateId: string, rating: number, feedback?: string): Promise<void>;
}

interface InvestigationTemplate {
  id: string;
  name: string;
  description: string;
  category: string;
  skillLevel: 'beginner' | 'intermediate' | 'advanced';
  parameters: TemplateParameter[];
  steps: NavigationStepTemplate[];
  expectedDuration: number;
  successRate: number;
  tags: string[];
  author: string;
  version: string;
  created: number;
  updated: number;
}

interface TemplateParameter {
  name: string;
  type: 'string' | 'number' | 'boolean' | 'address' | 'signature';
  description: string;
  required: boolean;
  defaultValue?: any;
  validation?: ValidationRule;
}
```

### Data Correlator
Advanced data correlation and pattern detection system.

```typescript
interface DataCorrelator {
  // Correlation analysis
  correlateEntities(entities: EntityReference[]): Promise<CorrelationResult>;
  findPatterns(data: ExtractedData[]): Promise<PatternResult>;
  detectAnomalies(data: ExtractedData[], baseline?: BaselineData): Promise<AnomalyResult>;
  
  // Relationship analysis
  buildRelationshipGraph(startEntity: EntityReference, depth: number): Promise<RelationshipGraph>;
  calculateRelationshipStrength(entity1: EntityReference, entity2: EntityReference): Promise<number>;
  findShortestPath(source: EntityReference, target: EntityReference): Promise<EntityPath>;
  
  // Temporal analysis
  analyzeTemporalPatterns(entities: EntityReference[], timeRange: TimeRange): Promise<TemporalAnalysis>;
  detectBehaviorChanges(entity: EntityReference, timeWindows: TimeWindow[]): Promise<BehaviorChange[]>;
}

interface CorrelationResult {
  entities: EntityReference[];
  correlations: Correlation[];
  strength: number;
  confidence: number;
  patterns: Pattern[];
  insights: Insight[];
}

interface Correlation {
  entity1: EntityReference;
  entity2: EntityReference;
  type: CorrelationType;
  strength: number;
  evidence: Evidence[];
  timeframe: TimeRange;
}

type CorrelationType = 
  | 'transaction_flow'
  | 'token_holding'
  | 'temporal_pattern'
  | 'behavioral_similarity'
  | 'network_proximity';
```

## Data Models

### Core Data Structures

```typescript
interface Finding {
  id: string;
  type: FindingType;
  entity: EntityReference;
  description: string;
  evidence: Evidence[];
  confidence: number;
  severity: 'low' | 'medium' | 'high' | 'critical';
  timestamp: number;
  relatedFindings: string[];
}

interface Evidence {
  type: EvidenceType;
  source: string;
  data: any;
  reliability: number;
  timestamp: number;
}

interface Insight {
  id: string;
  category: InsightCategory;
  title: string;
  description: string;
  actionable: boolean;
  recommendations: string[];
  confidence: number;
  impact: 'low' | 'medium' | 'high';
}

interface EntityReference {
  type: 'account' | 'transaction' | 'token' | 'block' | 'program';
  id: string;
  metadata?: Record<string, any>;
}

interface RelationshipGraph {
  nodes: GraphNode[];
  edges: GraphEdge[];
  metadata: GraphMetadata;
}

interface GraphNode {
  id: string;
  entity: EntityReference;
  properties: NodeProperties;
  position?: { x: number; y: number };
}

interface GraphEdge {
  id: string;
  source: string;
  target: string;
  type: RelationshipType;
  weight: number;
  properties: EdgeProperties;
}
```

### Investigation State Management

```typescript
interface InvestigationState {
  sessionId: string;
  currentContext: PageContext;
  visitedPages: PageVisit[];
  extractedData: ExtractedData[];
  findings: Finding[];
  insights: Insight[];
  relationships: Relationship[];
  checkpoints: StateCheckpoint[];
  userInteractions: UserInteraction[];
}

interface PageVisit {
  url: string;
  pageType: string;
  timestamp: number;
  duration: number;
  dataExtracted: boolean;
  errors?: Error[];
}

interface StateCheckpoint {
  id: string;
  timestamp: number;
  state: Partial<InvestigationState>;
  description: string;
  automatic: boolean;
}
```

## Error Handling

### Error Classification and Recovery

```typescript
interface NavigationError {
  id: string;
  type: NavigationErrorType;
  message: string;
  context: ErrorContext;
  recoverable: boolean;
  retryCount: number;
  timestamp: number;
  stack?: string;
}

type NavigationErrorType = 
  | 'navigation_failed'
  | 'page_load_timeout'
  | 'data_extraction_failed'
  | 'invalid_response'
  | 'rate_limit_exceeded'
  | 'network_error'
  | 'authentication_required'
  | 'resource_unavailable';

interface ErrorRecoveryStrategy {
  errorType: NavigationErrorType;
  maxRetries: number;
  retryDelay: number;
  backoffMultiplier: number;
  alternativeActions: NavigationStep[];
  escalationThreshold: number;
}

interface RecoveryAction {
  type: 'retry' | 'skip' | 'alternative' | 'abort';
  delay?: number;
  alternativeStep?: NavigationStep;
  reason: string;
}
```

## Testing Strategy

### Unit Testing
- Navigation controller logic
- Path planning algorithms
- Data extraction rules
- Error handling mechanisms
- Template validation

### Integration Testing
- End-to-end navigation flows
- Data correlation accuracy
- Progress tracking reliability
- Template execution
- User interaction handling

### Performance Testing
- Navigation speed benchmarks
- Memory usage during long investigations
- Concurrent session handling
- Resource allocation efficiency
- Cache performance

### User Acceptance Testing
- Investigation template effectiveness
- User experience during navigation
- Progress communication clarity
- Error recovery user experience
- Collaborative features usability

## Security Considerations

### Data Protection
- Encrypt investigation session data
- Sanitize extracted data before storage
- Implement secure data transmission
- Apply privacy filters to shared investigations

### Access Control
- Validate user permissions for navigation actions
- Implement rate limiting for investigation requests
- Audit trail for all navigation activities
- Secure template sharing mechanisms

### Input Validation
- Validate all navigation parameters
- Sanitize user-provided investigation objectives
- Prevent injection attacks in extraction rules
- Validate template parameters and steps

## Performance Optimization

### Caching Strategy
- Cache extracted data with TTL
- Cache navigation plans for similar objectives
- Cache template instantiations
- Cache relationship calculations

### Resource Management
- Limit concurrent investigations per user
- Implement investigation queuing system
- Monitor and limit resource usage
- Automatic cleanup of completed sessions

### Optimization Techniques
- Lazy loading of investigation components
- Progressive data extraction
- Parallel execution of independent steps
- Intelligent prefetching of likely next pages

## UI Layouts and Components

### Investigation Control Panel Layout
```typescript
interface InvestigationControlPanel {
  // Main control area
  investigationStatus: InvestigationStatusDisplay;
  controlButtons: InvestigationControls;
  progressVisualization: ProgressVisualization;
  
  // Expandable sections
  currentStepDetails: StepDetailsPanel;
  findingsPanel: FindingsDisplay;
  navigationMap: NavigationMapView;
  
  // Side panels
  templateSelector: TemplateSelectionPanel;
  historyPanel: InvestigationHistoryPanel;
  settingsPanel: InvestigationSettingsPanel;
}

interface InvestigationStatusDisplay {
  currentObjective: string;
  currentStep: string;
  progressBar: ProgressBarComponent;
  timeElapsed: string;
  estimatedTimeRemaining: string;
  status: 'planning' | 'executing' | 'paused' | 'completed' | 'failed';
}

interface InvestigationControls {
  pauseButton: ButtonComponent;
  resumeButton: ButtonComponent;
  stopButton: ButtonComponent;
  modifyButton: ButtonComponent;
  exportButton: ButtonComponent;
  shareButton: ButtonComponent;
}
```

### Progress Visualization Layout
```typescript
interface ProgressVisualization {
  // Main visualization area
  navigationPath: NavigationPathComponent;
  currentStepHighlight: StepHighlightComponent;
  completedSteps: CompletedStepsComponent;
  upcomingSteps: UpcomingStepsComponent;
  
  // Interactive elements
  stepClickHandlers: StepInteractionHandlers;
  zoomControls: ZoomControlsComponent;
  filterControls: FilterControlsComponent;
  
  // Data display
  findingsOverlay: FindingsOverlayComponent;
  insightsPanel: InsightsPanelComponent;
  errorIndicators: ErrorIndicatorsComponent;
}

interface NavigationMapView {
  // Graph visualization
  nodeGraph: GraphVisualizationComponent;
  edgeConnections: EdgeConnectionsComponent;
  nodeDetails: NodeDetailsPanel;
  
  // Layout controls
  layoutSelector: LayoutSelectorComponent;
  nodeFilters: NodeFilterComponent;
  edgeFilters: EdgeFilterComponent;
  
  // Interaction
  nodeClickHandlers: NodeInteractionHandlers;
  edgeClickHandlers: EdgeInteractionHandlers;
  contextMenu: ContextMenuComponent;
}
```

### AI Sidebar Integration Layout - ASCII Art Design

#### Enhanced AI Sidebar with Agentic Navigation
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ ╔═══════════════════════════════════════════════════════════════════════════╗ │
│ ║                    🤖 AI Assistant & Agentic Explorer                    ║ │
│ ╚═══════════════════════════════════════════════════════════════════════════╝ │
├─────────────────────────────────────────────────────────────────────────────┤
│ ┌─ Context Awareness ─────────────────────────────────────────────────────┐ │
│ │ 📍 Currently viewing: Account 7xKX...9mN2                              │ │
│ │ 🔗 Found 3 connections with previously visited wallets                 │ │
│ │ ┌─────────────────────────────────────────────────────────────────────┐ │ │
│ │ │ 💡 This account has 12 transactions with "DeFi Whale" (2h ago)     │ │ │
│ │ │    [Analyze Connection] [View Details]                              │ │ │
│ │ └─────────────────────────────────────────────────────────────────────┘ │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────────────────────────────────┤
│ ┌─ Active Investigation ──────────────────────────────────────────────────┐ │
│ │ 🔍 Investigating: "DeFi Portfolio Risk Analysis"                       │ │
│ │ ████████████████████░░░░ 80% Complete (Step 4/5)                       │ │
│ │ ⏱️  2m 15s elapsed • ~30s remaining                                     │ │
│ │                                                                         │ │
│ │ Current: Analyzing cross-protocol exposure...                          │ │
│ │ ┌─────────────────────────────────────────────────────────────────────┐ │ │
│ │ │ ✅ Account overview extracted                                       │ │ │
│ │ │ ✅ Token holdings analyzed (12 DeFi tokens found)                  │ │ │
│ │ │ ✅ Protocol connections mapped (Uniswap, Aave, Compound)           │ │ │
│ │ │ 🔄 Risk assessment in progress...                                   │ │ │
│ │ │ ⏳ Final report generation pending                                  │ │ │
│ │ └─────────────────────────────────────────────────────────────────────┘ │ │
│ │                                                                         │ │
│ │ [⏸️ Pause] [⏹️ Stop] [⚙️ Modify] [📊 View Progress]                      │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────────────────────────────────┤
│ ┌─ Chat Interface ────────────────────────────────────────────────────────┐ │
│ │ ┌─────────────────────────────────────────────────────────────────────┐ │ │
│ │ │ 👤 User: Can you investigate this wallet's DeFi activities?        │ │ │
│ │ │                                                                     │ │ │
│ │ │ 🤖 AI: I'll analyze this wallet's DeFi portfolio. Let me start     │ │ │
│ │ │     an investigation to examine:                                    │ │ │
│ │ │     • Token holdings and allocations                               │ │ │
│ │ │     • Protocol interactions and strategies                         │ │ │
│ │ │     • Risk exposure and diversification                            │ │ │
│ │ │                                                                     │ │ │
│ │ │     [🚀 Start Investigation] [📋 Use Template] [⚙️ Customize]       │ │ │
│ │ │                                                                     │ │ │
│ │ │ 👤 User: Yes, please focus on risk analysis                        │ │ │
│ │ │                                                                     │ │ │
│ │ │ 🤖 AI: Perfect! I'm now navigating through the data to build       │ │ │
│ │ │     a comprehensive risk profile. You can see my progress above.   │ │ │
│ │ └─────────────────────────────────────────────────────────────────────┘ │ │
│ │                                                                         │ │
│ │ ┌─ Message Input ─────────────────────────────────────────────────────┐ │ │
│ │ │ Type your message... 💬                                [🎤] [📎]    │ │ │
│ │ └─────────────────────────────────────────────────────────────────────┘ │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────────────────────────────────┤
│ ┌─ Quick Investigation Templates ─────────────────────────────────────────┐ │
│ │ 🎯 Quick Actions:                                                       │ │
│ │ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐         │ │
│ │ │ 💰 DeFi     │ │ 🔍 Suspicious│ │ 🔗 Wallet   │ │ 📊 Portfolio│         │ │
│ │ │ Analysis    │ │ Activity    │ │ Connections │ │ Overview    │         │ │
│ │ └─────────────┘ └─────────────┘ └─────────────┘ └─────────────┘         │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────────────────────────────────┤
│ ┌─ Recent Findings ───────────────────────────────────────────────────────┐ │
│ │ 🔍 Latest Discoveries:                                                  │ │
│ │ ┌─────────────────────────────────────────────────────────────────────┐ │ │
│ │ │ ⚠️  High Risk: 65% portfolio in single protocol (Aave)             │ │ │
│ │ │ 💡 Insight: Wallet shows sophisticated DeFi strategy               │ │ │
│ │ │ 🔗 Connection: Linked to 3 other high-value wallets                │ │ │
│ │ └─────────────────────────────────────────────────────────────────────┘ │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────────────────────────────────┤
│ ┌─ Investigation History ─────────────────────────────────────────────────┐ │
│ │ 📚 Recent Investigations:                                               │ │
│ │ • DeFi Portfolio Analysis - 2h ago ✅                                   │ │
│ │ • Suspicious Activity Check - 1d ago ⚠️                                │ │
│ │ • Wallet Connection Map - 3d ago 🔗                                     │ │
│ │                                                        [View All]       │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────────────────────────────────┤
│ ┌─ Settings & Controls ───────────────────────────────────────────────────┐ │
│ │ ⚙️  [Settings] [📤 Export] [🔗 Share] [📱 Mobile] [🔍 Fullscreen]        │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────────────┘
│◄──── Resize Handle (Draggable) ────►│
```

#### Investigation Progress Visualization (Expanded View)
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ ╔═══════════════════════════════════════════════════════════════════════════╗ │
│ ║                    🔍 Investigation Progress Visualization               ║ │
│ ╚═══════════════════════════════════════════════════════════════════════════╝ │
├─────────────────────────────────────────────────────────────────────────────┤
│ ┌─ Navigation Path ───────────────────────────────────────────────────────┐ │
│ │                                                                         │ │
│ │ [🏠 Home] ──→ [👤 Account] ──→ [💰 Tokens] ──→ [🔗 Connections] ──→ [📊] │ │
│ │    ✅           ✅              ✅              🔄                 ⏳    │ │
│ │                                                                         │ │
│ │ Step Details:                                                           │ │
│ │ ┌─────────────────────────────────────────────────────────────────────┐ │ │
│ │ │ 🔄 Current: Analyzing cross-protocol connections                   │ │ │
│ │ │ 📍 Page: /account/7xKX...9mN2                                       │ │ │
│ │ │ ⏱️  Duration: 45s                                                   │ │ │
│ │ │ 📊 Data Extracted: 847 transactions, 12 tokens, 3 protocols        │ │ │
│ │ └─────────────────────────────────────────────────────────────────────┘ │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────────────────────────────────┤
│ ┌─ Relationship Graph ────────────────────────────────────────────────────┐ │
│ │                                                                         │ │
│ │                    ┌─────────┐                                          │ │
│ │                    │ Uniswap │                                          │ │
│ │                    │   V3    │                                          │ │
│ │                    └────┬────┘                                          │ │
│ │                         │ 45 txns                                       │ │
│ │    ┌─────────┐         │         ┌─────────┐                           │ │
│ │    │  Aave   │◄────────┼────────►│ Target  │                           │ │
│ │    │Protocol │ 312 txns│         │ Wallet  │                           │ │
│ │    └─────────┘         │         └────┬────┘                           │ │
│ │                        │              │ 89 txns                        │ │
│ │                   ┌────┴────┐         │                                │ │
│ │                   │Compound │         │                                │ │
│ │                   │Protocol │         │                                │ │
│ │                   └─────────┘    ┌────▼────┐                           │ │
│ │                                  │Connected│                           │ │
│ │                                  │ Wallet  │                           │ │
│ │                                  └─────────┘                           │ │
│ │                                                                         │ │
│ │ [🔍 Zoom] [📐 Layout] [🎨 Style] [📤 Export]                            │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────────────────────────────────┤
│ ┌─ Live Findings Stream ──────────────────────────────────────────────────┐ │
│ │ 🔴 LIVE • New findings as they're discovered:                          │ │
│ │                                                                         │ │
│ │ [14:32:15] ✅ Extracted account balance: 45.7 SOL                      │ │
│ │ [14:32:18] 💰 Found 12 token holdings worth $127,450                   │ │
│ │ [14:32:22] 🔗 Discovered connection to whale wallet (strength: 0.85)   │ │
│ │ [14:32:28] ⚠️  Risk Alert: 65% portfolio concentration in Aave         │ │
│ │ [14:32:31] 🔄 Analyzing protocol interaction patterns...               │ │
│ │ [14:32:35] 💡 Pattern detected: Sophisticated yield farming strategy   │ │
│ │                                                                         │ │
│ │ ┌─ Key Insights ─────────────────────────────────────────────────────┐ │ │
│ │ │ • High-value DeFi user with advanced strategies                    │ │ │
│ │ │ • Strong connections to other sophisticated wallets                │ │ │
│ │ │ • Risk: Over-concentration in lending protocols                    │ │ │
│ │ │ • Opportunity: Diversification recommendations available            │ │ │
│ │ └─────────────────────────────────────────────────────────────────────┘ │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────────────┘
```

#### Mobile Responsive Layout
```
┌─────────────────────────────────┐
│ ╔═══════════════════════════════╗ │
│ ║     🤖 AI Agentic Explorer    ║ │
│ ╚═══════════════════════════════╝ │
├─────────────────────────────────┤
│ ┌─ Context ─────────────────────┐ │
│ │ 📍 Account: 7xKX...9mN2       │ │
│ │ 🔗 3 connections found        │ │
│ │ [💡 View Connections]         │ │
│ └───────────────────────────────┘ │
├─────────────────────────────────┤
│ ┌─ Active Investigation ────────┐ │
│ │ 🔍 DeFi Risk Analysis         │ │
│ │ ████████████░░░░ 80%          │ │
│ │ Step 4/5 • 30s remaining      │ │
│ │                               │ │
│ │ [⏸️] [⏹️] [📊] [⚙️]             │ │
│ └───────────────────────────────┘ │
├─────────────────────────────────┤
│ ┌─ Chat ────────────────────────┐ │
│ │ 👤 Investigate this wallet    │ │
│ │                               │ │
│ │ 🤖 Starting DeFi analysis...  │ │
│ │    [🚀 View Progress]         │ │
│ │                               │ │
│ │ ┌─────────────────────────────┐ │ │
│ │ │ Type message... [🎤] [📎]   │ │ │
│ │ └─────────────────────────────┘ │ │
│ └───────────────────────────────┘ │
├─────────────────────────────────┤
│ ┌─ Quick Actions ───────────────┐ │
│ │ [💰 DeFi] [🔍 Suspicious]     │ │
│ │ [🔗 Connect] [📊 Portfolio]   │ │
│ └───────────────────────────────┘ │
├─────────────────────────────────┤
│ ┌─ Recent Findings ─────────────┐ │
│ │ ⚠️  High Risk: 65% in Aave    │ │
│ │ 💡 Sophisticated strategy     │ │
│ │ 🔗 3 whale connections        │ │
│ │ [View All Findings]           │ │
│ └───────────────────────────────┘ │
└─────────────────────────────────┘
```

### TypeScript Interface for ASCII Layout Components

```typescript
interface AISidebarWithAgentic {
  // Existing chat interface
  chatInterface: AIChatInterface;
  messageHistory: MessageHistoryComponent;
  inputArea: MessageInputComponent;
  
  // Agentic navigation integration
  investigationTrigger: InvestigationTriggerComponent;
  activeInvestigationStatus: ActiveInvestigationStatusComponent;
  quickInvestigationActions: QuickActionsComponent;
  
  // Context awareness
  contextDisplay: ContextDisplayComponent;
  connectionNotifications: ConnectionNotificationComponent;
  historyIntegration: HistoryIntegrationComponent;
  
  // Layout management
  resizeHandle: ResizeHandleComponent;
  panelToggle: PanelToggleComponent;
  fullscreenMode: FullscreenModeComponent;
}

interface InvestigationTriggerComponent {
  // Natural language triggers
  triggerPhraseDetection: TriggerDetectionLogic;
  investigationSuggestions: SuggestionDisplayComponent;
  templateQuickSelect: TemplateQuickSelectComponent;
  
  // User interaction
  startInvestigationButton: ButtonComponent;
  customObjectiveInput: InputComponent;
  constraintsSelector: ConstraintsSelectorComponent;
}
```

### Mobile Layout Adaptations
```typescript
interface MobileInvestigationLayout {
  // Responsive design
  collapsiblePanels: CollapsiblePanelComponent[];
  swipeGestures: SwipeGestureHandlers;
  touchOptimizedControls: TouchControlsComponent;
  
  // Mobile-specific features
  fullscreenInvestigation: FullscreenInvestigationComponent;
  bottomSheetControls: BottomSheetComponent;
  floatingActionButton: FloatingActionButtonComponent;
  
  // Performance optimizations
  lazyLoadedSections: LazyLoadComponent[];
  virtualizedLists: VirtualizedListComponent[];
  optimizedAnimations: OptimizedAnimationComponent[];
}
```

## Context Preservation Strategy

### How AI Navigates Without Losing Context

The agentic navigation system maintains its own context through a **virtual navigation layer** that operates independently of the user's browser session. This ensures the user never loses their place while the AI conducts autonomous investigations.

#### 1. Virtual Navigation Architecture

```typescript
class VirtualNavigationEngine {
  private userContext: UserSessionContext;
  private aiContext: AINavigationContext;
  private dataFetcher: VirtualDataFetcher;
  
  async navigateVirtually(url: string): Promise<VirtualNavigationResult> {
    // Preserve user's current state
    this.preserveUserSession();
    
    // Fetch page data via API without browser navigation
    const pageData = await this.dataFetcher.fetchPageData(url);
    
    // Update AI's virtual context
    this.aiContext.addVirtualPage(url, pageData);
    
    // Extract data from virtual page
    const extractedData = await this.extractDataFromVirtualPage(pageData);
    
    // User remains on their original page
    return {
      virtualUrl: url,
      extractedData,
      userStillOn: this.userContext.currentPage
    };
  }
}

interface UserSessionContext {
  currentPage: string;
  scrollPosition: number;
  formData: Record<string, any>;
  navigationHistory: string[];
  timestamp: number;
}

interface AINavigationContext {
  investigationId: string;
  virtualPageStack: VirtualPage[];
  extractedDataCache: Map<string, ExtractedData>;
  navigationPath: NavigationStep[];
  findings: Finding[];
  currentObjective: string;
}
```

#### 2. Data Fetching Strategy

Instead of browser navigation, the AI uses existing API endpoints and server-side data:

```typescript
interface VirtualDataFetcher {
  // Use existing API endpoints
  fetchAccountPage(address: string): Promise<AccountPageData>;
  fetchTransactionPage(signature: string): Promise<TransactionPageData>;
  fetchTokenPage(mint: string): Promise<TokenPageData>;
  
  // Server-side rendering data
  getSSRData(url: string): Promise<SSRPageData>;
  
  // Direct database queries
  queryAccountData(address: string): Promise<AccountData>;
  queryTransactionData(signature: string): Promise<TransactionData>;
}

// Example: Virtual account page visit
async function visitAccountPageVirtually(address: string): Promise<VirtualPage> {
  // Fetch data without changing user's page
  const accountData = await api.get(`/api/account-stats/${address}`);
  const tokenData = await api.get(`/api/account-token-stats/${address}`);
  const transactionData = await api.get(`/api/account-transactions/${address}`);
  
  // Create virtual page representation
  return {
    url: `/account/${address}`,
    type: 'account',
    data: {
      account: accountData,
      tokens: tokenData,
      transactions: transactionData
    },
    extractedAt: Date.now(),
    userNeverVisited: true // User stayed on their original page
  };
}
```

#### 3. Context Isolation and Management

```typescript
class ContextManager {
  private contexts: Map<string, NavigationContext> = new Map();
  
  // Create isolated context for each investigation
  createInvestigationContext(sessionId: string): NavigationContext {
    const context: NavigationContext = {
      sessionId,
      userOriginalPage: window.location.href,
      userOriginalState: this.captureUserState(),
      aiVirtualPages: [],
      aiCurrentVirtualPage: null,
      aiNavigationHistory: [],
      aiExtractedData: new Map(),
      aiFindings: []
    };
    
    this.contexts.set(sessionId, context);
    return context;
  }
  
  // Switch between user and AI contexts
  switchToAIContext(sessionId: string): void {
    const context = this.contexts.get(sessionId);
    if (context) {
      // AI operates in its virtual space
      this.activeContext = context;
    }
  }
  
  switchToUserContext(): void {
    // User always stays in their original context
    this.activeContext = this.userContext;
  }
  
  private captureUserState(): UserState {
    return {
      url: window.location.href,
      scrollY: window.scrollY,
      formData: this.extractFormData(),
      timestamp: Date.now()
    };
  }
}
```

#### 4. Real-time Progress Without Disruption

The AI shows its virtual navigation progress while the user remains undisturbed:

```ascii
User's Browser Tab:                    AI's Virtual Navigation:
┌─────────────────────────┐           ┌─────────────────────────┐
│ 📍 /account/ABC123      │           │ 🤖 Virtually visiting: │
│                         │           │ 📍 /account/ABC123      │
│ User stays here ────────┼───────────┼──→ /token/DEF456       │
│ throughout investigation│           │ ──→ /tx/GHI789          │
│                         │           │ ──→ /account/JKL012     │
│ [AI Sidebar shows       │           │                         │
│  virtual progress]      │           │ All data fetched via    │
│                         │           │ API calls, no browser   │
│                         │           │ navigation              │
└─────────────────────────┘           └─────────────────────────┘
```

#### 5. Data Extraction from Virtual Pages

```typescript
class VirtualPageExtractor {
  async extractFromVirtualPage(virtualPage: VirtualPage): Promise<ExtractedData> {
    switch (virtualPage.type) {
      case 'account':
        return this.extractAccountData(virtualPage.data);
      case 'transaction':
        return this.extractTransactionData(virtualPage.data);
      case 'token':
        return this.extractTokenData(virtualPage.data);
      default:
        return this.extractGenericData(virtualPage.data);
    }
  }
  
  private extractAccountData(data: any): ExtractedData {
    return {
      balance: data.account.lamports,
      tokens: data.tokens.map(t => ({
        mint: t.mint,
        balance: t.balance,
        usdValue: t.usdValue
      })),
      transactionCount: data.transactions.length,
      // ... other extracted fields
    };
  }
}
```

#### 6. Investigation Progress Visualization

The user sees the AI's virtual journey without their page changing:

```typescript
interface InvestigationProgressDisplay {
  // Show AI's virtual navigation path
  virtualNavigationPath: VirtualNavigationStep[];
  
  // Current virtual page AI is "on"
  currentVirtualPage: string;
  
  // Data extracted from virtual pages
  extractedDataSummary: ExtractedDataSummary;
  
  // User's actual page (unchanged)
  userActualPage: string;
  
  // Progress indicators
  stepsCompleted: number;
  stepsTotal: number;
  timeElapsed: number;
}

// Example progress display
const progressDisplay = {
  virtualNavigationPath: [
    { page: '/account/ABC123', status: 'completed', dataExtracted: true },
    { page: '/token/DEF456', status: 'completed', dataExtracted: true },
    { page: '/tx/GHI789', status: 'in-progress', dataExtracted: false },
    { page: '/account/JKL012', status: 'pending', dataExtracted: false }
  ],
  currentVirtualPage: '/tx/GHI789',
  userActualPage: '/account/ABC123', // User never moved
  stepsCompleted: 2,
  stepsTotal: 4,
  timeElapsed: 45000 // 45 seconds
};
```

#### 7. Context Restoration and Cleanup

```typescript
class InvestigationCleanup {
  async completeInvestigation(sessionId: string): Promise<void> {
    const context = this.contextManager.getContext(sessionId);
    
    // Save investigation results to user profile
    await this.saveInvestigationResults(context.aiFindings);
    
    // Clean up virtual pages and temporary data
    this.cleanupVirtualPages(context.aiVirtualPages);
    
    // Ensure user is still on their original page
    this.verifyUserContext(context.userOriginalPage);
    
    // Remove investigation context
    this.contextManager.removeContext(sessionId);
  }
  
  private verifyUserContext(originalPage: string): void {
    if (window.location.href !== originalPage) {
      // This should never happen, but if it does, restore user
      console.warn('User context was disrupted, restoring...');
      window.location.href = originalPage;
    }
  }
}
```

### Key Benefits of Virtual Navigation

1. **Zero User Disruption**: User never leaves their current page
2. **Parallel Processing**: AI can "visit" multiple pages simultaneously via API calls
3. **Context Preservation**: Both user and AI contexts are maintained separately
4. **Performance**: Faster than browser navigation, uses cached API responses
5. **Security**: No risk of disrupting user's session or losing form data
6. **Transparency**: User can see exactly where AI is "going" and what it's finding

This virtual navigation approach ensures the AI can conduct sophisticated multi-page investigations while the user remains completely undisturbed on their original page, with full visibility into the AI's autonomous exploration process.

## Technical Implementation Architecture

### File Structure and Organization
```
lib/ai/agentic/
├── core/
│   ├── NavigationController.ts
│   ├── PathPlanner.ts
│   ├── ExecutionEngine.ts
│   └── ProgressTracker.ts
├── drivers/
│   ├── NavigationDriver.ts
│   ├── DataExtractor.ts
│   └── PageAnalyzer.ts
├── templates/
│   ├── TemplateManager.ts
│   ├── InvestigationTemplate.ts
│   └── predefined/
│       ├── DeFiAnalysisTemplate.ts
│       ├── SuspiciousActivityTemplate.ts
│       └── WalletConnectionTemplate.ts
├── correlation/
│   ├── DataCorrelator.ts
│   ├── PatternDetector.ts
│   └── RelationshipAnalyzer.ts
├── state/
│   ├── SessionManager.ts
│   ├── StateManager.ts
│   └── CheckpointManager.ts
├── utils/
│   ├── ErrorHandler.ts
│   ├── CacheManager.ts
│   └── PerformanceMonitor.ts
└── types/
    ├── NavigationTypes.ts
    ├── InvestigationTypes.ts
    └── AnalysisTypes.ts

components/ai/agentic/
├── InvestigationControlPanel.tsx
├── ProgressVisualization.tsx
├── NavigationMapView.tsx
├── TemplateSelector.tsx
├── FindingsDisplay.tsx
├── InvestigationHistory.tsx
└── mobile/
    ├── MobileInvestigationView.tsx
    └── TouchOptimizedControls.tsx

app/api/agentic/
├── investigations/
│   ├── route.ts
│   ├── [sessionId]/
│   │   ├── route.ts
│   │   ├── progress/route.ts
│   │   ├── control/route.ts
│   │   └── findings/route.ts
├── templates/
│   ├── route.ts
│   └── [templateId]/route.ts
└── websocket/
    └── progress/route.ts
```

### Database Schema Design
```typescript
// Investigation Sessions Table
interface InvestigationSessionSchema {
  id: string;
  userId: string;
  objective: string;
  status: InvestigationStatus;
  planId: string;
  currentStep: number;
  startTime: Date;
  endTime?: Date;
  findings: Finding[];
  errors: NavigationError[];
  metadata: Record<string, any>;
  createdAt: Date;
  updatedAt: Date;
}

// Navigation Plans Table
interface NavigationPlanSchema {
  id: string;
  sessionId: string;
  steps: NavigationStep[];
  estimatedDuration: number;
  complexity: ComplexityLevel;
  version: number;
  createdAt: Date;
}

// Extracted Data Cache Table
interface ExtractedDataSchema {
  id: string;
  url: string;
  pageType: string;
  data: Record<string, any>;
  quality: DataQuality;
  extractedAt: Date;
  expiresAt: Date;
}

// User Investigation History Table
interface UserInvestigationHistorySchema {
  id: string;
  userId: string;
  sessionId: string;
  entitiesVisited: EntityReference[];
  connectionsDiscovered: Connection[];
  patterns: Pattern[];
  createdAt: Date;
}
```

### WebSocket/SSE Integration
```typescript
interface ProgressWebSocketHandler {
  // Connection management
  handleConnection(socket: WebSocket, sessionId: string): void;
  handleDisconnection(socket: WebSocket): void;
  
  // Message handling
  sendProgressUpdate(sessionId: string, update: ProgressUpdate): void;
  sendFindingNotification(sessionId: string, finding: Finding): void;
  sendErrorNotification(sessionId: string, error: NavigationError): void;
  
  // Subscription management
  subscribeToSession(socket: WebSocket, sessionId: string): void;
  unsubscribeFromSession(socket: WebSocket, sessionId: string): void;
}

interface SSEProgressStream {
  // Stream management
  createStream(sessionId: string): ReadableStream;
  closeStream(sessionId: string): void;
  
  // Event emission
  emitProgressEvent(sessionId: string, event: ProgressEvent): void;
  emitFindingEvent(sessionId: string, event: FindingEvent): void;
  emitCompletionEvent(sessionId: string, event: CompletionEvent): void;
}
```

## SVMAI Token Monetization System

### Token-Based Pricing Model

The AI Agentic Navigation System operates on a consumption-based pricing model using SVMAI tokens:

```typescript
interface SVMAITokenPricing {
  // Base investigation costs
  basicInvestigation: number;        // 10 SVMAI tokens
  complexInvestigation: number;      // 25 SVMAI tokens
  deepInvestigation: number;         // 50 SVMAI tokens
  
  // Per-step costs
  navigationStep: number;            // 2 SVMAI tokens per step
  dataExtraction: number;            // 1 SVMAI token per page
  patternAnalysis: number;           // 5 SVMAI tokens per analysis
  relationshipMapping: number;       // 3 SVMAI tokens per relationship
  
  // Premium features
  realTimeMonitoring: number;        // 20 SVMAI tokens per hour
  advancedVisualization: number;     // 15 SVMAI tokens per chart
  expertTemplates: number;           // 30 SVMAI tokens per template
  collaborativeFeatures: number;     // 10 SVMAI tokens per share
  
  // Subscription discounts
  premiumDiscount: number;           // 20% discount
  enterpriseDiscount: number;        // 40% discount
}

interface TokenConsumptionTracker {
  sessionId: string;
  userId: string;
  startBalance: number;
  currentBalance: number;
  tokensConsumed: number;
  consumptionBreakdown: ConsumptionItem[];
  estimatedCost: number;
  actualCost: number;
}

interface ConsumptionItem {
  action: string;
  cost: number;
  timestamp: number;
  description: string;
}
```

### Token Gating and Access Control

```typescript
class SVMAITokenGate {
  async validateInvestigationAccess(
    userId: string, 
    investigationType: InvestigationType
  ): Promise<AccessValidation> {
    const userBalance = await this.getUserTokenBalance(userId);
    const estimatedCost = this.calculateEstimatedCost(investigationType);
    
    if (userBalance < estimatedCost) {
      return {
        allowed: false,
        reason: 'insufficient_tokens',
        required: estimatedCost,
        current: userBalance,
        shortfall: estimatedCost - userBalance
      };
    }
    
    return {
      allowed: true,
      estimatedCost,
      currentBalance: userBalance
    };
  }
  
  async consumeTokens(
    userId: string, 
    sessionId: string, 
    action: string, 
    cost: number
  ): Promise<TokenConsumptionResult> {
    const currentBalance = await this.getUserTokenBalance(userId);
    
    if (currentBalance < cost) {
      // Pause investigation and prompt for token purchase
      await this.pauseInvestigation(sessionId);
      return {
        success: false,
        reason: 'insufficient_balance',
        investigationPaused: true
      };
    }
    
    // Deduct tokens and log consumption
    await this.deductTokens(userId, cost);
    await this.logConsumption(sessionId, action, cost);
    
    return {
      success: true,
      newBalance: currentBalance - cost,
      tokensConsumed: cost
    };
  }
}
```

### Pricing Tiers and Features

```ascii
┌─────────────────────────────────────────────────────────────────────────────┐
│                           SVMAI Token Pricing Tiers                        │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│ 🆓 FREE TIER (0 SVMAI tokens)                                              │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ • 1 basic investigation per day                                         │ │
│ │ • Up to 3 navigation steps                                              │ │
│ │ • Basic templates only                                                  │ │
│ │ • No real-time monitoring                                               │ │
│ │ • Standard support                                                      │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ 💰 BASIC TIER (100 SVMAI tokens)                                           │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ • 10 basic investigations                                               │ │
│ │ • 4 complex investigations                                              │ │
│ │ • 2 deep investigations                                                 │ │
│ │ • All standard templates                                                │ │
│ │ • Basic visualization                                                   │ │
│ │ • Investigation history                                                 │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ 🚀 PREMIUM TIER (500 SVMAI tokens + 20% bonus = 600 SVMAI)                 │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ • Unlimited basic investigations                                        │ │
│ │ • 20 complex investigations                                             │ │
│ │ • 10 deep investigations                                                │ │
│ │ • All premium templates                                                 │ │
│ │ • Advanced visualization                                                │ │
│ │ • Real-time monitoring (500 SVMAI hours)                                │ │
│ │ • Collaborative features                                                │ │
│ │ • Priority support                                                      │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ 🏢 ENTERPRISE TIER (2000 SVMAI tokens + 40% bonus = 2800 SVMAI)            │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ • Unlimited all investigation types                                     │ │
│ │ • Custom templates and workflows                                        │ │
│ │ • Advanced analytics and reporting                                      │ │
│ │ • Unlimited real-time monitoring                                        │ │
│ │ • Team collaboration features                                           │ │
│ │ • API access                                                            │ │
│ │ • Dedicated support                                                     │ │
│ │ • White-label options                                                   │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────────────┘
```

### SVMAI Token Deposit and Payment System

#### Pure SVMAI Token System

```typescript
interface SVMAITokenSystem {
  // Direct SVMAI token usage only
  svmaiWalletBalance: SVMAIWalletBalance;
  
  // Token earning (free methods)
  referralRewards: ReferralSystem;
  communityRewards: CommunityRewardSystem;
  
  // Integration with existing auth
  phantomWalletIntegration: PhantomWalletIntegration;
}

interface SVMAIWalletBalance {
  // Check user's existing SVMAI token balance
  getCurrentBalance: (wallet: PublicKey) => Promise<number>;
  
  // Consume tokens for investigations
  consumeTokens: (wallet: PublicKey, amount: number) => Promise<ConsumptionResult>;
  
  // Track token usage
  getUsageHistory: (wallet: PublicKey) => Promise<UsageRecord[]>;
}

interface PhantomWalletIntegration {
  // Leverage existing wallet connection
  getConnectedWallet: () => Promise<PublicKey>;
  checkSVMAIBalance: (wallet: PublicKey) => Promise<number>;
  
  // Token consumption for investigations
  consumeForInvestigation: (amount: number) => Promise<TransactionSignature>;
  validateSufficientBalance: (requiredAmount: number) => Promise<boolean>;
}

interface InvestigationCost {
  basicInvestigation: 10; // 10 SVMAI tokens
  complexInvestigation: 25; // 25 SVMAI tokens
  deepInvestigation: 50; // 50 SVMAI tokens
  navigationStep: 2; // 2 SVMAI per step
  dataExtraction: 1; // 1 SVMAI per page
  patternAnalysis: 5; // 5 SVMAI per analysis
}
```

#### Phantom Wallet Integration for SVMAI Deposits

```ascii
┌─────────────────────────────────────────────────────────────────────────────┐
│ ╔═══════════════════════════════════════════════════════════════════════════╗ │
│ ║                    💰 Get SVMAI Tokens - Phantom Wallet Required         ║ │
│ ╚═══════════════════════════════════════════════════════════════════════════╝ │
├─────────────────────────────────────────────────────────────────────────────┤
│ ┌─ Wallet Status ─────────────────────────────────────────────────────────┐ │
│ │ 👻 Phantom Wallet: Connected (7xKX...9mN2)                             │ │
│ │ � SAOL Balance: 2.45 SOL                                               │ │
│ │ 💎 SVMAI Balance: 127 tokens                                           │ │
│ │ � ReCquired for AI features and social access                          │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────────────────────────────────┤
│ ┌─ Convert SOL to SVMAI (Instant) ────────────────────────────────────────┐ │
│ │ ⚡ Instant conversion via smart contract                                │ │
│ │                                                                         │ │
│ │ 📊 Current Rate: 1 SOL = 1000 SVMAI                                    │ │
│ │ 🎁 Bonus Tokens: Get extra SVMAI with larger deposits                  │ │
│ │                                                                         │ │
│ │ ┌─ Quick Amounts ─────────────────────────────────────────────────────┐ │ │
│ │ │ ┌───────────┐ ┌───────────┐ ┌───────────┐ ┌───────────┐             │ │ │
│ │ │ │ 0.1 SOL   │ │ 0.5 SOL   │ │ 1.0 SOL   │ │ 2.0 SOL   │             │ │ │
│ │ │ │ 100 SVMAI │ │ 550 SVMAI │ │ 1200 SVMAI│ │ 2800 SVMAI│             │ │ │
│ │ │ │ Basic     │ │ +10% Bonus│ │ +20% Bonus│ │ +40% Bonus│             │ │ │
│ │ │ └───────────┘ └───────────┘ └───────────┘ └───────────┘             │ │ │
│ │ └─────────────────────────────────────────────────────────────────────┘ │ │
│ │                                                                         │ │
│ │ Custom Amount: [0.75] SOL → [825] SVMAI (+75 bonus)                    │ │
│ │ [💰 Convert SOL to SVMAI]                                               │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────────────────────────────────┤
│ ┌─ Convert SPL Tokens to SVMAI ───────────────────────────────────────────┐ │
│ │ 🪙 Use your existing SPL tokens on Solana                              │ │
│ │                                                                         │ │
│ │ Available Tokens:                                                       │ │
│ │ • USDC: 150.00 (Rate: 1 USDC = 100 SVMAI)                             │ │
│ │ • USDT: 75.50 (Rate: 1 USDT = 100 SVMAI)                              │ │
│ │ • RAY: 1,250 (Rate: 1 RAY = 15 SVMAI)                                 │ │
│ │                                                                         │ │
│ │ Convert: [10] USDC → [1000] SVMAI                                      │ │
│ │ [� Conver t SPL Tokens]                                                 │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────────────────────────────────┤
│ ┌─ Earn SVMAI Tokens (FREE) ──────────────────────────────────────────────┐ │
│ │ 🎁 No wallet transactions required - earn through platform activity:   │ │
│ │                                                                         │ │
│ │ • 🔗 Invite Friends: +50 SVMAI per signup (wallet required)            │ │
│ │ • 📝 Daily Investigation: +5 SVMAI (first of the day)                  │ │
│ │ • 🏆 Weekly Streak: +20 SVMAI (7 days in a row)                        │ │
│ │ • 📋 Contribute Template: +25 SVMAI (when approved)                    │ │
│ │ • 🐛 Report Bugs: +100 SVMAI (valid reports)                           │ │
│ │ • 👥 Help Community: +10 SVMAI per helpful review                      │ │
│ │ • 🎯 Complete Profile: +15 SVMAI (one-time bonus)                      │ │
│ │                                                                         │ │
│ │ Today's Progress: 🔥 2/5 earning opportunities completed               │ │
│ │ [🎯 View All Earning Opportunities]                                     │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────────────────────────────────┤
│ ┌─ Transaction History ───────────────────────────────────────────────────┐ │
│ │ 📝 Recent SVMAI Activity:                                               │ │
│ │                                                                         │ │
│ │ • 2h ago: SOL Conversion (+550 SVMAI) ✅ Confirmed                     │ │
│ │ • 1d ago: Investigation Cost (-28 SVMAI) 🔍 DeFi Analysis              │ │
│ │ • 3d ago: Referral Bonus (+50 SVMAI) 🎁 Friend joined                 │ │
│ │ • 5d ago: Daily Bonus (+5 SVMAI) 🏆 Streak: 12 days                   │ │
│ │ • 1w ago: USDC Conversion (+1000 SVMAI) 🔄 SPL Token swap              │ │
│ │                                                        [View All]       │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────────────────────────────────┤
│ ┌─ Access Requirements ───────────────────────────────────────────────────┐ │
│ │ 🔒 SVMAI Token Requirements:                                            │ │
│ │                                                                         │ │
│ │ • AI Sidebar Access: 10 SVMAI minimum balance                          │ │
│ │ • Social Features: 25 SVMAI minimum balance                            │ │
│ │ • Basic Investigation: 10 SVMAI per investigation                       │ │
│ │ • Complex Investigation: 25 SVMAI per investigation                     │ │
│ │ • Deep Investigation: 50 SVMAI per investigation                        │ │
│ │                                                                         │ │
│ │ ✅ Current Status: All features unlocked (127 SVMAI balance)           │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────────────┘
```

#### Smart Contract Integration for SOL Deposits

```typescript
interface SVMAIDepositContract {
  // Solana program for instant SOL → SVMAI conversion
  programId: string;
  
  // Deposit functions
  depositSOL: (amount: number, userWallet: string) => Promise<TransactionSignature>;
  depositSPLToken: (tokenMint: string, amount: number, userWallet: string) => Promise<TransactionSignature>;
  
  // Rate calculation
  getCurrentRate: (inputToken: string) => Promise<ConversionRate>;
  calculateSVMAI: (inputAmount: number, inputToken: string) => Promise<SVMAIAmount>;
  
  // Bonus calculation
  calculateBonus: (svmaiAmount: number) => Promise<BonusAmount>;
}

// Example smart contract interaction
const depositSOL = async (solAmount: number) => {
  // 1. Connect user's Solana wallet
  const wallet = await window.solana.connect();
  
  // 2. Calculate SVMAI amount with bonus
  const baseAmount = solAmount * 1000; // 1 SOL = 1000 SVMAI
  const bonusAmount = calculateBonus(baseAmount);
  const totalSVMAI = baseAmount + bonusAmount;
  
  // 3. Create deposit transaction
  const transaction = new Transaction().add(
    SystemProgram.transfer({
      fromPubkey: wallet.publicKey,
      toPubkey: SVMAI_DEPOSIT_ACCOUNT,
      lamports: solAmount * LAMPORTS_PER_SOL
    })
  );
  
  // 4. Sign and send transaction
  const signature = await wallet.signAndSendTransaction(transaction);
  
  // 5. Credit SVMAI tokens to user account
  await creditSVMAITokens(wallet.publicKey.toString(), totalSVMAI);
  
  return { signature, svmaiCredited: totalSVMAI };
};
```

#### Implementation Priority (Fastest to Deploy)

```typescript
interface DepositImplementationPlan {
  // Phase 1: Immediate (1-2 days)
  phase1: {
    methods: ['solana_wallet', 'earning_system'];
    features: ['SOL deposits', 'referral rewards', 'daily bonuses'];
    complexity: 'low';
    revenue: 'medium';
  };
  
  // Phase 2: Quick (3-5 days)
  phase2: {
    methods: ['credit_card'];
    features: ['Stripe integration', 'instant delivery'];
    complexity: 'medium';
    revenue: 'high';
  };
  
  // Phase 3: Extended (1-2 weeks)
  phase3: {
    methods: ['crypto_deposits', 'bank_transfer'];
    features: ['Multi-crypto support', 'advanced features'];
    complexity: 'high';
    revenue: 'high';
  };
}
```

### Token Purchase and Management UI

```ascii
┌─────────────────────────────────────────────────────────────────────────────┐
│ ╔═══════════════════════════════════════════════════════════════════════════╗ │
│ ║                        💰 SVMAI Token Management                         ║ │
│ ╚═══════════════════════════════════════════════════════════════════════════╝ │
├─────────────────────────────────────────────────────────────────────────────┤
│ ┌─ Current Balance ───────────────────────────────────────────────────────┐ │
│ │ 💎 SVMAI Tokens: 127                                                   │ │
│ │ 📊 Usage This Month: 73 tokens                                         │ │
│ │ 📈 Estimated Remaining: ~5 complex investigations                      │ │
│ │ ⚡ Token Earning Rate: +12 SVMAI this week                             │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────────────────────────────────┤
│ ┌─ Investigation Cost Estimator ──────────────────────────────────────────┐ │
│ │ 🔍 Investigation Type: [Complex DeFi Analysis ▼]                       │ │
│ │ 📊 Estimated Steps: 8-12                                               │ │
│ │ ⏱️  Estimated Duration: 3-5 minutes                                     │ │
│ │ 💰 Estimated Cost: 25-35 SVMAI tokens                                  │ │
│ │                                                                         │ │
│ │ ✅ You have sufficient balance                                          │ │
│ │ [🚀 Start Investigation] [⚙️ Customize]                                 │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────────────────────────────────┤
│ ┌─ Token Package Options ─────────────────────────────────────────────────┐ │
│ │ 💎 Available Token Packages:                                           │ │
│ │                                                                         │ │
│ │ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐         │ │
│ │ │ 100 SVMAI   │ │ 500 SVMAI   │ │ 1000 SVMAI  │ │ 2000 SVMAI  │         │ │
│ │ │ Basic Pack  │ │ Premium     │ │ Pro Pack    │ │ Enterprise  │         │ │
│ │ │             │ │ +100 Bonus  │ │ +300 Bonus  │ │ +800 Bonus  │         │ │
│ │ │ = 100 Total │ │ = 600 Total │ │ = 1300 Total│ │ = 2800 Total│         │ │
│ │ └─────────────┘ └─────────────┘ └─────────────┘ └─────────────┘         │ │
│ │                                                                         │ │
│ │ 🎯 Recommended: Premium (600 SVMAI total) for your usage pattern       │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────────────────────────────────┤
│ ┌─ Token Earning Opportunities ───────────────────────────────────────────┐ │
│ │ 🎁 Earn More SVMAI Tokens:                                             │ │
│ │                                                                         │ │
│ │ • 🔗 Refer Friends: +50 SVMAI per successful referral                  │ │
│ │ • 📝 Contribute Templates: +25 SVMAI per validated template            │ │
│ │ • 🏆 Daily Investigation: +5 SVMAI for first investigation daily       │ │
│ │ • 🔥 Weekly Streak: +20 SVMAI for 7-day investigation streak           │ │
│ │ • 🐛 Report Bugs: +100 SVMAI per valid bug report                      │ │
│ │ • 👥 Community Help: +10 SVMAI per helpful review                      │ │
│ │                                                                         │ │
│ │ [🎯 View All Earning Opportunities]                                     │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────────────────────────────────┤
│ ┌─ Usage Analytics ───────────────────────────────────────────────────────┐ │
│ │ 📊 Token Consumption Breakdown (Last 30 Days):                          │ │
│ │                                                                         │ │
│ │ Navigation Steps     ████████████░░░░ 65% (47 tokens)                   │ │
│ │ Pattern Analysis     ██████░░░░░░░░░░ 20% (15 tokens)                   │ │
│ │ Data Extraction      ████░░░░░░░░░░░░ 10% (7 tokens)                    │ │
│ │ Premium Features     ██░░░░░░░░░░░░░░ 5% (4 tokens)                     │ │
│ │                                                                         │ │
│ │ ! Most Used: DeFi Portfolio Analysis (12 investigations)                │ │
│ │ ? Suggestion: Consider Premium package for 20% bonus tokens             │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────────────────────────────────┤
│ ┌─ Recent Transactions ───────────────────────────────────────────────────┐ │
│ │ 📝 Transaction History:                                                 │ │
│ │                                                                         │ │
│ │ • 2h ago: DeFi Risk Analysis (-28 SVMAI)                                │ │
│ │ • 1d ago: Wallet Connection Map (-15 SVMAI)                             │ │
│ │ • 2d ago: Premium Package (+600 SVMAI)                                  │ │
│ │ • 3d ago: Suspicious Activity Check (-22 SVMAI)                         │ │
│ │ • 4d ago: Daily Investigation Bonus (+5 SVMAI)                          │ │
│ │ • 5d ago: Template Contribution (+25 SVMAI)                             │ │
│ │                                                        [View All]       │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Revenue Optimization Features

```typescript
interface RevenueOptimization {
  // Dynamic pricing based on demand
  dynamicPricing: DynamicPricingEngine;
  
  // Usage-based recommendations
  usageAnalyzer: UsageAnalyzer;
  
  // Subscription upselling
  subscriptionManager: SubscriptionManager;
  
  // Token earning opportunities
  tokenRewards: TokenRewardSystem;
}

interface DynamicPricingEngine {
  adjustPricing(demand: number, supply: number): PricingAdjustment;
  getPeakHourPricing(): PricingMultiplier;
  getVolumeDiscounts(usage: number): DiscountRate;
}

interface TokenRewardSystem {
  // Earn tokens through platform engagement
  referralRewards: number;        // 50 SVMAI per successful referral
  contentContribution: number;    // 25 SVMAI per validated template
  communityModeration: number;    // 10 SVMAI per helpful review
  bugReporting: number;          // 100 SVMAI per valid bug report
  
  // Daily/weekly challenges
  dailyInvestigationBonus: number;  // 5 SVMAI for first investigation
  weeklyStreakBonus: number;        // 20 SVMAI for 7-day streak
  monthlyChallenge: number;         // 200 SVMAI for monthly goals
}
```

### Integration with Existing Systems

```typescript
interface SVMAIIntegration {
  // User profile integration
  userProfile: {
    tokenBalance: number;
    subscriptionTier: 'free' | 'basic' | 'premium' | 'enterprise';
    usageHistory: TokenUsageRecord[];
    preferences: TokenPreferences;
  };
  
  // Payment processing
  paymentGateway: {
    processPurchase: (amount: number, tokens: number) => Promise<PaymentResult>;
    handleSubscription: (tier: string) => Promise<SubscriptionResult>;
    processRefund: (transactionId: string) => Promise<RefundResult>;
  };
  
  // Analytics and reporting
  analytics: {
    trackTokenUsage: (userId: string, action: string, cost: number) => void;
    generateUsageReport: (userId: string, period: string) => UsageReport;
    calculateROI: (userId: string) => ROIMetrics;
  };
}
```

## Monitoring and Analytics

### Performance Metrics
- Investigation completion rates
- Average investigation duration
- Error rates by navigation type
- User satisfaction scores
- Template usage statistics
- **Token consumption patterns**
- **Revenue per user metrics**
- **Subscription conversion rates**

### System Health Monitoring
- Resource utilization tracking
- Error rate monitoring
- Response time tracking
- Cache hit rates
- Queue depth monitoring
- **Token transaction processing**
- **Payment gateway health**

### User Behavior Analytics
- Most popular investigation types
- Template effectiveness ratings
- User interaction patterns
- Abandonment points in investigations
- Feature adoption rates
- **Token spending behavior**
- **Price sensitivity analysis**
- **Upselling opportunity identification**