# Wallet Path Finding - Design Document

## Overview

The Wallet Path Finding system analyzes connections between Solana wallet addresses by examining transaction histories, token transfers, and program interactions. The system uses graph algorithms to discover direct and indirect relationships, visualizes connections in an interactive interface, and provides detailed analytics about wallet relationships.

## Architecture

### System Components

```mermaid
graph TB
    UI[Path Finding UI] --> API[Path Finding API]
    API --> Cache[Path Cache]
    API --> Analyzer[Connection Analyzer]
    Analyzer --> Solana[Solana RPC]
    Analyzer --> Graph[Graph Builder]
    Graph --> Viz[Graph Visualizer]
    Cache --> DB[(Cache Database)]
```

### Data Flow

1. **Input Validation**: Validate wallet addresses and sanitize inputs
2. **Cache Check**: Check if path analysis exists in cache
3. **Data Collection**: Fetch transaction histories from Solana RPC
4. **Connection Analysis**: Analyze transactions to identify connections
5. **Graph Construction**: Build graph representation of connections
6. **Path Finding**: Use BFS/DFS algorithms to find paths
7. **Visualization**: Render interactive graph with D3.js/Cytoscape
8. **Caching**: Store results for future queries

## Components and Interfaces

### Frontend Components

#### `WalletPathFinder`
```typescript
interface WalletPathFinderProps {
  initialSource?: string;
  initialTarget?: string;
  onAnalysisComplete?: (results: PathAnalysisResults) => void;
}

interface PathAnalysisResults {
  paths: WalletPath[];
  graph: ConnectionGraph;
  metrics: ConnectionMetrics;
  executionTime: number;
}
```

#### `ConnectionGraph`
```typescript
interface ConnectionGraphProps {
  nodes: GraphNode[];
  edges: GraphEdge[];
  onNodeClick?: (node: GraphNode) => void;
  onEdgeClick?: (edge: GraphEdge) => void;
  filters?: GraphFilters;
}

interface GraphNode {
  id: string;
  address: string;
  label?: string;
  balance: number;
  transactionCount: number;
  tokenCount: number;
  type: 'source' | 'target' | 'intermediate';
}

interface GraphEdge {
  source: string;
  target: string;
  weight: number;
  transactionCount: number;
  totalVolume: number;
  firstTransaction: Date;
  lastTransaction: Date;
  tokens: string[];
}
```

#### `PathAnalysisPanel`
```typescript
interface PathAnalysisPanelProps {
  paths: WalletPath[];
  selectedPath?: number;
  onPathSelect: (pathIndex: number) => void;
  onExport: (format: ExportFormat) => void;
}

interface WalletPath {
  nodes: string[];
  totalHops: number;
  connectionStrength: number;
  totalVolume: number;
  pathType: 'direct' | 'token_transfer' | 'program_interaction';
  transactions: PathTransaction[];
}
```

### Backend Services

#### `PathFindingService`
```typescript
class PathFindingService {
  async findPaths(
    source: string,
    target: string,
    options: PathFindingOptions
  ): Promise<PathAnalysisResults>;
  
  async getConnectionStrength(
    address1: string,
    address2: string
  ): Promise<ConnectionStrength>;
  
  async getCachedAnalysis(
    source: string,
    target: string
  ): Promise<PathAnalysisResults | null>;
}

interface PathFindingOptions {
  maxDepth: number;
  minTransactionAmount: number;
  timeRange?: DateRange;
  includeTokenTransfers: boolean;
  includeProgramInteractions: boolean;
}
```

#### `ConnectionAnalyzer`
```typescript
class ConnectionAnalyzer {
  async analyzeDirectConnections(
    address1: string,
    address2: string
  ): Promise<DirectConnection[]>;
  
  async analyzeTokenConnections(
    address1: string,
    address2: string
  ): Promise<TokenConnection[]>;
  
  async analyzeProgramConnections(
    address1: string,
    address2: string
  ): Promise<ProgramConnection[]>;
  
  async calculateConnectionStrength(
    connections: Connection[]
  ): Promise<number>;
}
```

#### `GraphBuilder`
```typescript
class GraphBuilder {
  buildGraph(connections: Connection[]): ConnectionGraph;
  optimizeGraph(graph: ConnectionGraph): ConnectionGraph;
  clusterNodes(graph: ConnectionGraph, threshold: number): ConnectionGraph;
  calculateLayout(graph: ConnectionGraph): LayoutedGraph;
}
```

## Data Models

### Connection Types

```typescript
interface DirectConnection {
  type: 'direct_transfer';
  fromAddress: string;
  toAddress: string;
  transactions: TransactionSummary[];
  totalVolume: number;
  frequency: number;
}

interface TokenConnection {
  type: 'token_transfer';
  fromAddress: string;
  toAddress: string;
  tokenMint: string;
  tokenSymbol: string;
  transfers: TokenTransfer[];
  totalAmount: number;
}

interface ProgramConnection {
  type: 'program_interaction';
  address1: string;
  address2: string;
  programId: string;
  programName?: string;
  interactions: ProgramInteraction[];
  sharedInstructions: string[];
}
```

### Graph Data Structure

```typescript
interface ConnectionGraph {
  nodes: Map<string, GraphNode>;
  edges: Map<string, GraphEdge>;
  metadata: GraphMetadata;
}

interface GraphMetadata {
  totalNodes: number;
  totalEdges: number;
  maxDepth: number;
  analysisTimestamp: Date;
  sourceAddress: string;
  targetAddress: string;
}
```

## Error Handling

### Input Validation Errors
- Invalid wallet address format
- Same source and target address
- Address not found on blockchain
- Insufficient transaction history

### Analysis Errors
- RPC connection failures
- Timeout during analysis
- Memory limitations for large graphs
- Cache corruption or unavailability

### Visualization Errors
- Graph rendering failures
- Performance issues with large datasets
- Browser compatibility issues
- Export functionality failures

## Testing Strategy

### Unit Tests
- Address validation functions
- Connection analysis algorithms
- Graph building and optimization
- Path finding algorithms
- Caching mechanisms

### Integration Tests
- End-to-end path finding workflow
- RPC integration and error handling
- Cache integration and performance
- Export functionality
- Real-time graph updates

### Performance Tests
- Large graph rendering (1000+ nodes)
- Complex path finding (6+ degrees)
- Concurrent analysis requests
- Memory usage optimization
- Cache hit/miss ratios

### User Experience Tests
- Interactive graph manipulation
- Filter application and performance
- Export functionality across formats
- Mobile responsiveness
- Accessibility compliance

## Security Considerations

### Input Sanitization
- Validate all wallet addresses
- Sanitize user inputs to prevent injection
- Rate limit analysis requests
- Implement request size limits

### Data Privacy
- No storage of sensitive transaction data
- Anonymize exported data options
- Secure caching mechanisms
- Audit trail for analysis requests

### Performance Security
- Prevent DoS through complex queries
- Implement circuit breakers
- Monitor resource usage
- Graceful degradation under load