# Transaction Explorer Enhancements - Design Document

## Overview

The enhanced Transaction Explorer provides comprehensive transaction analysis through detailed instruction parsing, account change visualization, AI-powered explanations, and related transaction discovery. The system transforms raw blockchain data into understandable insights for users of all technical levels.

## Architecture

### System Components

```mermaid
graph TB
    UI[Transaction UI] --> Parser[Instruction Parser]
    UI --> Changes[Account Changes Analyzer]
    UI --> AI[AI Explanation Engine]
    UI --> Related[Related Tx Finder]
    UI --> Graph[Transaction Graph]
    
    Parser --> Programs[Program Registry]
    Changes --> Diff[State Diff Engine]
    AI --> LLM[Language Model]
    Related --> Cache[Transaction Cache]
    Graph --> Viz[Graph Visualizer]
```

### Enhanced Transaction Flow

1. **Transaction Loading**: Fetch transaction data with full account states
2. **Instruction Parsing**: Parse and categorize all instructions
3. **Account Analysis**: Calculate before/after state changes
4. **AI Analysis**: Generate natural language explanation
5. **Related Discovery**: Find connected transactions
6. **Visualization**: Render interactive transaction graph
7. **Metrics Calculation**: Compute performance and cost metrics

## Components and Interfaces

### Frontend Components

#### `EnhancedTransactionView`
```typescript
interface EnhancedTransactionViewProps {
  signature: string;
  transaction?: ParsedTransaction;
  onRelatedTransactionClick?: (signature: string) => void;
}

interface ParsedTransaction {
  signature: string;
  slot: number;
  blockTime: number;
  instructions: ParsedInstruction[];
  accountChanges: AccountChange[];
  aiExplanation?: AIExplanation;
  relatedTransactions: RelatedTransaction[];
  metrics: TransactionMetrics;
}
```

#### `InstructionBreakdown`
```typescript
interface InstructionBreakdownProps {
  instructions: ParsedInstruction[];
  onInstructionClick?: (instruction: ParsedInstruction) => void;
}

interface ParsedInstruction {
  programId: string;
  programName?: string;
  instructionType: string;
  description: string;
  accounts: InstructionAccount[];
  data: InstructionData;
  innerInstructions?: ParsedInstruction[];
  computeUnits: number;
}

interface InstructionAccount {
  pubkey: string;
  isSigner: boolean;
  isWritable: boolean;
  role: 'payer' | 'recipient' | 'authority' | 'program' | 'system';
}
```

#### `AccountChangesPanel`
```typescript
interface AccountChangesPanelProps {
  changes: AccountChange[];
  onAccountClick?: (address: string) => void;
}

interface AccountChange {
  address: string;
  before: AccountState;
  after: AccountState;
  lamportsDiff: number;
  tokenChanges: TokenChange[];
  dataChanges?: DataChange;
}

interface AccountState {
  lamports: number;
  owner: string;
  executable: boolean;
  rentEpoch: number;
  data?: string;
}

interface TokenChange {
  mint: string;
  symbol?: string;
  beforeAmount: number;
  afterAmount: number;
  difference: number;
}
```

#### `AIExplanationPanel`
```typescript
interface AIExplanationPanelProps {
  explanation: AIExplanation;
  isLoading: boolean;
  onRegenerateExplanation?: () => void;
}

interface AIExplanation {
  summary: string;
  mainAction: string;
  secondaryEffects: string[];
  riskAssessment: RiskAssessment;
  technicalDetails: TechnicalDetail[];
  confidence: number;
}

interface RiskAssessment {
  level: 'low' | 'medium' | 'high';
  factors: string[];
  recommendations: string[];
}
```

#### `RelatedTransactionsPanel`
```typescript
interface RelatedTransactionsPanelProps {
  relatedTransactions: RelatedTransaction[];
  onTransactionClick: (signature: string) => void;
  isLoading: boolean;
}

interface RelatedTransaction {
  signature: string;
  relationship: RelationshipType;
  strength: number;
  description: string;
  timestamp: number;
  accounts: string[];
}

type RelationshipType = 
  | 'same_accounts'
  | 'same_program'
  | 'temporal_proximity'
  | 'token_flow'
  | 'authority_chain';
```

#### `TransactionGraph`
```typescript
interface TransactionGraphProps {
  transaction: ParsedTransaction;
  showRelated?: boolean;
  onNodeClick?: (address: string) => void;
  onEdgeClick?: (transfer: Transfer) => void;
}

interface GraphNode {
  id: string;
  type: 'account' | 'program' | 'token';
  label: string;
  balance?: number;
  isWritable: boolean;
  isSigner: boolean;
}

interface GraphEdge {
  source: string;
  target: string;
  type: 'transfer' | 'instruction' | 'authority';
  amount?: number;
  label: string;
}
```

### Backend Services

#### `InstructionParserService`
```typescript
class InstructionParserService {
  async parseInstructions(
    transaction: Transaction
  ): Promise<ParsedInstruction[]>;
  
  async getInstructionDescription(
    programId: string,
    instructionData: Buffer
  ): Promise<string>;
  
  async identifyInstructionType(
    programId: string,
    data: Buffer
  ): Promise<string>;
}
```

#### `AccountChangesAnalyzer`
```typescript
class AccountChangesAnalyzer {
  async analyzeAccountChanges(
    transaction: Transaction,
    preBalances: number[],
    postBalances: number[]
  ): Promise<AccountChange[]>;
  
  async getTokenChanges(
    address: string,
    beforeSlot: number,
    afterSlot: number
  ): Promise<TokenChange[]>;
  
  async analyzeDataChanges(
    address: string,
    beforeData: Buffer,
    afterData: Buffer
  ): Promise<DataChange>;
}
```

#### `AITransactionAnalyzer`
```typescript
class AITransactionAnalyzer {
  async generateExplanation(
    transaction: ParsedTransaction
  ): Promise<AIExplanation>;
  
  async assessRisk(
    transaction: ParsedTransaction
  ): Promise<RiskAssessment>;
  
  async identifyMainAction(
    instructions: ParsedInstruction[]
  ): Promise<string>;
}
```

#### `RelatedTransactionFinder`
```typescript
class RelatedTransactionFinder {
  async findRelatedTransactions(
    signature: string,
    options: RelatedTxOptions
  ): Promise<RelatedTransaction[]>;
  
  async findByAccountInteractions(
    accounts: string[],
    timeWindow: number
  ): Promise<RelatedTransaction[]>;
  
  async findByProgramUsage(
    programId: string,
    timeWindow: number
  ): Promise<RelatedTransaction[]>;
}
```

## Data Models

### Enhanced Transaction Data

```typescript
interface TransactionMetrics {
  totalFee: number;
  computeUnitsUsed: number;
  computeUnitsRequested: number;
  efficiency: number;
  size: number;
  accountsModified: number;
  instructionCount: number;
  innerInstructionCount: number;
  priorityFee?: number;
  baseFee: number;
  feePerComputeUnit: number;
}

interface DataChange {
  type: 'account_data' | 'token_account' | 'program_data';
  beforeHash: string;
  afterHash: string;
  sizeChange: number;
  significantChanges: string[];
  fieldChanges?: FieldChange[];
}

interface FieldChange {
  field: string;
  beforeValue: any;
  afterValue: any;
  significance: 'high' | 'medium' | 'low';
}

interface TechnicalDetail {
  category: 'instruction' | 'account' | 'program' | 'token';
  title: string;
  description: string;
  importance: 'high' | 'medium' | 'low';
  data?: any;
}

interface InstructionData {
  raw: Buffer;
  parsed?: any;
  discriminator?: string;
  args?: Record<string, any>;
}
```

### Program Registry

```typescript
interface ProgramInfo {
  programId: string;
  name: string;
  description: string;
  category: string;
  instructions: InstructionDefinition[];
  website?: string;
  documentation?: string;
}

interface InstructionDefinition {
  discriminator: string;
  name: string;
  description: string;
  accounts: AccountDefinition[];
  args: ArgumentDefinition[];
}
```

## Error Handling

### Transaction Loading Errors
- Transaction not found or invalid signature
- RPC timeout or connection issues
- Incomplete transaction data
- Historical transaction limitations

### Parsing Errors
- Unknown program instructions
- Malformed instruction data
- Missing account information
- Incomplete state data

### AI Analysis Errors
- LLM service unavailability
- Context too large for analysis
- Analysis timeout
- Confidence threshold not met

## Testing Strategy

### Unit Tests
- Instruction parsing accuracy
- Account change calculations
- AI explanation generation
- Related transaction discovery
- Graph construction algorithms

### Integration Tests
- End-to-end transaction analysis
- AI service integration
- RPC data fetching and parsing
- Graph visualization rendering
- Related transaction accuracy

### Performance Tests
- Large transaction parsing
- Complex instruction analysis
- AI explanation generation time
- Graph rendering performance
- Related transaction search speed

### User Experience Tests
- Transaction explanation clarity
- Graph interaction usability
- Mobile responsiveness
- Accessibility compliance
- Error state handling