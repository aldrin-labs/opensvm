# OpenSVM Project Structure

## Root Directory Organization

```
opensvm/
├── app/                  # Next.js App Router (pages and API routes)
├── components/           # React components (reusable UI)
├── lib/                  # Core libraries and utilities
├── types/                # TypeScript type definitions
├── utils/                # Utility functions
├── public/               # Static assets
├── docs/                 # Documentation
├── __tests__/            # Unit tests
├── e2e/                  # End-to-end tests
└── scripts/              # Build and utility scripts
```

## App Directory (Next.js App Router)

```
app/
├── api/                  # API routes
│   ├── account-*/        # Account-related endpoints
│   ├── ai-response/      # AI assistant endpoints
│   ├── analytics/        # Analytics endpoints
│   ├── anomaly/          # Anomaly detection endpoints
│   ├── auth/             # Authentication endpoints
│   ├── block*/           # Block data endpoints
│   ├── chat/             # Chat/AI endpoints
│   ├── nft*/             # NFT-related endpoints
│   ├── search/           # Search endpoints
│   ├── solana-*/         # Solana integration endpoints
│   ├── sse-*/            # Server-sent events endpoints
│   ├── stream/           # Streaming endpoints
│   ├── token*/           # Token-related endpoints
│   ├── transaction/      # Transaction endpoints
│   └── user-*/           # User-related endpoints
├── account/[address]/    # Account explorer pages
├── block/[slot]/         # Block explorer pages
├── tx/[signature]/       # Transaction explorer pages
├── token/[mint]/         # Token explorer pages
├── program/[address]/    # Program explorer pages
├── analytics/            # Analytics dashboard pages
├── chat/                 # AI chat interface
├── monitoring/           # Network monitoring pages
├── wallet-path-finding/  # Wallet connection analysis
├── components/           # Page-specific components
├── providers/            # React context providers
├── styles/               # Page-specific styles
└── layout.tsx            # Root layout component
```

## Components Directory

```
components/
├── ui/                   # Base UI components (buttons, inputs, etc.)
├── ai/                   # AI-related components
│   ├── actions/          # AI action components
│   ├── capabilities/     # AI capability components
│   ├── core/             # Core AI components
│   ├── hooks/            # AI-related hooks
│   ├── layouts/          # AI interface layouts
│   ├── modals/           # AI modal components
│   └── types/            # AI type definitions
├── analytics/            # Analytics visualization components
├── blockchain-visualizations/ # Blockchain data visualizations
├── referrals/            # Referral system components
├── search/               # Search-related components
├── solana/               # Solana-specific components
├── transaction-graph/    # Transaction visualization components
├── user-history/         # User history components
└── [ComponentName].tsx   # Individual components
```

## Lib Directory (Core Logic)

```
lib/
├── ai/                   # AI functionality
├── cache/                # Caching implementations
├── constants/            # Application constants
├── data-cache/           # Data caching utilities
├── data-sources/         # External data source integrations
├── hooks/                # Custom React hooks
├── sacred/               # Core business logic
├── server/               # Server-side utilities
├── types/                # Shared type definitions
├── utils/                # General utilities
├── validation/           # Input validation schemas
├── workers/              # Web workers
├── solana.ts             # Solana blockchain utilities
├── transaction-parser.ts # Transaction parsing logic
├── auth.ts               # Authentication utilities
├── cache.ts              # Caching layer
└── utils.ts              # General utility functions
```

## File Naming Conventions

### Components
- **PascalCase** for component files: `TransactionTable.tsx`
- **camelCase** for utility components: `vtable.tsx`
- **kebab-case** for directories: `transaction-graph/`

### API Routes
- **kebab-case** for route directories: `account-stats/`
- **camelCase** for dynamic routes: `[address]/`

### Utilities and Libraries
- **kebab-case** for multi-word files: `solana-connection.ts`
- **camelCase** for single concept files: `utils.ts`

## Import Path Conventions

### Absolute Imports
Use `@/` prefix for all internal imports:
```typescript
import { TransactionTable } from '@/components/TransactionTable';
import { parseTransaction } from '@/lib/transaction-parser';
import { SolanaAgent } from '@/lib/ai/core/agent';
```

### Relative Imports
Avoid relative imports except for closely related files in the same directory.

## Component Organization Patterns

### Feature-Based Grouping
Components are organized by feature area (ai/, analytics/, solana/) rather than by type.

### Barrel Exports
Use index.ts files for clean imports:
```typescript
// components/ai/index.ts
export { AIAssistant } from './AIAssistant';
export { AIChatDialog } from './AIChatDialog';
```

### Co-location
Keep related files close together:
```
components/ai/
├── AIAssistant.tsx
├── AIAssistant.test.tsx
├── AIAssistant.module.css
└── hooks/
    └── useAIAssistant.ts
```

## Testing Structure

### Unit Tests
- Located alongside source files with `.test.ts` suffix
- Use Jest with React Testing Library
- Focus on component behavior and utility functions

### E2E Tests
- Located in `e2e/` directory
- Use Playwright for browser automation
- Test critical user flows and integrations

### Test Utilities
- Shared test utilities in `__tests__/` directory
- Mock data and helper functions for consistent testing

## Configuration Files

### Root Level
- `package.json`: Dependencies and scripts
- `tsconfig.json`: TypeScript configuration
- `tailwind.config.ts`: Tailwind CSS configuration
- `next.config.mjs`: Next.js configuration
- `.eslintrc.json`: ESLint rules
- `.env.example`: Environment variable template

### Build and Deployment
- `Dockerfile`: Container configuration
- `netlify.toml`: Netlify deployment settings
- `scripts/`: Build optimization and utility scripts