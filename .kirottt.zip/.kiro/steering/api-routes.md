# OpenSVM API Routes Documentation

## API Architecture

All API routes follow RESTful conventions and are organized under `/api/` with consistent response formats, error handling, and authentication patterns.

## Core API Endpoints

### Account APIs (`/api/account-*`)

#### `/api/account-stats/[address]`
- **Purpose**: Get comprehensive account statistics
- **Method**: GET
- **Response**: Account balance, transaction count, token holdings summary
- **Caching**: 30 seconds for active accounts, 5 minutes for inactive

#### `/api/account-token-stats/[address]`
- **Purpose**: Get detailed token holdings and statistics
- **Method**: GET
- **Response**: List of tokens with balances, USD values, percentage allocations
- **Features**: Token metadata resolution, price data integration

#### `/api/account-transactions/[address]`
- **Purpose**: Paginated transaction history for an account
- **Method**: GET
- **Query Params**: `page`, `limit`, `before`, `until`
- **Response**: Transactions with parsed instructions and metadata

#### `/api/account-transfers/[address]`
- **Purpose**: Token transfer history for an account
- **Method**: GET
- **Response**: Filtered transfers with token metadata and USD values

### Transaction APIs (`/api/transaction/`)

#### `/api/transaction/[signature]`
- **Purpose**: Get detailed transaction information
- **Method**: GET
- **Response**: Complete transaction data with parsed instructions
- **Features**: Instruction parsing, account change analysis, fee calculation

#### `/api/analyze-transaction`
- **Purpose**: AI-powered transaction analysis
- **Method**: POST
- **Body**: `{ signature: string }`
- **Response**: Natural language explanation of transaction purpose and effects

### Block APIs (`/api/block*`)

#### `/api/block`
- **Purpose**: Get block information by slot
- **Method**: GET
- **Query Params**: `slot`
- **Response**: Block metadata, transactions, validator info

#### `/api/blocks/[slot]`
- **Purpose**: Get specific block details
- **Method**: GET
- **Response**: Detailed block information with transaction list

### Token APIs (`/api/token*`)

#### `/api/token/[mint]`
- **Purpose**: Get token metadata and statistics
- **Method**: GET
- **Response**: Token info, supply, holder count, price data

#### `/api/token-stats/[account]`
- **Purpose**: Get token statistics for a specific account
- **Method**: GET
- **Response**: Token balances and transaction history

### Search APIs (`/api/search*`)

#### `/api/search`
- **Purpose**: Universal search across all blockchain entities
- **Method**: GET
- **Query Params**: `q` (query), `type` (filter), `limit`
- **Response**: Categorized search results

#### `/api/search/suggestions`
- **Purpose**: Auto-complete suggestions for search queries
- **Method**: GET
- **Query Params**: `q` (partial query)
- **Response**: Suggested completions with entity types

#### `/api/search/accounts`
- **Purpose**: Search specifically for accounts
- **Method**: GET
- **Response**: Account matches with metadata

### AI APIs (`/api/ai-*`, `/api/chat`)

#### `/api/ai-response`
- **Purpose**: Process AI queries about blockchain data
- **Method**: POST
- **Body**: `{ message: string, context?: object }`
- **Response**: AI-generated response with data analysis

#### `/api/chat`
- **Purpose**: Conversational AI interface
- **Method**: POST
- **Body**: `{ messages: ChatMessage[] }`
- **Response**: Streaming AI responses

### Analytics APIs (`/api/analytics/`)

#### `/api/analytics/overview`
- **Purpose**: High-level network statistics
- **Method**: GET
- **Response**: Network metrics, validator count, TPS, epoch info

#### `/api/analytics/defi`
- **Purpose**: DeFi protocol analytics
- **Method**: GET
- **Response**: TVL data, protocol metrics, yield information

#### `/api/analytics/tokens`
- **Purpose**: Token market analytics
- **Method**: GET
- **Response**: Token prices, volume, market cap data

### Real-time APIs (`/api/sse-*`, `/api/stream`)

#### `/api/sse-events/feed`
- **Purpose**: Server-sent events for real-time updates
- **Method**: GET (EventSource)
- **Response**: Streaming blockchain events

#### `/api/sse-alerts`
- **Purpose**: Real-time security alerts
- **Method**: GET (EventSource)
- **Response**: Anomaly detection alerts

#### `/api/stream`
- **Purpose**: WebSocket-like streaming for live data
- **Method**: GET
- **Response**: Continuous data stream

### Utility APIs

#### `/api/solana-proxy`
- **Purpose**: Proxy requests to Solana RPC with load balancing
- **Method**: POST
- **Body**: Standard Solana RPC request
- **Response**: Proxied RPC response with error handling

#### `/api/solana-rpc`
- **Purpose**: Direct Solana RPC interface
- **Method**: POST
- **Features**: Request validation, response caching, rate limiting

#### `/api/check-account-type`
- **Purpose**: Determine account type (wallet, program, token account)
- **Method**: GET
- **Query Params**: `address`
- **Response**: Account type classification

### Program APIs (`/api/program/`)

#### `/api/program/[address]`
- **Purpose**: Get program information and statistics
- **Method**: GET
- **Response**: Program metadata, instruction usage, account ownership

### Validator APIs (`/api/validator/`)

#### `/api/validator/[address]`
- **Purpose**: Get validator information and performance
- **Method**: GET
- **Response**: Validator stats, commission, stake, performance history

### NFT APIs (`/api/nft*`)

#### `/api/nft-collections`
- **Purpose**: Get NFT collection data
- **Method**: GET
- **Response**: Collection metadata, floor prices, volume

#### `/api/nft-collections/trending`
- **Purpose**: Get trending NFT collections
- **Method**: GET
- **Response**: Collections sorted by activity and volume

### User & Social APIs (`/api/user-*`)

#### `/api/user-profile/[walletAddress]`
- **Purpose**: Get user profile information
- **Method**: GET
- **Response**: User preferences, activity summary, social connections

#### `/api/user-history/[walletAddress]`
- **Purpose**: Get user's interaction history
- **Method**: GET
- **Response**: Page views, searches, bookmarks

#### `/api/user-social/follow`
- **Purpose**: Follow/unfollow wallet addresses
- **Method**: POST
- **Body**: `{ target: string, action: 'follow' | 'unfollow' }`

### Anomaly Detection APIs (`/api/anomaly/`)

#### `/api/anomaly`
- **Purpose**: Report and query anomalies
- **Method**: GET/POST
- **Response**: Anomaly reports, risk scores, related transactions

#### `/api/anomaly/similar`
- **Purpose**: Find similar anomalous patterns
- **Method**: GET
- **Response**: Related anomalies and pattern analysis

### Monetization APIs (`/api/referrals/`, `/api/share/`)

#### `/api/referrals/balance`
- **Purpose**: Get referral earnings balance
- **Method**: GET
- **Response**: Earnings, pending rewards, referral stats

#### `/api/share/generate`
- **Purpose**: Generate shareable links with tracking
- **Method**: POST
- **Body**: `{ url: string, metadata: object }`
- **Response**: Shareable link with tracking code

## API Response Patterns

### Success Response
```typescript
{
  success: true,
  data: T,
  timestamp: number,
  cached?: boolean
}
```

### Error Response
```typescript
{
  success: false,
  error: {
    code: string,
    message: string,
    details?: object
  },
  timestamp: number
}
```

### Paginated Response
```typescript
{
  success: true,
  data: T[],
  pagination: {
    page: number,
    limit: number,
    total: number,
    hasNext: boolean,
    hasPrev: boolean
  },
  timestamp: number
}
```

## Authentication & Rate Limiting

### API Keys
- Optional API keys for higher rate limits
- JWT tokens for authenticated features
- Wallet signature verification for user actions

### Rate Limiting
- Anonymous: 100 requests/minute
- Authenticated: 1000 requests/minute
- Premium: 10000 requests/minute

### CORS Policy
- Allowed origins: configured domains
- Credentials: included for authenticated requests
- Methods: GET, POST, OPTIONS

## Caching Strategy

### Cache Levels
1. **Browser Cache**: Static responses (5 minutes)
2. **CDN Cache**: Public data (1 minute)
3. **Application Cache**: Computed results (30 seconds)
4. **Database Cache**: Query results (10 seconds)

### Cache Keys
- Include relevant parameters in cache keys
- Invalidate on blockchain state changes
- Use cache tags for bulk invalidation

## Error Handling

### Common Error Codes
- `INVALID_ADDRESS`: Malformed Solana address
- `ACCOUNT_NOT_FOUND`: Account doesn't exist
- `TRANSACTION_NOT_FOUND`: Transaction not found
- `RATE_LIMIT_EXCEEDED`: Too many requests
- `INTERNAL_ERROR`: Server-side error
- `NETWORK_ERROR`: Solana RPC error

### Error Recovery
- Automatic retries for transient errors
- Fallback to alternative RPC endpoints
- Graceful degradation for non-critical features