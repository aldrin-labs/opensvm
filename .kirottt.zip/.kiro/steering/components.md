# OpenSVM Components Documentation

## Component Architecture

Components are organized by feature area and follow consistent patterns for props, state management, error handling, and accessibility.

## Core UI Components (`/components/ui/`)

### Base Components
- **Button**: Primary, secondary, destructive, ghost variants with loading states
- **Input**: Text inputs with validation states and icons
- **Card**: Container component with header, content, and footer sections
- **Table**: Data tables with sorting, pagination, and selection
- **Dialog**: Modal dialogs with backdrop and focus management
- **Dropdown**: Dropdown menus with keyboard navigation
- **Progress**: Progress bars and loading indicators
- **Avatar**: User avatars with fallback initials
- **Badge**: Status badges and labels
- **Tooltip**: Contextual help tooltips

### Form Components
- **Form**: Form wrapper with validation and error handling
- **FormField**: Individual form fields with labels and validation
- **Select**: Dropdown select with search and multi-select
- **Checkbox**: Checkboxes with indeterminate state
- **RadioGroup**: Radio button groups
- **Switch**: Toggle switches
- **Slider**: Range sliders with multiple handles

## Blockchain-Specific Components

### Account Components (`/components/account/`)

#### `AccountInfo`
- **Purpose**: Display basic account information
- **Props**: `address`, `isSystemProgram`, `parsedOwner`
- **Features**: Address validation, copy functionality, QR code generation
- **Usage**: Account detail pages, search results

#### `AccountOverview`
- **Purpose**: Account balance and token holdings summary
- **Props**: `address`, `solBalance`, `tokenAccounts`, `isSystemProgram`
- **Features**: Balance formatting, token metadata resolution, USD values
- **State**: Loading states, error handling, refresh capability

#### `AccountTabs`
- **Purpose**: Tabbed interface for account data (tokens, transactions, NFTs)
- **Props**: `address`, `solBalance`, `tokenBalances`, `activeTab`
- **Features**: Lazy loading, URL synchronization, infinite scroll
- **Tabs**: Tokens, Transactions, NFTs, Programs, History

### Transaction Components (`/components/transaction/`)

#### `TransactionDetails`
- **Purpose**: Complete transaction information display
- **Props**: `signature`, `transaction`, `meta`
- **Features**: Instruction parsing, account changes, fee breakdown
- **Sections**: Overview, Instructions, Account Changes, Logs

#### `TransactionGraph`
- **Purpose**: Visual representation of transaction flow
- **Props**: `address`, `signature?`, `depth?`
- **Features**: Interactive graph, zoom/pan, node filtering
- **Libraries**: D3.js for rendering, Cytoscape for layout

#### `TransactionTable`
- **Purpose**: Paginated table of transactions
- **Props**: `transactions`, `loading`, `onLoadMore`
- **Features**: Sorting, filtering, infinite scroll, export
- **Columns**: Signature, Type, Age, Fee, Status

### Block Components (`/components/block/`)

#### `BlockDetails`
- **Purpose**: Block information and transaction list
- **Props**: `slot`, `block?`
- **Features**: Block metadata, transaction filtering, validator info
- **Sections**: Header, Transactions, Rewards, Statistics

#### `RecentBlocks`
- **Purpose**: Live feed of recent blocks
- **Props**: `blocks`, `onBlockSelect`, `isLoading`
- **Features**: Real-time updates, click handling, loading states
- **Updates**: WebSocket connection for live data

### Token Components (`/components/token/`)

#### `TokenDetails`
- **Purpose**: Token metadata and statistics
- **Props**: `mint`, `token?`
- **Features**: Token info, supply data, holder analysis
- **Sections**: Overview, Statistics, Holders, Transfers

#### `TokenBalance`
- **Purpose**: Display token balance with formatting
- **Props**: `balance`, `decimals`, `symbol`, `showUSD?`
- **Features**: Number formatting, USD conversion, loading states

#### `TokenTable`
- **Purpose**: Table of token holdings or transfers
- **Props**: `tokens`, `type`, `loading`
- **Features**: Sorting by balance/value, token metadata, pagination

### Program Components (`/components/program/`)

#### `ProgramDetails`
- **Purpose**: Program information and analysis
- **Props**: `address`, `program?`
- **Features**: Program metadata, instruction analysis, account ownership
- **Sections**: Overview, Instructions, Accounts, Statistics

#### `ProgramVisualizer`
- **Purpose**: Visual representation of program bytecode
- **Props**: `address`, `data`
- **Features**: Hex view, disassembly, interactive exploration
- **Views**: Hex dump, Assembly, Control flow graph

## AI Components (`/components/ai/`)

### Core AI Components

#### `AIChatSidebar`
- **Purpose**: Resizable sidebar with AI chat interface
- **Props**: `isOpen`, `onClose`, `onWidthChange`, `initialWidth`
- **Features**: Drag resize, conversation history, context awareness
- **State**: Chat messages, loading states, error handling

#### `AIAssistant`
- **Purpose**: Main AI interaction component
- **Props**: `context?`, `initialMessage?`
- **Features**: Natural language processing, blockchain data analysis
- **Capabilities**: Transaction explanation, anomaly detection, education

#### `AIChatDialog`
- **Purpose**: Modal dialog for AI interactions
- **Props**: `isOpen`, `onClose`, `context?`
- **Features**: Full-screen chat, context injection, export conversations

### AI Action Components

#### `AIAnalyzeButton`
- **Purpose**: Button to trigger AI analysis of current data
- **Props**: `data`, `type`, `onAnalysis`
- **Features**: Loading states, error handling, result display

#### `AIExplainTransaction`
- **Purpose**: AI explanation of transaction purpose and effects
- **Props**: `signature`, `transaction?`
- **Features**: Natural language explanation, technical details toggle

## Visualization Components (`/components/visualization/`)

### Chart Components

#### `NetworkResponseChart`
- **Purpose**: Real-time network performance visualization
- **Props**: `data`, `timeRange?`
- **Features**: Live updates, zoom/pan, multiple metrics
- **Library**: Chart.js with real-time plugin

#### `TokenPriceChart`
- **Purpose**: Token price history and trends
- **Props**: `mint`, `timeRange`, `data?`
- **Features**: Candlestick/line charts, volume overlay, indicators

#### `AccountActivityChart`
- **Purpose**: Account transaction activity over time
- **Props**: `address`, `timeRange`
- **Features**: Transaction volume, balance changes, activity heatmap

### Graph Components

#### `TransactionGraph`
- **Purpose**: Interactive transaction flow visualization
- **Props**: `address`, `depth?`, `filters?`
- **Features**: Force-directed layout, node clustering, path highlighting
- **Libraries**: D3.js, Cytoscape

#### `WalletConnectionGraph`
- **Purpose**: Wallet relationship visualization
- **Props**: `sourceWallet`, `targetWallet?`, `maxDepth`
- **Features**: Path finding, connection strength, interactive exploration

## Search Components (`/components/search/`)

#### `SearchSuggestions`
- **Purpose**: Auto-complete suggestions for search queries
- **Props**: `showSuggestions`, `suggestions`, `onSelect`
- **Features**: Keyboard navigation, entity type icons, recent searches

#### `SearchResults`
- **Purpose**: Categorized search results display
- **Props**: `results`, `query`, `loading`
- **Features**: Result categorization, pagination, result highlighting

#### `SearchFilters`
- **Purpose**: Advanced search filtering interface
- **Props**: `filters`, `onFilterChange`
- **Features**: Date ranges, amount filters, entity type filters

## Analytics Components (`/components/analytics/`)

#### `NetworkStats`
- **Purpose**: High-level network statistics dashboard
- **Props**: `stats`, `timeRange?`
- **Features**: Key metrics, trend indicators, comparison views

#### `DeFiAnalytics`
- **Purpose**: DeFi protocol analytics and TVL tracking
- **Props**: `protocols?`, `timeRange`
- **Features**: TVL charts, protocol comparison, yield analysis

#### `ValidatorAnalytics`
- **Purpose**: Validator performance and staking analytics
- **Props**: `validators?`, `metrics`
- **Features**: Performance rankings, stake distribution, commission analysis

## Data Display Components

### Table Components

#### `DataTable`
- **Purpose**: Generic data table with advanced features
- **Props**: `data`, `columns`, `pagination?`, `sorting?`
- **Features**: Sorting, filtering, pagination, row selection, export
- **Library**: @tanstack/react-table

#### `VirtualTable`
- **Purpose**: High-performance virtual table for large datasets
- **Props**: `data`, `columns`, `height`
- **Features**: Virtual scrolling, dynamic row heights, column resizing
- **Library**: @visactor/vtable

### List Components

#### `TransactionList`
- **Purpose**: Optimized list of transactions
- **Props**: `transactions`, `showDetails?`, `onSelect?`
- **Features**: Virtual scrolling, lazy loading, item selection

#### `AccountList`
- **Purpose**: List of accounts with metadata
- **Props**: `accounts`, `showBalances?`, `sortBy?`
- **Features**: Balance display, sorting options, bulk actions

## Layout Components

#### `PageLayout`
- **Purpose**: Standard page layout with navigation and sidebar
- **Props**: `children`, `sidebar?`, `breadcrumbs?`
- **Features**: Responsive design, sidebar toggle, breadcrumb navigation

#### `DashboardLayout`
- **Purpose**: Dashboard layout with widget areas
- **Props**: `widgets`, `layout`, `onLayoutChange?`
- **Features**: Drag-and-drop widgets, responsive grid, layout persistence

## Error Handling Components

#### `ErrorBoundary`
- **Purpose**: Catch and display component errors gracefully
- **Props**: `fallback?`, `onError?`
- **Features**: Error reporting, retry functionality, fallback UI

#### `LoadingSpinner`
- **Purpose**: Loading indicators with different styles
- **Props**: `size?`, `variant?`, `text?`
- **Features**: Multiple variants, accessible labels, timeout handling

## Component Patterns

### Props Patterns
```typescript
// Base component props
interface BaseComponentProps {
  className?: string;
  children?: React.ReactNode;
  'data-testid'?: string;
}

// Data component props
interface DataComponentProps<T> extends BaseComponentProps {
  data?: T;
  loading?: boolean;
  error?: Error | null;
  onRefresh?: () => void;
}

// Interactive component props
interface InteractiveComponentProps extends BaseComponentProps {
  disabled?: boolean;
  onClick?: (event: React.MouseEvent) => void;
  onKeyDown?: (event: React.KeyboardEvent) => void;
}
```

### State Management Patterns
```typescript
// Loading states
const [loading, setLoading] = useState(false);
const [error, setError] = useState<Error | null>(null);
const [data, setData] = useState<T | null>(null);

// Async data fetching
const fetchData = useCallback(async () => {
  setLoading(true);
  setError(null);
  try {
    const result = await api.getData();
    setData(result);
  } catch (err) {
    setError(err as Error);
  } finally {
    setLoading(false);
  }
}, []);
```

### Error Handling Patterns
```typescript
// Component error boundaries
const ErrorFallback = ({ error, resetError }: ErrorFallbackProps) => (
  <div className="error-container">
    <h2>Something went wrong</h2>
    <p>{error.message}</p>
    <button onClick={resetError}>Try again</button>
  </div>
);

// Async error handling
const handleAsyncError = (error: Error) => {
  console.error('Component error:', error);
  // Report to error tracking service
  // Show user-friendly error message
};
```

### Accessibility Patterns
```typescript
// ARIA labels and roles
<button
  aria-label="Copy address to clipboard"
  aria-describedby="copy-help-text"
  role="button"
  tabIndex={0}
>
  Copy
</button>

// Keyboard navigation
const handleKeyDown = (event: React.KeyboardEvent) => {
  if (event.key === 'Enter' || event.key === ' ') {
    event.preventDefault();
    onClick?.(event as any);
  }
};
```

### Performance Patterns
```typescript
// Memoization for expensive calculations
const expensiveValue = useMemo(() => {
  return calculateExpensiveValue(data);
}, [data]);

// Callback memoization
const handleClick = useCallback((id: string) => {
  onItemClick?.(id);
}, [onItemClick]);

// Component memoization
const MemoizedComponent = React.memo(Component, (prevProps, nextProps) => {
  return prevProps.data === nextProps.data;
});
```