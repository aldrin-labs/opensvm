# Account Explorer Routes Steering

## Routes Covered
- `/account/[address]` - Individual account details
- `/user/[walletAddress]` - User profile and social features

## Account Detail Page (`/account/[address]`)

### Purpose
Comprehensive account information including balances, token holdings, transaction history, NFTs, and relationship analysis.

### Key Components Required
- **AccountInfo**: Basic account information display
- **AccountOverview**: Balance and holdings summary
- **TokenAccounts**: SPL token holdings with metadata
- **TransactionHistory**: Paginated transaction list
- **TransactionGraph**: Visual transaction relationships
- **NFTHoldings**: NFT collection display
- **ProgramInteractions**: Program usage analysis
- **AccountAnalytics**: Activity statistics and insights

### Data Requirements
```typescript
interface AccountData {
  address: string;
  info: AccountInfo;
  balance: AccountBalance;
  tokens: TokenHolding[];
  transactions: Transaction[];
  nfts: NFTHolding[];
  programs: ProgramInteraction[];
  analytics: AccountAnalytics;
  relationships: AccountRelationship[];
}

interface AccountInfo {
  lamports: number;
  owner: string;
  executable: boolean;
  rentEpoch: number;
  dataSize: number;
  type: 'wallet' | 'program' | 'token_account' | 'system';
  created: number;
  lastActivity: number;
}

interface AccountBalance {
  sol: number;
  usdValue: number;
  tokens: TokenBalance[];
  totalValue: number;
  change24h: number;
}

interface TokenHolding {
  mint: string;
  symbol: string;
  name: string;
  balance: number;
  decimals: number;
  usdValue: number;
  percentage: number;
  logo?: string;
  verified: boolean;
}

interface AccountAnalytics {
  transactionCount: number;
  uniquePrograms: number;
  averageTransactionSize: number;
  activityLevel: 'inactive' | 'low' | 'moderate' | 'high';
  riskScore: number;
  labels: string[];
  tags: string[];
}

interface AccountRelationship {
  address: string;
  type: 'frequent_sender' | 'frequent_receiver' | 'token_partner' | 'program_user';
  strength: number;
  transactionCount: number;
  totalVolume: number;
  lastInteraction: number;
}
```

### Implementation Guidelines
- Use server-side rendering for account metadata
- Implement real-time balance updates
- Show progressive loading for different sections
- Cache account data with appropriate TTL
- Implement infinite scroll for transaction history
- Add export functionality for account data

### Tabbed Interface
- **Overview**: Balance, tokens, and key metrics
- **Transactions**: Full transaction history with filtering
- **Tokens**: Detailed token holdings and transfers
- **NFTs**: NFT collection with metadata
- **Programs**: Program interaction analysis
- **Analytics**: Advanced statistics and insights

### Transaction History Features
- Infinite scroll pagination
- Advanced filtering (date, type, amount, program)
- Search within transactions
- Export to CSV/JSON
- Real-time updates for new transactions
- Transaction categorization and labeling

## User Profile Page (`/user/[walletAddress]`)

### Purpose
Social features and user-centric view of wallet activity with profiles, following, and community features.

### Key Components Required
- **UserProfile**: Profile information and customization
- **ActivityFeed**: Social activity and updates
- **FollowingList**: Accounts being followed
- **FollowersList**: Accounts following this user
- **SharedContent**: Shared transactions and insights
- **UserStats**: Social and activity statistics

### Social Features
```typescript
interface UserProfile {
  walletAddress: string;
  displayName?: string;
  bio?: string;
  avatar?: string;
  verified: boolean;
  joinDate: number;
  privacy: PrivacySettings;
  stats: UserStats;
  badges: Badge[];
}

interface UserStats {
  followers: number;
  following: number;
  postsShared: number;
  transactionsAnalyzed: number;
  reputation: number;
  level: number;
}

interface ActivityFeedItem {
  id: string;
  type: 'transaction' | 'follow' | 'share' | 'comment' | 'analysis';
  timestamp: number;
  data: any;
  visibility: 'public' | 'followers' | 'private';
}

interface PrivacySettings {
  profileVisibility: 'public' | 'followers' | 'private';
  transactionHistory: 'public' | 'followers' | 'private';
  followingList: 'public' | 'followers' | 'private';
  activityFeed: 'public' | 'followers' | 'private';
}
```

### Social Interaction Features
- Follow/unfollow other wallet addresses
- Share interesting transactions with commentary
- Comment on shared content
- Like and react to posts
- Reputation system based on contributions


## API Integration

### Required Endpoints
- `GET /api/account-stats/[address]` - Get account statistics
- `GET /api/account-token-stats/[address]` - Get token holdings
- `GET /api/account-transactions/[address]` - Get transaction history
- `GET /api/account-transfers/[address]` - Get transfer history
- `GET /api/user-profile/[walletAddress]` - Get user profile
- `GET /api/user-social/[walletAddress]` - Get social data
- `POST /api/user-social/follow` - Follow/unfollow actions
- `GET /api/user-history/[walletAddress]` - Get user activity history

### Real-time Updates
- WebSocket connection for balance updates
- Server-sent events for new transactions
- Push notifications for social interactions
- Real-time activity feed updates

### Caching Strategy
- Account info: Cache for 30 seconds
- Token balances: Cache for 1 minute
- Transaction history: Cache for 300 seconds
- User profiles: Cache for 5 minutes
- Social data: Cache for 1 minute

## Testing Requirements

### Unit Tests
- Account data parsing and validation
- Balance calculations accuracy
- Token metadata resolution
- Social feature functionality
- Privacy settings enforcement

### Integration Tests
- Account page loads with valid address
- Invalid addresses show appropriate errors
- Real-time updates work correctly
- Social features function properly
- Privacy controls are enforced

### E2E Tests
- Account search and navigation
- Transaction history pagination
- Token holdings display
- Social interactions work
- Privacy settings are respected

## Performance Considerations
- Lazy load heavy components (transaction graph, NFT images)
- Implement virtual scrolling for large lists
- Use React.memo for list items
- Optimize image loading for NFTs and avatars
- Bundle split social features

## Security Considerations
- Validate wallet addresses before processing
- Sanitize user-generated content
- Rate limit social interactions
- Prevent spam and abuse
- Secure handling of private data

## Account Analysis Features

### Risk Assessment
```typescript
interface RiskAnalyzer {
  analyzeAccount: (address: string) => Promise<RiskAssessment>;
  detectSuspiciousActivity: (transactions: Transaction[]) => SuspiciousActivity[];
  calculateRiskScore: (account: AccountData) => number;
  identifyPatterns: (activity: Activity[]) => Pattern[];
}

interface RiskAssessment {
  score: number; // 0-100
  level: 'low' | 'medium' | 'high' | 'critical';
  factors: RiskFactor[];
  recommendations: string[];
  lastUpdated: number;
}

interface RiskFactor {
  type: string;
  severity: number;
  description: string;
  evidence: any[];
}
```

### Activity Patterns
```typescript
interface ActivityAnalyzer {
  analyzeTransactionPatterns: (transactions: Transaction[]) => TransactionPattern[];
  detectTradingBehavior: (transactions: Transaction[]) => TradingBehavior;
  identifyAccountType: (account: AccountData) => AccountType;
  calculateActivityScore: (account: AccountData) => number;
}

interface TransactionPattern {
  type: 'regular_trading' | 'arbitrage' | 'liquidity_provision' | 'wash_trading';
  confidence: number;
  frequency: number;
  volume: number;
  timeframe: string;
}
```

## Accessibility Requirements
- Screen reader support for account data
- Keyboard navigation for all features
- High contrast mode for visualizations
- Alternative text for charts and graphs
- Focus management in modal dialogs

## Mobile Optimization
- Responsive design for all components
- Touch-friendly navigation
- Optimized loading for mobile networks
- Simplified views for small screens
- Swipe gestures for navigation

## SEO Optimization
- Dynamic meta titles with account type
- Rich meta descriptions with account summary
- Structured data for account information
- Canonical URLs for account pages
- Social media optimization

## Monitoring and Analytics
- Track account page views and engagement
- Monitor real-time update performance
- Measure user interactions with features
- Track error rates and API failures
- Monitor social feature adoption