# OpenSVM Technology Stack

## Core Framework & Runtime
- **Next.js 15.3.5**: React framework with App Router for server-rendered applications
- **React 18.3.1**: UI library with server and client components
- **TypeScript 5.7.3**: Typed JavaScript for better developer experience
- **Node.js 18+**: Runtime environment (Bun recommended for faster builds)

## Blockchain Integration
- **@solana/web3.js 1.98.0**: Official Solana JavaScript SDK
- **@solana/spl-token**: SPL token program integration
- **@coral-xyz/anchor**: Solana program framework
- **@debridge-finance/solana-transaction-parser**: Transaction parsing utilities

## Styling & UI
- **Tailwind CSS 3.4.1**: Utility-first CSS framework
- **Radix UI**: Accessible component primitives
- **Framer Motion**: Animation library
- **next-themes**: Theme switching support
- **Lucide React**: Icon library

## Data Visualization
- **D3.js 7.9.0**: Data visualization library
- **Cytoscape 3.31.1**: Graph visualization
- **Three.js 0.173.0**: 3D graphics library
- **Chart.js 4.4.8**: Chart library
- **Recharts**: React chart components
- **@visactor/vtable**: Virtual table component

## AI & Machine Learning
- **@mlc-ai/web-llm**: Web-based LLM integration
- **Together AI**: LLM API provider
- **@qdrant/js-client-rest**: Vector database client
- **XState 5.19.2**: State machine library for AI workflows

## Development Tools
- **ESLint**: Code linting with TypeScript support
- **Prettier**: Code formatting
- **Jest**: Unit testing framework
- **Playwright**: End-to-end testing
- **@swc/jest**: Fast Jest transformer

## Build & Deployment
- **Webpack**: Module bundler (via Next.js)
- **PostCSS**: CSS processing
- **Sass**: CSS preprocessor support
- **Docker**: Containerization support
- **Netlify**: Deployment platform support

## Common Commands

### Development
```bash
# Start development server
npm run dev
# or (recommended)
bun run dev

# Run with test environment
npm run dev:test
```

### Building
```bash
# Standard build
npm run build

# Optimized build with analysis
npm run build:optimized

# Build with bundle analysis
npm run build:analyze

# Fast build (skip optimizations)
npm run build:fast
```

### Testing
```bash
# Run unit tests
npm test

# Run E2E tests
npm run test:e2e

# Run E2E tests with UI
npm run test:e2e:ui
```

### Installation (when facing dependency issues)
```bash
# Force reinstall with Bun (recommended)
bun install --force

# Legacy peer deps (npm)
npm install --legacy-peer-deps

# Force install (npm)
npm install --force
```

### Linting & Formatting
```bash
# Run ESLint
npm run lint

# Format code with Prettier (typically via IDE)
```

## Environment Configuration
- Copy `.example.env` to `.env.local`
- Required: Solana RPC endpoints
- Optional: AI service API keys, analytics keys
- Environment variables are typed and validated

## Performance Considerations
- Bundle splitting for heavy libraries (Three.js, Solana, charts)
- Server-side rendering for SEO and performance
- Incremental static regeneration for semi-static data
- Extensive caching for blockchain data
- Code splitting and lazy loading for large components