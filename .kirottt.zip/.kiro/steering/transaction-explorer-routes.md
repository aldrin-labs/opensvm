# Transaction Explorer Routes Steering

## Routes Covered
- `/tx` - Transaction search landing page
- `/tx/[signature]` - Individual transaction details
- `/tx/[signature]/graph` - Transaction graph visualization
- `/tx/[signature]/opengraph-image` - Transaction social sharing images

## Transaction Detail Page (`/tx/[signature]`)

### Purpose
Provide comprehensive analysis of individual Solana transactions including instructions, account changes, fees, and AI-powered explanations.

### Key Components Required
- **TransactionDetails**: Main transaction information display
- **InstructionBreakdown**: Detailed instruction parsing and analysis
- **AccountChangesDisplay**: Before/after account state visualization
- **TransactionGraph**: Visual representation of transaction flow
- **AITransactionExplanation**: AI-powered natural language explanation
- **RelatedTransactionsDisplay**: Connected transactions discovery
- **TransactionFailureAnalysis**: Error analysis for failed transactions

### Data Requirements
```typescript
interface TransactionData {
  signature: string;
  slot: number;
  blockTime: number | null;
  fee: number;
  status: 'success' | 'failed';
  instructions: ParsedInstruction[];
  accountChanges: AccountChange[];
  logs: string[];
  meta: TransactionMeta;
  relatedTransactions: string[];
  aiAnalysis?: AIAnalysis;
}

interface ParsedInstruction {
  programId: string;
  programName: string;
  instructionType: string;
  data: any;
  accounts: InstructionAccount[];
  innerInstructions?: ParsedInstruction[];
}

interface AccountChange {
  address: string;
  before: AccountState;
  after: AccountState;
  change: {
    lamports: number;
    data: any;
    owner?: string;
  };
}

interface AIAnalysis {
  summary: string;
  purpose: string;
  riskLevel: 'low' | 'medium' | 'high';
  keyInsights: string[];
  technicalDetails: string;
  recommendations: string[];
}
```

### Implementation Guidelines
- Use Suspense for async data loading
- Implement comprehensive error boundaries
- Show progressive loading states (signature validation → transaction fetch → parsing → AI analysis)
- Cache parsed transaction data aggressively
- Implement retry mechanism for failed requests
- Add copy-to-clipboard functionality for addresses and signatures

### AI Integration
- Trigger AI analysis automatically for complex transactions
- Show AI thinking/loading states
- Allow users to request re-analysis
- Cache AI responses to reduce API costs
- Provide technical and simplified explanation modes

### Performance Considerations
- Lazy load heavy components (graph visualization, AI analysis)
- Use React.memo for instruction list items
- Implement virtual scrolling for transactions with many instructions
- Prefetch related transactions on hover
- Optimize bundle size by code-splitting visualization libraries

## Transaction Graph Page (`/tx/[signature]/graph`)

### Purpose
Interactive graph visualization showing transaction flow, account relationships, and program interactions.

### Key Components Required
- **TransactionGraphClouds**: 3D visualization component
- **TransactionGraphFilters**: Filter controls for graph display
- **TransactionNodeDetails**: Detailed node information panel
- **GraphControls**: Zoom, pan, layout controls

### Visualization Features
- Force-directed graph layout using D3.js/Cytoscape
- Interactive nodes (accounts, programs, instructions)
- Edge weights based on SOL/token amounts
- Color coding by account type and program
- Zoom and pan functionality
- Node clustering for complex transactions
- Export to PNG/SVG functionality

### Graph Data Structure
```typescript
interface GraphData {
  nodes: GraphNode[];
  edges: GraphEdge[];
  metadata: GraphMetadata;
}

interface GraphNode {
  id: string;
  type: 'account' | 'program' | 'instruction';
  label: string;
  data: any;
  position?: { x: number; y: number };
  style: NodeStyle;
}

interface GraphEdge {
  source: string;
  target: string;
  type: 'transfer' | 'instruction' | 'account_change';
  weight: number;
  data: any;
  style: EdgeStyle;
}
```

### Interaction Features
- Click nodes to show details panel
- Hover for quick information tooltips
- Right-click context menu for actions
- Keyboard shortcuts for navigation
- Touch gestures for mobile

## Transaction Search Landing (`/tx`)

### Purpose
Entry point for transaction search with recent transactions and search suggestions.

### Key Components Required
- **SearchBar**: Transaction signature search
- **RecentTransactions**: List of recent network transactions
- **SearchSuggestions**: Auto-complete for partial signatures
- **TransactionStats**: Network transaction statistics

### Features to Implement
- Auto-complete for transaction signatures
- Recent transaction feed with real-time updates
- Transaction type filtering
- Bulk transaction analysis tools
- Export functionality for transaction lists

## OpenGraph Images (`/tx/[signature]/opengraph-image`)

### Purpose
Generate dynamic social sharing images for transaction pages.

### Implementation Guidelines
- Use Next.js ImageResponse API
- Include transaction summary (type, amount, status)
- Show key participants (sender, receiver)
- Display transaction status visually
- Include timestamp and fee information
- Use consistent OpenSVM branding

### Image Content Structure
```typescript
interface TransactionOGData {
  signature: string; // Truncated for display
  type: string; // "Token Transfer", "Program Interaction", etc.
  amount?: string; // "1.5 SOL" or "100 USDC"
  status: 'success' | 'failed';
  timestamp: string;
  fee: string;
  participants: string[]; // Key addresses involved
}
```

## API Integration

### Required Endpoints
- `GET /api/transaction/[signature]` - Get transaction details
- `POST /api/analyze-transaction` - AI analysis of transaction
- `GET /api/transaction/[signature]/related` - Find related transactions
- `GET /api/transaction/[signature]/graph` - Graph data for visualization
- `GET /api/enhanced-transaction/[signature]` - Enhanced transaction data

### Error Handling
- Invalid signatures should return 400 with clear message
- Not found transactions should return 404
- Network timeouts should trigger retry mechanism
- Partial data should be displayed with loading indicators

### Caching Strategy
- Transaction data: Cache for 1 hour (confirmed transactions are immutable)
- AI analysis: Cache for 24 hours
- Graph data: Cache for 30 minutes
- Related transactions: Cache for 15 minutes

## Testing Requirements

### Unit Tests
- Transaction signature validation
- Instruction parsing accuracy
- Account change calculation
- AI analysis integration
- Graph data generation

### Integration Tests
- Transaction page loads with valid signature
- Invalid signatures show appropriate errors
- AI analysis triggers correctly
- Graph visualization renders properly
- Related transactions are discovered

### E2E Tests
- Search for transaction works end-to-end
- Transaction details display correctly
- Graph visualization is interactive
- Social sharing generates correct images
- Mobile experience is functional

## Security Considerations
- Validate transaction signatures before processing
- Sanitize transaction data before display
- Rate limit AI analysis requests
- Prevent XSS in transaction logs display
- Secure handling of sensitive transaction data

## Performance Monitoring
- Track transaction page load times
- Monitor AI analysis response times
- Measure graph rendering performance
- Track user engagement with different features
- Monitor error rates and types

## Accessibility Requirements
- Keyboard navigation for graph visualization
- Screen reader support for transaction details
- High contrast mode for visual elements
- Alternative text for graph nodes
- Focus management in modal dialogs

## Mobile Optimization
- Touch-friendly graph controls
- Responsive transaction details layout
- Optimized loading for mobile networks
- Simplified graph view for small screens
- Swipe gestures for navigation

## SEO and Social Sharing
- Dynamic meta titles with transaction type
- Rich meta descriptions with transaction summary
- Structured data for transaction information
- Twitter Card optimization
- LinkedIn sharing optimization