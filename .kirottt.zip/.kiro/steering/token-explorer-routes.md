# Token Explorer Routes Steering

## Routes Covered
- `/token/[mint]` - Individual token details
- `/token/[mint]/opengraph-image` - Token social sharing images
- `/tokens` - Token list and market data
- `/tokens/gainers` - Top gaining tokens
- `/tokens/new` - Recently launched tokens

## Token Detail Page (`/token/[mint]`)

### Purpose
Comprehensive token information including metadata, statistics, holder analysis, transfer history, and market data.

### Key Components Required
- **TokenDetails**: Main token information display
- **TokenMarketTable**: Market data and price information
- **TokenAccounts**: Holder distribution and top holders
- **TransfersTable**: Token transfer history
- **TokenStatistics**: Supply, circulation, and metrics
- **PriceChart**: Historical price and volume charts
- **TokenSocialInfo**: Community links and social media

### Data Requirements
```typescript
interface TokenData {
  mint: string;
  metadata: TokenMetadata;
  supply: TokenSupply;
  marketData: TokenMarketData;
  holders: TokenHolder[];
  transfers: TokenTransfer[];
  statistics: TokenStatistics;
  socialLinks: SocialLinks;
}

interface TokenMetadata {
  name: string;
  symbol: string;
  decimals: number;
  description?: string;
  image?: string;
  creator: string;
  verified: boolean;
  tags: string[];
}

interface TokenSupply {
  total: number;
  circulating: number;
  burned: number;
  locked: number;
}

interface TokenMarketData {
  price: number;
  priceChange24h: number;
  volume24h: number;
  marketCap: number;
  fullyDilutedMarketCap: number;
  liquidity: number;
  holders: number;
}

interface TokenHolder {
  address: string;
  balance: number;
  percentage: number;
  rank: number;
  isContract: boolean;
}

interface TokenStatistics {
  transferCount24h: number;
  uniqueHolders: number;
  averageHoldingTime: number;
  concentrationRatio: number;
  liquidityScore: number;
}
```

### Implementation Guidelines
- Use server-side rendering for SEO optimization
- Implement real-time price updates via WebSocket
- Cache token metadata aggressively (rarely changes)
- Show loading states for different data sections
- Implement infinite scroll for transfer history
- Add price alerts and watchlist functionality

### Market Data Integration
- Connect to multiple price data sources
- Implement fallback for price data failures
- Show price in multiple currencies (USD, SOL)
- Display price charts with different timeframes
- Calculate market metrics accurately

### Holder Analysis Features
- Top holders list with percentage ownership
- Holder distribution charts
- Whale movement tracking
- New holder acquisition metrics
- Holder retention analysis

## Token List Page (`/tokens`)

### Purpose
Browse all tokens with market data, filtering, and real-time updates.

### Key Components Required
- **TokenMarketTable**: Main table with market data
- **TokenFilters**: Filtering and search controls
- **MarketOverview**: Overall market statistics
- **TrendingTokens**: Popular tokens section

### Features to Implement
- Real-time price updates every 30 seconds
- Advanced filtering (price range, market cap, volume)
- Search by name, symbol, or mint address
- Sorting by various metrics
- Export functionality for token data
- Watchlist and favorites functionality

### Table Columns
- Token name and symbol with logo
- Current price with 24h change
- Market cap and fully diluted market cap
- 24h volume and volume change
- Circulating supply
- Number of holders
- Price chart sparkline

## Token Gainers Page (`/tokens/gainers`)

### Purpose
Display top performing tokens by price change over different timeframes.

### Key Components Required
- **GainersTable**: Sorted by price performance
- **TimeframeSelector**: 1h, 24h, 7d, 30d options
- **PerformanceCharts**: Visual performance indicators
- **GainerAlerts**: Notification system for big movers

### Features to Implement
- Multiple timeframe analysis
- Percentage and absolute change display
- Volume-weighted performance metrics
- Alert system for significant moves
- Historical gainer tracking

### Data Structure
```typescript
interface TokenGainer {
  mint: string;
  name: string;
  symbol: string;
  image: string;
  priceChange: {
    '1h': number;
    '24h': number;
    '7d': number;
    '30d': number;
  };
  volume24h: number;
  marketCap: number;
  rank: number;
}
```

## New Tokens Page (`/tokens/new`)

### Purpose
Showcase recently launched tokens with launch metrics and early performance data.

### Key Components Required
- **NewTokensTable**: Recently launched tokens
- **LaunchMetrics**: Launch performance indicators
- **TokenLaunchCalendar**: Upcoming token launches
- **RiskIndicators**: Safety and verification status

### Features to Implement
- Launch date and time tracking
- Initial price and current performance
- Liquidity pool creation tracking
- Verification status indicators
- Risk assessment for new tokens
- Launch announcement integration

### Launch Metrics
```typescript
interface TokenLaunch {
  mint: string;
  launchDate: number;
  initialPrice: number;
  currentPrice: number;
  priceChangeFromLaunch: number;
  initialLiquidity: number;
  currentLiquidity: number;
  holderGrowth: number;
  verified: boolean;
  riskScore: number;
}
```

## OpenGraph Images (`/token/[mint]/opengraph-image`)

### Purpose
Generate dynamic social sharing images for token pages.

### Implementation Guidelines
- Include token logo and name prominently
- Show current price and 24h change
- Display market cap and volume
- Use color coding for price changes (green/red)
- Include mini price chart if space allows
- Maintain consistent OpenSVM branding

### Image Content
```typescript
interface TokenOGData {
  name: string;
  symbol: string;
  logo: string;
  price: string;
  priceChange24h: number;
  marketCap: string;
  volume24h: string;
  holders: number;
}
```

## API Integration

### Required Endpoints
- `GET /api/token/[mint]` - Get comprehensive token data
- `GET /api/token-stats/[mint]` - Get token statistics
- `GET /api/tokens` - Get token list with market data
- `GET /api/tokens/gainers` - Get top gaining tokens
- `GET /api/tokens/new` - Get recently launched tokens
- `GET /api/token/[mint]/holders` - Get token holder data
- `GET /api/token/[mint]/transfers` - Get token transfer history
- `GET /api/token/[mint]/chart` - Get price chart data

### Real-time Data
- WebSocket connection for live price updates
- Server-sent events for market data changes
- Push notifications for significant price movements
- Real-time holder count updates

### Caching Strategy
- Token metadata: Cache for 1 hour
- Market data: Cache for 30 seconds
- Holder data: Cache for 5 minutes
- Transfer history: Cache for 1 minute
- Price charts: Cache for 30 seconds

## Testing Requirements

### Unit Tests
- Token data parsing and validation
- Price calculation accuracy
- Market metrics computation
- Holder analysis algorithms
- Chart data generation

### Integration Tests
- Token page loads with valid mint
- Invalid mints show appropriate errors
- Market data updates correctly
- Filtering and search functionality
- Real-time updates work properly

### E2E Tests
- Token search and navigation
- Market data display accuracy
- Price chart interactions
- Holder list functionality
- Transfer history pagination

## Performance Considerations
- Lazy load heavy components (charts, holder lists)
- Implement virtual scrolling for large datasets
- Use React.memo for token list items
- Optimize image loading for token logos
- Bundle split chart libraries

## Security Considerations
- Validate mint addresses before processing
- Sanitize token metadata display
- Rate limit price data requests
- Prevent manipulation of market data
- Secure handling of holder information

## Accessibility Requirements
- Screen reader support for price changes
- Keyboard navigation for tables
- High contrast mode for charts
- Alternative text for token logos
- ARIA labels for interactive elements

## Mobile Optimization
- Responsive table design
- Touch-friendly chart interactions
- Optimized loading for mobile networks
- Simplified view for small screens
- Swipe gestures for navigation

## SEO Optimization
- Dynamic meta titles with token name and price
- Rich meta descriptions with market data
- Structured data for token information
- Canonical URLs for token pages
- Sitemap inclusion for verified tokens

## Monitoring and Analytics
- Track token page views and engagement
- Monitor price data accuracy and latency
- Measure chart rendering performance
- Track user interactions with features
- Monitor error rates and API failures