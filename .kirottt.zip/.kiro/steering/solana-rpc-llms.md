---
title: accountSubscribe
hideTableOfContents: true
h1: accountSubscribe RPC Method
---

Subscribe to an account to receive notifications when the lamports or data for a
given account public key changes

<APIMethod>

```jsonc !!request
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "accountSubscribe",
  "params": [
    // !hover 0
    "CM78CPUeXjn8o3yroDHxUtKsZZgoy4GPkPPXfouKNH12",
    // !hover(1:4) 1
    {
      // !hover encoding
      "encoding": "jsonParsed",
      // !hover commitment
      "commitment": "finalized"
    }
  ]
}
```

### !params

#### !! 0

!type string  
!required

Account Pubkey, as base-58 encoded string

#### !! 1

!type object

Configuration object containing the following fields:

##### !! commitment

!type string

The commitment describes how finalized a block is at that point in time. See
[Configuring State Commitment](/docs/rpc#configuring-state-commitment).

##### !! encoding

!type string  
!values base58 base64 base64+zstd jsonParsed

Encoding format for Account data

- `base58` is slow.
- `jsonParsed` encoding attempts to use program-specific state parsers to return
  more human-readable and explicit account state data
- If `jsonParsed` is requested but a parser cannot be found, the field falls
  back to binary encoding, detectable when the `data` field is type `string`.

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover result
  "result": 23784,
  "id": 1
}
```

!type number

Subscription id (needed to unsubscribe)

</APIMethod>

#### Notification Format:

The notification format is the same as seen in the
[getAccountInfo](/docs/rpc/http/getaccountinfo) RPC HTTP method.

Base58 encoding:

```json
{
  "jsonrpc": "2.0",
  "method": "accountNotification",
  "params": {
    "result": {
      "context": {
        "slot": 5199307
      },
      "value": {
        "data": [
          "11116bv5nS2h3y12kD1yUKeMZvGcKLSjQgX6BeV7u1FrjeJcKfsHPXHRDEHrBesJhZyqnnq9qJeUuF7WHxiuLuL5twc38w2TXNLxnDbjmuR",
          "base58"
        ],
        "executable": false,
        "lamports": 33594,
        "owner": "11111111111111111111111111111111",
        "rentEpoch": 635,
        "space": 80
      }
    },
    "subscription": 23784
  }
}
```

Parsed-JSON encoding:

```json
{
  "jsonrpc": "2.0",
  "method": "accountNotification",
  "params": {
    "result": {
      "context": {
        "slot": 5199307
      },
      "value": {
        "data": {
          "program": "nonce",
          "parsed": {
            "type": "initialized",
            "info": {
              "authority": "Bbqg1M4YVVfbhEzwA9SpC9FhsaG83YMTYoR4a8oTDLX",
              "blockhash": "LUaQTmM7WbMRiATdMMHaRGakPtCkc2GHtH57STKXs6k",
              "feeCalculator": {
                "lamportsPerSignature": 5000
              }
            }
          }
        },
        "executable": false,
        "lamports": 33594,
        "owner": "11111111111111111111111111111111",
        "rentEpoch": 635,
        "space": 80
      }
    },
    "subscription": 23784
  }
}
```
---
title: accountUnsubscribe
hideTableOfContents: true
h1: accountUnsubscribe RPC Method
---

Unsubscribe from account change notifications

<APIMethod>

```jsonc !!request
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "accountUnsubscribe",
  "params": [
    // !hover 0
    0
  ]
}
```

### !params

#### !! 0

!type number  
!required

id of the account Subscription to cancel

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover result
  "result": true,
  "id": 1
}
```

!type boolean

unsubscribe success message

</APIMethod>
---
title: blockSubscribe
hideTableOfContents: true
h1: blockSubscribe RPC Method
---

Subscribe to receive notification anytime a new block is `confirmed` or
`finalized`.

<Callout type="warn" title={"Unstable Method"}>
  This subscription is considered **unstable** and is only available if the
  validator was started with the `--rpc-pubsub-enable-block-subscription` flag.
  The format of this subscription may change in the future.
</Callout>

<APIMethod>

```jsonc !!request
{
  "jsonrpc": "2.0",
  "id": "1",
  "method": "blockSubscribe",
  "params": [
    // !hover(1:3) 0
    {
      "mentionsAccountOrProgram": "LieKvPRE8XeX3Y2xVNHjKlpAScD12lYySBVQ4HqoJ5op"
    },
    // !hover(1:6) 1
    {
      // !hover commitment
      "commitment": "confirmed",
      // !hover encoding
      "encoding": "base64",
      // !hover transactionDetails
      "transactionDetails": "full",
      // !hover maxSupportedTransactionVersion
      "maxSupportedTransactionVersion": 0,
      // !hover showRewards
      "showRewards": true
    }
  ]
}
```

### !params

#### !! 0

!type string | object  
!required

filter criteria for the logs to receive results by account type; currently
supported:

- `all` - include all transactions in block
- A JSON object with the following field:
  - `mentionsAccountOrProgram: <string>` - return only transactions that mention
    the provided public key (as base-58 encoded string). If no mentions in a
    given block, then no notification will be sent.

#### !! 1

!type object

Configuration object containing the following fields:

##### !! commitment

!type string
!values confirmed finalized
!default finalized

The commitment describes how finalized a block is at that point in time. See
[Configuring State Commitment](/docs/rpc#configuring-state-commitment).

- `processed` is not supported.

##### !! encoding

!type string  
!values json jsonParsed base58 base64  
!default json

encoding format for each returned Transaction

- `jsonParsed` attempts to use program-specific instruction parsers to return
  more human-readable and explicit data in the
  `transaction.message.instructions` list.
- If `jsonParsed` is requested but a parser cannot be found, the instruction
  falls back to regular JSON encoding (`accounts`, `data`, and `programIdIndex`
  fields).

##### !! transactionDetails

!type string  
!values full accounts signatures none  
!default full

level of transaction detail to return

- If `accounts` are requested, transaction details only include signatures and
  an annotated list of accounts in each transaction.
- Transaction metadata is limited to only: fee, err, pre_balances,
  post_balances, pre_token_balances, and post_token_balances.

##### !! maxSupportedTransactionVersion

!type number
!values 0
!default 0

Currently, the only valid value for this parameter is `0`. 
Setting it to `0` allows you to fetch all transactions, including both Versioned and legacy transactions.

This parameter determines the maximum transaction version that will be returned in the response. 
If you request a transaction with a higher version than this value, an error will be returned. 
If you omit this parameter, only legacy transactions will be returned—any versioned transaction will result in an error.


##### !! showRewards

!type bool

whether to populate the `rewards` array. If parameter not provided, the default
includes rewards.

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover result
  "result": 0,
  "id": 1
}
```

!type integer

subscription id (needed to unsubscribe)

</APIMethod>

#### Notification Format:

The notification will be an object with the following fields:

- `slot: <u64>` - The corresponding slot.
- `err: <object|null>` - Error if something went wrong publishing the
  notification otherwise null.
- `block: <object|null>` - A block object as seen in the
  [getBlock](/docs/rpc/http/getblock) RPC HTTP method.

```json
{
  "jsonrpc": "2.0",
  "method": "blockNotification",
  "params": {
    "result": {
      "context": {
        "slot": 112301554
      },
      "value": {
        "slot": 112301554,
        "block": {
          "previousBlockhash": "GJp125YAN4ufCSUvZJVdCyWQJ7RPWMmwxoyUQySydZA",
          "blockhash": "6ojMHjctdqfB55JDpEpqfHnP96fiaHEcvzEQ2NNcxzHP",
          "parentSlot": 112301553,
          "transactions": [
            {
              "transaction": [
                "OpltwoUvWxYi1P2U8vbIdE/aPntjYo5Aa0VQ2JJyeJE2g9Vvxk8dDGgFMruYfDu8/IfUWb0REppTe7IpAuuLRgIBAAkWnj4KHRpEWWW7gvO1c0BHy06wZi2g7/DLqpEtkRsThAXIdBbhXCLvltw50ZnjDx2hzw74NVn49kmpYj2VZHQJoeJoYJqaKcvuxCi/2i4yywedcVNDWkM84Iuw+cEn9/ROCrXY4qBFI9dveEERQ1c4kdU46xjxj9Vi+QXkb2Kx45QFVkG4Y7HHsoS6WNUiw2m4ffnMNnOVdF9tJht7oeuEfDMuUEaO7l9JeUxppCvrGk3CP45saO51gkwVYEgKzhpKjCx3rgsYxNR81fY4hnUQXSbbc2Y55FkwgRBpVvQK7/+clR4Gjhd3L4y+OtPl7QF93Akg1LaU9wRMs5nvfDFlggqI9PqJl+IvVWrNRdBbPS8LIIhcwbRTkSbqlJQWxYg3Bo2CTVbw7rt1ZubuHWWp0mD/UJpLXGm2JprWTePNULzHu67sfqaWF99LwmwjTyYEkqkRt1T0Je5VzHgJs0N5jY4iIU9K3lMqvrKOIn/2zEMZ+ol2gdgjshx+sphIyhw65F3J/Dbzk04LLkK+CULmN571Y+hFlXF2ke0BIuUG6AUF+4214Cu7FXnqo3rkxEHDZAk0lRrAJ8X/Z+iwuwI5cgbd9uHXZaGT2cvhRs7reawctIXtX1s3kTqM9YV+/wCpDLAp8axcEkaQkLDKRoWxqp8XLNZSKial7Rk+ELAVVKWoWLRXRZ+OIggu0OzMExvVLE5VHqy71FNHq4gGitkiKYNFWSLIE4qGfdFLZXy/6hwS+wq9ewjikCpd//C9BcCL7Wl0iQdUslxNVCBZHnCoPYih9JXvGefOb9WWnjGy14sG9j70+RSVx6BlkFELWwFvIlWR/tHn3EhHAuL0inS2pwX7ZQTAU6gDVaoqbR2EiJ47cKoPycBNvHLoKxoY9AZaBjPl6q8SKQJSFyFd9n44opAgI6zMTjYF/8Ok4VpXEESp3QaoUyTI9sOJ6oFP6f4dwnvQelgXS+AEfAsHsKXxGAIUDQENAgMEBQAGBwgIDg8IBJCER3QXl1AVDBADCQoOAAQLERITDAjb7ugh3gOuTy==",
                "base64"
              ],
              "meta": {
                "err": null,
                "status": {
                  "Ok": null
                },
                "fee": 5000,
                "preBalances": [
                  1758510880, 2067120, 1566000, 1461600, 2039280, 2039280,
                  1900080, 1865280, 0, 3680844220, 2039280
                ],
                "postBalances": [
                  1758505880, 2067120, 1566000, 1461600, 2039280, 2039280,
                  1900080, 1865280, 0, 3680844220, 2039280
                ],
                "innerInstructions": [
                  {
                    "index": 0,
                    "instructions": [
                      {
                        "programIdIndex": 13,
                        "accounts": [1, 15, 3, 4, 2, 14],
                        "data": "21TeLgZXNbtHXVBzCaiRmH"
                      },
                      {
                        "programIdIndex": 14,
                        "accounts": [3, 4, 1],
                        "data": "6qfC8ic7Aq99"
                      },
                      {
                        "programIdIndex": 13,
                        "accounts": [1, 15, 3, 5, 2, 14],
                        "data": "21TeLgZXNbsn4QEpaSEr3q"
                      },
                      {
                        "programIdIndex": 14,
                        "accounts": [3, 5, 1],
                        "data": "6LC7BYyxhFRh"
                      }
                    ]
                  },
                  {
                    "index": 1,
                    "instructions": [
                      {
                        "programIdIndex": 14,
                        "accounts": [4, 3, 0],
                        "data": "7aUiLHFjSVdZ"
                      },
                      {
                        "programIdIndex": 19,
                        "accounts": [17, 18, 16, 9, 11, 12, 14],
                        "data": "8kvZyjATKQWYxaKR1qD53V"
                      },
                      {
                        "programIdIndex": 14,
                        "accounts": [9, 11, 18],
                        "data": "6qfC8ic7Aq99"
                      }
                    ]
                  }
                ],
                "logMessages": [
                  "Program QMNeHCGYnLVDn1icRAfQZpjPLBNkfGbSKRB83G5d8KB invoke [1]",
                  "Program QMWoBmAyJLAsA1Lh9ugMTw2gciTihncciphzdNzdZYV invoke [2]"
                ],
                "preTokenBalances": [
                  {
                    "accountIndex": 4,
                    "mint": "iouQcQBAiEXe6cKLS85zmZxUqaCqBdeHFpqKoSz615u",
                    "uiTokenAmount": {
                      "uiAmount": null,
                      "decimals": 6,
                      "amount": "0",
                      "uiAmountString": "0"
                    },
                    "owner": "LieKvPRE8XeX3Y2xVNHjKlpAScD12lYySBVQ4HqoJ5op",
                    "programId": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
                  },
                  {
                    "accountIndex": 5,
                    "mint": "iouQcQBAiEXe6cKLS85zmZxUqaCqBdeHFpqKoSz615u",
                    "uiTokenAmount": {
                      "uiAmount": 11513.0679,
                      "decimals": 6,
                      "amount": "11513067900",
                      "uiAmountString": "11513.0679"
                    },
                    "owner": "rXhAofQCT7NN9TUqigyEAUzV1uLL4boeD8CRkNBSkYk",
                    "programId": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
                  },
                  {
                    "accountIndex": 10,
                    "mint": "Saber2gLauYim4Mvftnrasomsv6NvAuncvMEZwcLpD1",
                    "uiTokenAmount": {
                      "uiAmount": null,
                      "decimals": 6,
                      "amount": "0",
                      "uiAmountString": "0"
                    },
                    "owner": "CL9wkGFT3SZRRNa9dgaovuRV7jrVVigBUZ6DjcgySsCU",
                    "programId": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
                  },
                  {
                    "accountIndex": 11,
                    "mint": "Saber2gLauYim4Mvftnrasomsv6NvAuncvMEZwcLpD1",
                    "uiTokenAmount": {
                      "uiAmount": 15138.514093,
                      "decimals": 6,
                      "amount": "15138514093",
                      "uiAmountString": "15138.514093"
                    },
                    "owner": "LieKvPRE8XeX3Y2xVNHjKlpAScD12lYySBVQ4HqoJ5op",
                    "programId": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
                  }
                ],
                "postTokenBalances": [
                  {
                    "accountIndex": 4,
                    "mint": "iouQcQBAiEXe6cKLS85zmZxUqaCqBdeHFpqKoSz615u",
                    "uiTokenAmount": {
                      "uiAmount": null,
                      "decimals": 6,
                      "amount": "0",
                      "uiAmountString": "0"
                    },
                    "owner": "LieKvPRE8XeX3Y2xVNHjKlpAScD12lYySBVQ4HqoJ5op",
                    "programId": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
                  },
                  {
                    "accountIndex": 5,
                    "mint": "iouQcQBAiEXe6cKLS85zmZxUqaCqBdeHFpqKoSz615u",
                    "uiTokenAmount": {
                      "uiAmount": 11513.103028,
                      "decimals": 6,
                      "amount": "11513103028",
                      "uiAmountString": "11513.103028"
                    },
                    "owner": "rXhAofQCT7NN9TUqigyEAUzV1uLL4boeD8CRkNBSkYk",
                    "programId": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
                  },
                  {
                    "accountIndex": 10,
                    "mint": "Saber2gLauYim4Mvftnrasomsv6NvAuncvMEZwcLpD1",
                    "uiTokenAmount": {
                      "uiAmount": null,
                      "decimals": 6,
                      "amount": "0",
                      "uiAmountString": "0"
                    },
                    "owner": "CL9wkGFT3SZRRNa9dgaovuRV7jrVVigBUZ6DjcgySsCU",
                    "programId": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
                  },
                  {
                    "accountIndex": 11,
                    "mint": "Saber2gLauYim4Mvftnrasomsv6NvAuncvMEZwcLpD1",
                    "uiTokenAmount": {
                      "uiAmount": 15489.767829,
                      "decimals": 6,
                      "amount": "15489767829",
                      "uiAmountString": "15489.767829"
                    },
                    "owner": "BeiHVPRE8XeX3Y2xVNrSsTpAScH94nYySBVQ4HqgN9at",
                    "programId": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
                  }
                ],
                "rewards": []
              }
            }
          ],
          "blockTime": 1639926816,
          "blockHeight": 101210751
        },
        "err": null
      }
    },
    "subscription": 14
  }
}
```
---
title: blockUnsubscribe
hideTableOfContents: true
h1: blockUnsubscribe RPC Method
---

Unsubscribe from block notifications

<APIMethod>

```jsonc !!request
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "blockUnsubscribe",
  "params": [
    // !hover 0
    0
  ]
}
```

### !params

#### !! 0

!type integer  
!required

subscription id to cancel

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover result
  "result": true,
  "id": 1
}
```

!type boolean

unsubscribe success message

</APIMethod>
---
title: Websocket Methods
seoTitle: Solana RPC Websocket Methods
hideTableOfContents: false
h1: Solana RPC Websocket Methods
---

After connecting to the RPC PubSub websocket at `ws://<ADDRESS>/`:

- Submit subscription requests to the websocket using the methods below
- Multiple subscriptions may be active at once
- Many subscriptions take the optional
  [`commitment` parameter](/docs/rpc/#configuring-state-commitment),
  defining how finalized a change should be to trigger a notification. For
  subscriptions, if commitment is unspecified, the default value is `finalized`.

## RPC PubSub WebSocket Endpoint

Default port: `8900`

- ws://localhost:8900
- http://192.168.1.88:8900
---
title: logsSubscribe
hideTableOfContents: true
h1: logsSubscribe RPC Method
---

Subscribe to transaction logging

<APIMethod>

```jsonc !!request
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "logsSubscribe",
  "params": [
    // !hover(1:3) 0
    {
      "mentions": ["11111111111111111111111111111111"]
    },
    // !hover(1:3) 1
    {
      // !hover commitment
      "commitment": "finalized"
    }
  ]
}
```

### !params

#### !! 0

!type string | object  
!required

filter criteria for the logs to receive results by account type. The following
filters types are currently supported:

- `all` - subscribe to all transactions except for simple vote transactions
- `allWithVotes` - subscribe to all transactions, including simple vote
  transactions
- An object with the following field:
  - `mentions: [ <string> ]` - array containing a single Pubkey (as base-58
    encoded string); if present, subscribe to only transactions mentioning this
    address

<Callout type="warn" title={true}>
  The `mentions` field currently [only supports
  one](https://github.com/solana-labs/solana/blob/master/rpc/src/rpc_pubsub.rs#L481)
  Pubkey string per method call. Listing additional addresses will result in an
  error.
</Callout>

#### !! 1

!type object

Configuration object containing the following fields:

##### !! commitment

!type string

The commitment describes how finalized a block is at that point in time. See
[Configuring State Commitment](/docs/rpc#configuring-state-commitment).

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover result
  "result": 24040,
  "id": 1
}
```

!type integer

Subscription id (needed to unsubscribe)

</APIMethod>

#### Notification Format:

The notification will be an RpcResponse JSON object with value equal to:

- `signature: <string>` - The transaction signature base58 encoded.
- `err: <object|null>` - Error if transaction failed, null if transaction
  succeeded.
  [TransactionError definitions](https://github.com/solana-labs/solana/blob/c0c60386544ec9a9ec7119229f37386d9f070523/sdk/src/transaction/error.rs#L13)
- `logs: <array[string]>` - Array of log messages the transaction instructions 
  output during execution.

Example:

```json
{
  "jsonrpc": "2.0",
  "method": "logsNotification",
  "params": {
    "result": {
      "context": {
        "slot": 5208469
      },
      "value": {
        "signature": "5h6xBEauJ3PK6SWCZ1PGjBvj8vDdWG3KpwATGy1ARAXFSDwt8GFXM7W5Ncn16wmqokgpiKRLuS83KUxyZyv2sUYv",
        "err": null,
        "logs": [
          "SBF program 83astBRguLMdt2h5U1Tpdq5tjFoJ6noeGwaY3mDLVcri success"
        ]
      }
    },
    "subscription": 24040
  }
}
```
---
title: logsUnsubscribe
hideTableOfContents: true
h1: logsUnsubscribe RPC Method
---

Unsubscribe from transaction logging

<APIMethod>

```jsonc !!request
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "logsUnsubscribe",
  "params": [
    // !hover 0
    0
  ]
}
```

### !params

#### !! 0

!type integer  
!required

subscription id to cancel

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover result
  "result": true,
  "id": 1
}
```

!type boolean

unsubscribe success message

</APIMethod>
{
  "title": "Websocket Methods",
  "pages": [
    "accountsubscribe",
    "accountunsubscribe",
    "blocksubscribe",
    "blockunsubscribe",
    "logssubscribe",
    "logsunsubscribe",
    "programsubscribe",
    "programunsubscribe",
    "rootsubscribe",
    "rootunsubscribe",
    "signaturesubscribe",
    "signatureunsubscribe",
    "slotsubscribe",
    "slotsupdatessubscribe",
    "slotsupdatesunsubscribe",
    "slotunsubscribe",
    "votesubscribe",
    "voteunsubscribe"
  ]
}
---
title: programSubscribe
hideTableOfContents: true
h1: programSubscribe RPC Method
---

Subscribe to a program to receive notifications when the lamports or data for an
account owned by the given program changes

<APIMethod>

```jsonc !!request
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "programSubscribe",
  "params": [
    // !hover 0
    "11111111111111111111111111111111",
    // !hover(1:4) 1
    {
      // !hover encoding
      "encoding": "base64",
      // !hover filters
      "filters": [{ "dataSize": 80 }]
    }
  ]
}
```

### !params

#### !! 0

!type string  
!required

Pubkey of the `program_id`, as base-58 encoded string

#### !! 1

!type object

Configuration object containing the following fields:

##### !! commitment

!type string

The commitment describes how finalized a block is at that point in time. See
[Configuring State Commitment](/docs/rpc#configuring-state-commitment).

##### !! filters

!type array

Filter results using various filter objects. See
[Filtering](/docs/rpc#filter-criteria).

<Callout type="info">
  The resultant account must meet **ALL** filter criteria to be included in the
  returned results
</Callout>

##### !! encoding

!type string  
!values base58 base64 base64+zstd jsonParsed

Encoding format for Account data

- `base58` is slow.
- `jsonParsed` encoding attempts to use program-specific state parsers to return
  more human-readable and explicit account state data.
- If `jsonParsed` is requested but a parser cannot be found, the field falls
  back to `base64` encoding, detectable when the `data` field is type `string`.

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover result
  "result": 24040,
  "id": 1
}
```

!type integer

Subscription id (needed to unsubscribe)

</APIMethod>

#### Notification format

The notification format is a <b>single</b> program account object as seen in the
[getProgramAccounts](/docs/rpc/http/getprogramaccounts) RPC HTTP method.

Base58 encoding:

```json
{
  "jsonrpc": "2.0",
  "method": "programNotification",
  "params": {
    "result": {
      "context": {
        "slot": 5208469
      },
      "value": {
        "pubkey": "H4vnBqifaSACnKa7acsxstsY1iV1bvJNxsCY7enrd1hq",
        "account": {
          "data": [
            "11116bv5nS2h3y12kD1yUKeMZvGcKLSjQgX6BeV7u1FrjeJcKfsHPXHRDEHrBesJhZyqnnq9qJeUuF7WHxiuLuL5twc38w2TXNLxnDbjmuR",
            "base58"
          ],
          "executable": false,
          "lamports": 33594,
          "owner": "11111111111111111111111111111111",
          "rentEpoch": 636,
          "space": 80
        }
      }
    },
    "subscription": 24040
  }
}
```

Parsed-JSON encoding:

```json
{
  "jsonrpc": "2.0",
  "method": "programNotification",
  "params": {
    "result": {
      "context": {
        "slot": 5208469
      },
      "value": {
        "pubkey": "H4vnBqifaSACnKa7acsxstsY1iV1bvJNxsCY7enrd1hq",
        "account": {
          "data": {
            "program": "nonce",
            "parsed": {
              "type": "initialized",
              "info": {
                "authority": "Bbqg1M4YVVfbhEzwA9SpC9FhsaG83YMTYoR4a8oTDLX",
                "blockhash": "LUaQTmM7WbMRiATdMMHaRGakPtCkc2GHtH57STKXs6k",
                "feeCalculator": {
                  "lamportsPerSignature": 5000
                }
              }
            }
          },
          "executable": false,
          "lamports": 33594,
          "owner": "11111111111111111111111111111111",
          "rentEpoch": 636,
          "space": 80
        }
      }
    },
    "subscription": 24040
  }
}
```
---
title: programUnsubscribe
hideTableOfContents: true
h1: programUnsubscribe RPC Method
---

Unsubscribe from program-owned account change notifications

<APIMethod>

```jsonc !!request
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "programUnsubscribe",
  "params": [
    // !hover 0
    0
  ]
}
```

### !params

#### !! 0

!type number  
!required

id of account Subscription to cancel

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover result
  "result": true,
  "id": 1
}
```

!type boolean

unsubscribe success message

</APIMethod>
---
title: rootSubscribe
hideTableOfContents: true
h1: rootSubscribe RPC Method
---

Subscribe to receive notification anytime a new root is set by the validator.

<APIMethod>

```jsonc !!request
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "rootSubscribe"
}
```

### !params

**None**

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover result
  "result": 0,
  "id": 1
}
```

!type integer

subscription id (needed to unsubscribe)

</APIMethod>

#### Notification Format:

The result is the latest root slot number.

```json
{
  "jsonrpc": "2.0",
  "method": "rootNotification",
  "params": {
    "result": 42,
    "subscription": 0
  }
}
```
---
title: rootUnsubscribe
hideTableOfContents: true
h1: rootUnsubscribe RPC Method
---

Unsubscribe from root notifications

<APIMethod>

```jsonc !!request
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "rootUnsubscribe",
  "params": [
    // !hover 0
    0
  ]
}
```

### !params

#### !! 0

!type number  
!required

subscription id to cancel

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover result
  "result": true,
  "id": 1
}
```

!type boolean

unsubscribe success message

</APIMethod>
---
title: signatureSubscribe
hideTableOfContents: true
h1: signatureSubscribe RPC Method
---

Subscribe to receive a notification when the transaction with the given
signature reaches the specified commitment level.

<Callout type="warn">
  This is a subscription to a single notification. It is automatically cancelled
  by the server once the notification, `signatureNotification`, is sent by the
  RPC.
</Callout>

<APIMethod>

```jsonc !!request
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "signatureSubscribe",
  "params": [
    // !hover 0
    "2EBVM6cB8vAAD93Ktr6Vd8p67XPbQzCJX47MpReuiCXJAtcjaxpvWpcg9Ege1Nr5Tk3a2GFrByT7WPBjdsTycY9b",
    // !hover(1:4) 1
    {
      // !hover commitment
      "commitment": "finalized",
      // !hover enableReceivedNotification
      "enableReceivedNotification": false
    }
  ]
}
```

### !params

#### !! 0

!type string  
!required

transaction signature, as base-58 encoded string

<Callout type="info">
  The transaction signature must be the first signature from the transaction
  (see [transaction id](/docs/references/terminology#transaction-id) for more
  details).
</Callout>

#### !! 1

!type object

Configuration object containing the following fields:

##### !! commitment

!type string

The commitment describes how finalized a block is at that point in time. See
[Configuring State Commitment](/docs/rpc#configuring-state-commitment).

##### !! enableReceivedNotification

!type boolean

Whether or not to subscribe for notifications when signatures are received by
the RPC, in addition to when they are processed.

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover result
  "result": 0,
  "id": 1
}
```

!type integer

subscription id (needed to unsubscribe)

</APIMethod>

#### Notification Format:

The notification will be an RpcResponse JSON object with value containing an
object with:

- `slot: <u64>` - The corresponding slot.
- `value: <object|string>` - a notification value of
  [`RpcSignatureResult`](https://github.com/solana-labs/solana/blob/6d28fd455b07e3557fc6c0c3ddf3ba03e3fe8482/rpc-client-api/src/response.rs#L265-L268),
  resulting in either:
  - when `enableReceivedNotification` is `true` and the signature is received:
    the literal string
    [`"receivedSignature"`](https://github.com/solana-labs/solana/blob/6d28fd455b07e3557fc6c0c3ddf3ba03e3fe8482/rpc-client-api/src/response.rs#L286-L288),
    or
  - when the signature is processed: `err: <object|null>`:
    - `null` if the transaction succeeded in being processed at the specified
      commitment level, or
    - a
      [`TransactionError`](https://github.com/solana-labs/solana/blob/6d28fd455b07e3557fc6c0c3ddf3ba03e3fe8482/sdk/src/transaction/error.rs#L15-L164),
      if the transaction failed

#### Example responses:

The following is an example response of a notification from a successfully
**processed** transactions:

```json
{
  "jsonrpc": "2.0",
  "method": "signatureNotification",
  "params": {
    "result": {
      "context": {
        "slot": 5207624
      },
      "value": {
        "err": null
      }
    },
    "subscription": 24006
  }
}
```

The following is an example response of a notification from a successfully
**received** transaction signature:

```json
{
  "jsonrpc": "2.0",
  "method": "signatureNotification",
  "params": {
    "result": {
      "context": {
        "slot": 5207624
      },
      "value": "receivedSignature"
    },
    "subscription": 24006
  }
}
```
---
title: signatureUnsubscribe
hideTableOfContents: true
h1: signatureUnsubscribe RPC Method
---

Unsubscribe from signature confirmation notification

<APIMethod>

```jsonc !!request
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "signatureUnsubscribe",
  "params": [
    // !hover 0
    0
  ]
}
```

### !params

#### !! 0

!type number  
!required

subscription id to cancel

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover result
  "result": true,
  "id": 1
}
```

!type boolean

unsubscribe success message

</APIMethod>
---
title: slotSubscribe
hideTableOfContents: true
h1: slotSubscribe RPC Method
---

Subscribe to receive notification anytime a slot is processed by the validator

<APIMethod>

```jsonc !!request
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "slotSubscribe"
}
```

### !params

**None**

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover result
  "result": 0,
  "id": 1
}
```

!type integer

Subscription id (needed to unsubscribe)

</APIMethod>

#### Notification Format:

The notification will be an object with the following fields:

- `parent: <u64>` - The parent slot
- `root: <u64>` - The current root slot
- `slot: <u64>` - The newly set slot value

Example:

```json
{
  "jsonrpc": "2.0",
  "method": "slotNotification",
  "params": {
    "result": {
      "parent": 75,
      "root": 44,
      "slot": 76
    },
    "subscription": 0
  }
}
```
---
title: slotsUpdatesSubscribe
hideTableOfContents: true
h1: slotsUpdatesSubscribe RPC Method
---

Subscribe to receive a notification from the validator on a variety of updates
on every slot

<Callout type="warn">
  This subscription is unstable. The format of this subscription may change in
  the future, and may not always be supported.
</Callout>

<APIMethod>

```jsonc !!request
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "slotsUpdatesSubscribe"
}
```

### !params

**None**

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover result
  "result": 0,
  "id": 1
}
```

!type integer

Subscription id (needed to unsubscribe)

</APIMethod>

### Notification Format

The notification will be an object with the following fields:

- `err: <string|undefined>` - The error message. Only present if the update is
  of type "dead".
- `parent: <u64|undefined>` - The parent slot. Only present if the update is of
  type "createdBank".
- `slot: <u64>` - The newly updated slot
- `stats: <object|undefined>` - The error message. Only present if the update is
  of type "frozen". An object with the following fields:
  - `maxTransactionsPerEntry: <u64>`,
  - `numFailedTransactions: <u64>`,
  - `numSuccessfulTransactions: <u64>`,
  - `numTransactionEntries: <u64>`,
- `timestamp: <i64>` - The Unix timestamp of the update in milliseconds
- `type: <string>` - The update type, one of:
  - "firstShredReceived"
  - "completed"
  - "createdBank"
  - "frozen"
  - "dead"
  - "optimisticConfirmation"
  - "root"

```shell
{
  "jsonrpc": "2.0",
  "method": "slotsUpdatesNotification",
  "params": {
    "result": {
      "parent": 75,
      "slot": 76,
      "timestamp": 1625081266243,
      "type": "optimisticConfirmation"
    },
    "subscription": 0
  }
}
```
---
title: slotsUpdatesUnsubscribe
hideTableOfContents: true
h1: slotsUpdatesUnsubscribe RPC Method
---

Unsubscribe from slot-update notifications

<APIMethod>

```jsonc !!request
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "slotsUpdatesUnsubscribe",
  "params": [
    // !hover 0
    0
  ]
}
```

### !params

#### !! 0

!type number  
!required

subscription id to cancel

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover result
  "result": true,
  "id": 1
}
```

!type boolean

unsubscribe success message

</APIMethod>
---
title: slotUnsubscribe
hideTableOfContents: true
h1: slotUnsubscribe RPC Method
---

Unsubscribe from slot notifications

<APIMethod>

```jsonc !!request
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "slotUnsubscribe",
  "params": [
    // !hover 0
    0
  ]
}
```

### !params

#### !! 0

!type integer  
!required

subscription id to cancel

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover result
  "result": true,
  "id": 1
}
```

!type boolean

unsubscribe success message

</APIMethod>
---
title: getAccountInfo
hideTableOfContents: true
h1: getAccountInfo RPC Method
---

Returns all information associated with the account of provided Pubkey

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "getAccountInfo",
  "params": [
    // !hover pubkey
    "vines1vzrYbzLMRdu58ou5XTby4qAqVRLmqo36NKPTg",
    // !hover(1:3) 1
    {
      // !hover commitment
      "commitment": "finalized",
      // !hover encoding
      "encoding": "base58"
    }
  ]
}
```

```ts !!request title="Kit"
import { address, createSolanaRpc } from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

// !hover pubkey
const publicKey = address("vines1vzrYbzLMRdu58ou5XTby4qAqVRLmqo36NKPTg");
const accountInfo = await rpc.getAccountInfo(publicKey).send();

console.log("Account Info:", accountInfo);
```

```ts !!request title="web3.js"
import { Connection, PublicKey, clusterApiUrl } from "@solana/web3.js";

const connection = new Connection(clusterApiUrl("devnet"), "confirmed");
// !hover pubkey
const publicKey = new PublicKey("vines1vzrYbzLMRdu58ou5XTby4qAqVRLmqo36NKPTg");
const accountInfo = await connection.getAccountInfo(publicKey);

console.log("Account Info:", JSON.stringify(accountInfo, null, 2));
```

```rs !!request title="Rust"
use solana_client::nonblocking::rpc_client::RpcClient;
use solana_sdk::{commitment_config::CommitmentConfig, pubkey::Pubkey};
use anyhow::Result;
use std::str::FromStr;

#[tokio::main]
async fn main() -> Result<()> {
    let client = RpcClient::new_with_commitment(
        String::from("https://api.devnet.solana.com"),
        CommitmentConfig::confirmed()
    );
    // !hover pubkey
    let pubkey = Pubkey::from_str("vines1vzrYbzLMRdu58ou5XTby4qAqVRLmqo36NKPTg")?;
    let account = client.get_account(&pubkey).await?;

    println!("{:#?}", account);

    Ok(())
}
```

### !params

#### !! pubkey

!type string
!required

Pubkey of account to query, as base-58 encoded string.

#### !! 1

!type object

Configuration object.

##### !! commitment

!type string

The commitment describes how finalized a block is at that point in time. See
[Configuring State Commitment](/docs/rpc#configuring-state-commitment).

##### !! encoding

!type string
!values base58 base64 base64+zstd jsonParsed

Encoding format for Account data. See
[Parsed Responses](/docs/rpc#parsed-responses).

- `base58` is slow and limited to less than 129 bytes of Account data.
- `base64` will return base64 encoded data for Account data of any size.
- `base64+zstd` compresses the Account data using
  [Zstandard](https://facebook.github.io/zstd/) and base64-encodes the result.
- `jsonParsed` encoding attempts to use program-specific state parsers to return
  more human-readable and explicit account state data.
- If `jsonParsed` is requested but a parser cannot be found, the field falls
  back to `base64` encoding, detectable when the `data` field is type `string`.

##### !! dataSlice

!type object

Request a slice of the account&apos;s data.

- `length: <usize>` - number of bytes to return
- `offset: <usize>` - byte offset from which to start reading

<Callout type="info">
  Data slicing is only available for `base58`, `base64`, or `base64+zstd`
  encodings.
</Callout>

##### !! minContextSlot

!type string

The minimum slot that the request can be evaluated at.

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  "result": {
    "context": { "apiVersion": "2.0.15", "slot": 341197053 },
    // !hover(1:8) result
    "value": {
      // !hover data
      "data": ["", "base58"],
      // !hover executable
      "executable": false,
      // !hover lamports
      "lamports": 88849814690250,
      // !hover owner
      "owner": "11111111111111111111111111111111",
      // !hover rentEpoch
      "rentEpoch": 18446744073709551615,
      // !hover space
      "space": 0
    }
  },
  "id": 1
}
```

!type object | null

If the requested account doesn't exist result will be `null`. Otherwise, an
object containing:

#### !! data

!type \[string,encoding\] | object

Data associated with the account, either as encoded binary data or JSON format
`{<program>: <state>}` - depending on encoding parameter

#### !! executable

!type bool

Boolean indicating if the account contains a program (and is strictly read-only)

#### !! lamports
!type u64

Number of lamports assigned to this account

#### !! owner

!type string

base-58 encoded Pubkey of the program this account has been assigned to

#### !! rentEpoch

!type u64

The epoch at which this account will next owe rent, as u64

#### !! space

!type u64

The data size of the account

</APIMethod>
---
title: getBalance
hideTableOfContents: true
h1: getBalance RPC Method
---

Returns the lamport balance of the account of provided Pubkey

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "getBalance",
  "params": [
    // !hover pubkey
    "83astBRguLMdt2h5U1Tpdq5tjFoJ6noeGwaY3mDLVcri",
    {
      // !hover commitment
      "commitment": "finalized"
    }
  ]
}
```

```ts !!request title="Kit"
import { address, createSolanaRpc } from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

// !hover pubkey
const publicKey = address("83astBRguLMdt2h5U1Tpdq5tjFoJ6noeGwaY3mDLVcri");
const balance = await rpc.getBalance(publicKey).send();

console.log("Account Balance:", balance);
```

```ts !!request title="web3.js"
import { Connection, PublicKey, clusterApiUrl } from "@solana/web3.js";

const connection = new Connection(clusterApiUrl("devnet"), "confirmed");
// !hover pubkey
const publicKey = new PublicKey("83astBRguLMdt2h5U1Tpdq5tjFoJ6noeGwaY3mDLVcri");
const balance = await connection.getBalance(publicKey);

console.log("Account Balance:", JSON.stringify(balance, null, 2));
```

```rs !!request title="Rust"
use anyhow::Result;
use solana_client::nonblocking::rpc_client::RpcClient;
use solana_sdk::{
    commitment_config::CommitmentConfig, native_token::LAMPORTS_PER_SOL, pubkey::Pubkey,
};
use std::str::FromStr;

#[tokio::main]
async fn main() -> Result<()> {
    let client = RpcClient::new_with_commitment(
        String::from("https://api.devnet.solana.com"),
        CommitmentConfig::confirmed(),
    );

    // !hover pubkey
    let pubkey = Pubkey::from_str("83astBRguLMdt2h5U1Tpdq5tjFoJ6noeGwaY3mDLVcri")?;
    let balance = client.get_balance(&pubkey).await?;

    println!("{:#?} SOL", balance / LAMPORTS_PER_SOL);

    Ok(())
}
```

### !params

#### !! pubkey

!type string
!required

Pubkey of account to query, as base-58 encoded string.

#### !! 1

!type object

Configuration object.

##### !! commitment

!type string

The commitment describes how finalized a block is at that point in time. See
[Configuring State Commitment](/docs/rpc#configuring-state-commitment).

##### !! minContextSlot

!type number

The minimum slot that the request can be evaluated at.

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  "result": {
    "context": { "slot": 1 },
    // !hover result
    "value": 0
  },
  "id": 1
}
```

!type u64

RpcResponse JSON object with value field set to the balance.

</APIMethod>
---
title: getBlock
hideTableOfContents: true
h1: getBlock RPC Method
---

Returns identity and transaction information about a confirmed block in the
ledger

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "getBlock",
  "params": [
    // !hover slot number
    378967388,
    // !hover(1:6) 1
    {
      // !hover commitment
      "commitment": "finalized",
      // !hover encoding
      "encoding": "json",
      // !hover transactionDetails
      "transactionDetails": "full",
      // !hover maxSupportedTransactionVersion
      "maxSupportedTransactionVersion": 0,
      // !hover rewards
      "rewards": false
    }
  ]
}
```

```ts !!request title="Kit"
import { createSolanaRpc } from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

// !hover slot number
const slot_number = BigInt(377261141);

let block = await rpc
  .getBlock(
    slot_number,
    // !hover(1:6) 1
    {
      // !hover commitment
      commitment: "finalized",
      // !hover encoding
      encoding: "json",
      // !hover transactionDetails
      transactionDetails: "full",
      // !hover maxSupportedTransactionVersion
      maxSupportedTransactionVersion: 0,
      // !hover rewards
      rewards: false,
    },
  )
  .send();

console.log("block:", block);
```

```ts !!request title="web3.js"
import { Connection, clusterApiUrl } from "@solana/web3.js";

const connection = new Connection(clusterApiUrl("devnet"), "confirmed");

// !hover slot number
const slot_number = 377261141;

const block = await connection.getBlock(
  slot_number,
  // !hover(1:6) 1
  {
    // !hover commitment
    commitment: "finalized",
    // !hover transactionDetails
    transactionDetails: "full",
    // !hover maxSupportedTransactionVersion
    maxSupportedTransactionVersion: 0,
    // !hover rewards
    rewards: false,
  },
);

console.log("block:", block);
```

```rs !!request title="Rust"
use anyhow::Result;
use solana_client::nonblocking::rpc_client::RpcClient;
use solana_sdk::commitment_config::CommitmentConfig;
use solana_transaction_status_client_types::{TransactionDetails, UiTransactionEncoding};

#[tokio::main]
async fn main() -> Result<()> {
    let client = RpcClient::new_with_commitment(
        String::from("https://api.devnet.solana.com"),
        CommitmentConfig::confirmed(),
    );

    // !hover slot number
    let slot_number = 377261141;

  // !hover(1:6) 1
    let config = solana_client::rpc_config::RpcBlockConfig {
        // !hover encoding
        encoding: UiTransactionEncoding::Base58.into(),
        // !hover transactionDetails
        transaction_details: TransactionDetails::Full.into(),
        // !hover rewards
        rewards: None,
        // !hover commitment
        commitment: CommitmentConfig::finalized().into(),
        // !hover maxSupportedTransactionVersion
        max_supported_transaction_version: Some(0),
    };
    let block = client.get_block_with_config(slot_number, config).await?;

    println!("Block: {:#?}", block);

    Ok(())
}
```

### !params

#### !! slot number

!type u64
!required

Slot number.

#### !! 1

!type object

Configuration object.

##### !! commitment

!type string
!values confirmed finalized
!default finalized

The commitment describes how finalized a block is at that point in time. See
[Configuring State Commitment](/docs/rpc#configuring-state-commitment).

- `processed` is not supported.

##### !! encoding

!type string
!values json jsonParsed base58 base64
!default json

Encoding format for each returned transaction. See
[Parsed Responses](/docs/rpc#parsed-responses).

- `jsonParsed` attempts to use program-specific instruction parsers to return
  more human-readable and explicit data in the
  `transaction.message.instructions` list.
- If `jsonParsed` is requested but a parser cannot be found, the instruction
  falls back to regular JSON encoding (`accounts`, `data`, and `programIdIndex`
  fields).

##### !! transactionDetails

!type string
!values full accounts signatures none
!default full

Level of transaction detail to return.

- If `accounts` are requested, transaction details only include signatures and
  an annotated list of accounts in each transaction.
- Transaction metadata is limited to only: fee, err, pre_balances,
  post_balances, pre_token_balances, and post_token_balances.

##### !! maxSupportedTransactionVersion

!type number
!values 0
!default 0

Currently, the only valid value for this parameter is `0`.
Setting it to `0` allows you to fetch all transactions, including both Versioned and legacy transactions.

This parameter determines the maximum transaction version that will be returned in the response.
If you request a transaction with a higher version than this value, an error will be returned.
If you omit this parameter, only legacy transactions will be returned—any versioned transaction will result in an error.


##### !! rewards

!type bool

Whether to populate the rewards array. If parameter not provided, the default
includes rewards.

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover(1:52) result
  "result": {
    // !hover blockHeight
    "blockHeight": 428,
    // !hover blockTime
    "blockTime": null,
    // !hover blockhash
    "blockhash": "3Eq21vXNB5s86c62bVuUfTeaMif1N2kUqRPBmGRJhyTA",
    // !hover parentSlot
    "parentSlot": 429,
    // !hover previousBlockhash
    "previousBlockhash": "mfcyqEXB3DnHXki6KjjmZck6YjmZLvpAByy2fj4nh6B",
    // !hover(1:45) transactions
    "transactions": [
      {
        // !collapse(1:13) collapsed
        "meta": {
          "err": null,
          "fee": 5000,
          "innerInstructions": [],
          "logMessages": [],
          "postBalances": [499998932500, 26858640, 1, 1, 1],
          "postTokenBalances": [],
          "preBalances": [499998937500, 26858640, 1, 1, 1],
          "preTokenBalances": [],
          "rewards": null,
          "status": {
            "Ok": null
          }
        },
        // !collapse(1:26) collapsed
        "transaction": {
          "message": {
            "accountKeys": [
              "3UVYmECPPMZSCqWKfENfuoTv51fTDTWicX9xmBD2euKe",
              "AjozzgE83A3x1sHNUR64hfH7zaEBWeMaFuAN9kQgujrc",
              "SysvarS1otHashes111111111111111111111111111",
              "SysvarC1ock11111111111111111111111111111111",
              "Vote111111111111111111111111111111111111111"
            ],
            "header": {
              "numReadonlySignedAccounts": 0,
              "numReadonlyUnsignedAccounts": 3,
              "numRequiredSignatures": 1
            },
            "instructions": [
              {
                "accounts": [1, 2, 3, 0],
                "data": "37u9WtQpcm6ULa3WRQHmj49EPs4if7o9f1jSRVZpm2dvihR9C8jY4NqEwXUbLwx15HBSNcP1",
                "programIdIndex": 4
              }
            ],
            "recentBlockhash": "mfcyqEXB3DnHXki6KjjmZck6YjmZLvpAByy2fj4nh6B"
          },
          "signatures": [
            "2nBhEBYYvfaAe16UMNqRHre4YNSskvuYgx3M6E4JP1oDYvZEJHvoPzyUidNgNX5r9sTyN1J9UxtbCXy2rqYcuyuv"
          ]
        }
      }
    ]
  },
  "id": 1
}
```

!type object | null

If specified block is not confirmed result will be `null`. Otherwise, an object
containing:

##### !! blockHeight

!type u64 | null

The number of blocks beneath this block.

##### !! blockTime

!type i64 | null

Estimated production time, as Unix timestamp (seconds since the Unix epoch).
`null` if not available.

##### !! blockhash

!type string

The blockhash of this block, as base-58 encoded string

##### !! parentSlot

!type u64

The slot index of this block's parent

##### !! previousBlockhash

!type string

The blockhash of this block's parent, as base-58 encoded string; if the parent
block is not available due to ledger cleanup, this field will return
"11111111111111111111111111111111"

##### !! transactions

!type array

Present if "full" transaction details are requested; an array of JSON objects
containing:

- `transaction: <object|[string,encoding]>` -
  [Transaction](/docs/rpc/json-structures#transactions) object, either in JSON
  format or encoded binary data, depending on encoding parameter.
- `meta: <object>` - Transaction status
  [metadata object](/docs/rpc/json-structures#transaction-status-metadata) or
  `null`.

</APIMethod>
---
title: getBlockCommitment
hideTableOfContents: true
h1: getBlockCommitment RPC Method
---

Returns commitment for particular block

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "getBlockCommitment",
  "params": [
    // !hover slot number
    5
  ]
}
```

```ts !!request title="Kit"
import { createSolanaRpc } from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

// !hover slot number
const slot_number = BigInt(5);

let blockCommitment = await rpc.getBlockCommitment(slot_number).send();

console.log("block commitment:", blockCommitment);
```

### !params

#### !! slot number

!type u64
!required

Block number, identified by Slot.

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover(1:6) result
  "result": {
    // !hover(1:4) commitment
    "commitment": [
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 10, 32
    ],
    // !hover totalStake
    "totalStake": 42
  },
  "id": 1
}
```

!type object

The result field will be a JSON object containing:

##### !! commitment

!type array | null

Array of u64 integers logging the amount of cluster stake in lamports that has
voted on the block at each depth from 0 to `MAX_LOCKOUT_HISTORY`.

##### !! totalStake

!type number

Total active stake, in lamports, of the current epoch.

</APIMethod>
---
title: getBlockHeight
hideTableOfContents: true
h1: getBlockHeight RPC Method
---

Returns the current block height of the node

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "getBlockHeight",
  "params": [
    {
      // !hover commitment
      "commitment": "finalized"
    }
  ]
}
```

```ts !!request title="Kit"
import { createSolanaRpc } from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

let blockHeight = await rpc.getBlockHeight().send();

console.log("block height:", blockHeight);
```

```ts !!request title="web3.js"
import { Connection, clusterApiUrl } from "@solana/web3.js";

const connection = new Connection(clusterApiUrl("devnet"), "confirmed");

let blockHeight = await connection.getBlockHeight();

console.log("block height:", blockHeight);
```

```rs !!request title="Rust"
use anyhow::Result;
use solana_client::nonblocking::rpc_client::RpcClient;
use solana_sdk::commitment_config::CommitmentConfig;

#[tokio::main]
async fn main() -> Result<()> {
    let client = RpcClient::new_with_commitment(
        String::from("https://api.devnet.solana.com"),
        CommitmentConfig::confirmed(),
    );

    let block_height = client.get_block_height().await?;

    println!("Block height: {:#?}", block_height);

    Ok(())
}
```

### !params

#### !! 0

!type object

Configuration object

##### !! commitment

!type string

The commitment describes how finalized a block is at that point in time. See
[Configuring State Commitment](/docs/rpc#configuring-state-commitment).

##### !! minContextSlot

!type number

The minimum slot that the request can be evaluated at.

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover result
  "result": 1233,
  "id": 1
}
```

!type u64

Current block height.

</APIMethod>
---
title: getBlockProduction
hideTableOfContents: true
h1: getBlockProduction RPC Method
---

Returns recent block production information from the current or previous epoch.

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "getBlockProduction",
  "params": [
    // !hover(1:3) 0
    {
      // !hover commitment
      "commitment": "finalized"
    }
  ]
}
```

```ts !!request title="Kit"
import { createSolanaRpc } from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

let blockProduction = await rpc.getBlockProduction().send();

console.log("block production:", blockProduction);
```

```ts !!request title="web3.js"
import { Connection, clusterApiUrl } from "@solana/web3.js";

const connection = new Connection(clusterApiUrl("devnet"), "confirmed");

let blockProduction = await connection.getBlockProduction();

console.log("block production:", blockProduction);
```

```rs !!request title="Rust"
use anyhow::Result;
use solana_client::nonblocking::rpc_client::RpcClient;
use solana_sdk::commitment_config::CommitmentConfig;

#[tokio::main]
async fn main() -> Result<()> {
    let client = RpcClient::new_with_commitment(
        String::from("https://api.devnet.solana.com"),
        CommitmentConfig::confirmed(),
    );

    let block_production = client.get_block_production().await?;

    println!("Block production: {:#?}", block_production);

    Ok(())
}
```

### !params

#### !! 0

!type object

Configuration object

##### !! commitment

!type string

The commitment describes how finalized a block is at that point in time. See
[Configuring State Commitment](/docs/rpc#configuring-state-commitment).

##### !! identity

!type string

Only return results for this validator identity (base-58 encoded).

##### !! range

!type object

Slot range to return block production for. If parameter not provided, defaults
to current epoch.

- `firstSlot: <u64>` - first slot to return block production information for
  (inclusive)
- (optional) `lastSlot: <u64>` - last slot to return block production
  information for (inclusive). If parameter not provided, defaults to the
  highest slot

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  "result": {
    "context": {
      "slot": 9887
    },
    // !hover(1:9) result
    "value": {
      // !hover(1:3) byIdentity
      "byIdentity": {
        "85iYT5RuzRTDgjyRa3cP8SYhM2j21fj7NhfJ3peu1DPr": [9888, 9886]
      },
      // !hover(1:4) range
      "range": {
        "firstSlot": 0,
        "lastSlot": 9887
      }
    }
  },
  "id": 1
}
```

!type object

The result will be an RpcResponse JSON object with value equal to:

##### !! byIdentity

!type object

A dictionary of validator identities, as base-58 encoded strings. Value is a two
element array containing the number of leader slots and the number of blocks
produced.

##### !! range

!type object

Block production slot range

- `firstSlot: <u64>` - first slot of the block production information
  (inclusive)
- `lastSlot: <u64>` - last slot of block production information (inclusive)

</APIMethod>
---
title: getBlocks
hideTableOfContents: true
h1: getBlocks RPC Method
---

Returns a list of confirmed blocks between two slots

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "getBlocks",
  "params": [
    // !hover start slot
    5,
    // !hover end slot
    10,
    // !hover(1:3) 2
    {
      // !hover commitment
      "commitment": "finalized"
    }
  ]
}
```

```ts !!request title="Kit"
import { createSolanaRpc } from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

// !hover start slot
let startSlot = BigInt(377268280);
// !hover end slot
let endSlot = BigInt(377268285);
let blocks = await rpc.getBlocks(startSlot, endSlot).send();

console.log("Blocks produced:", blocks);
```


```ts !!request title="web3.js"
import { Connection, clusterApiUrl } from "@solana/web3.js";

const connection = new Connection(clusterApiUrl("devnet"), "confirmed");

// !hover start slot
let startSlot = 377268280;
// !hover end slot
let endSlot = 377268285;
let blocks = await connection.getBlocks(startSlot, endSlot);

console.log("Blocks produced:", blocks);
```


```rs !!request title="Rust"
use anyhow::Result;
use solana_client::nonblocking::rpc_client::RpcClient;
use solana_sdk::commitment_config::CommitmentConfig;

#[tokio::main]
async fn main() -> Result<()> {
    let client = RpcClient::new_with_commitment(
        String::from("https://api.devnet.solana.com"),
        CommitmentConfig::confirmed(),
    );

    // !hover start slot
    let start_slot = 377268280;
    // !hover end slot
    let end_slot = 377268285;
    let blocks = client.get_blocks(start_slot, Some(end_slot)).await?;

    println!("Blocks produced: {:#?}", blocks);

    Ok(())
}
```

### !params

#### !! start slot

!type u64
!required

Start slot

#### !! end slot

!type u64

End slot (must be no more than 500,000 blocks higher than the `start_slot`)

#### !! 2

!type object

Configuration object

##### !! commitment

!type string

The commitment describes how finalized a block is at that point in time. See
[Configuring State Commitment](/docs/rpc#configuring-state-commitment).

- "processed" is not supported

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover result
  "result": [5, 6, 7, 8, 9, 10],
  "id": 1
}
```

!type array

An array of u64 integers listing confirmed blocks between `start_slot` and
either `end_slot` - if provided, or latest confirmed slot, inclusive. Max range
allowed is 500,000 slots.

</APIMethod>
---
title: getBlocksWithLimit
hideTableOfContents: true
h1: getBlocksWithLimit RPC Method
---

Returns a list of confirmed blocks starting at the given slot

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "getBlocksWithLimit",
  "params": [
    // !hover start slot
    5,
    // !hover limit
    3
  ],
  // !hover(1:3) 2
  {
    // !hover commitment
    "commitment": "finalized"
  }
}
```

```ts !!request title="Kit"
import { createSolanaRpc } from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

// !hover start slot
let startSlot = BigInt(377268280);
// !hover limit
let limit = 5;
let blocks = await rpc.getBlocksWithLimit(startSlot, limit).send();

console.log("blocks produced:", blocks);
```

```rs !!request title="Rust"
use anyhow::Result;
use solana_client::nonblocking::rpc_client::RpcClient;
use solana_sdk::commitment_config::CommitmentConfig;

#[tokio::main]
async fn main() -> Result<()> {
    let client = RpcClient::new_with_commitment(
        String::from("https://api.devnet.solana.com"),
        CommitmentConfig::confirmed(),
    );

    // !hover start slot
    let start_slot = 377268280;
    // !hover limit
    let limit = 5;

    let blocks = client.get_blocks_with_limit(start_slot, limit).await?;

    println!("Blocks produced: {:?}", blocks);

    Ok(())
}
```

### !params

#### !! start slot

!type u64
!required

Start slot

#### !! limit

!type u64

Limit (must be no more than 500,000 blocks higher than the `start_slot`)

#### !! 2

!type object

Configuration object

##### !! commitment

!type string

The commitment describes how finalized a block is at that point in time. See
[Configuring State Commitment](/docs/rpc#configuring-state-commitment).

- "processed" is not supported

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover result
  "result": [5, 6, 7],
  "id": 1
}
```

!type array

An array of u64 integers listing confirmed blocks starting at `start_slot` for
up to `limit` blocks, inclusive.

</APIMethod>
---
title: getBlockTime
hideTableOfContents: true
h1: getBlockTime RPC Method
---

Returns the estimated production time of a block.

<Callout type="info">
  Each validator reports their UTC time to the ledger on a regular interval by
  intermittently adding a timestamp to a Vote for a particular block. A
  requested block's time is calculated from the stake-weighted mean of the Vote
  timestamps in a set of recent blocks recorded on the ledger.
</Callout>

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "getBlockTime",
  "params": [
    // !hover slot number
    5
  ]
}
```

```ts !!request title="Kit"
import { createSolanaRpc } from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

// !hover slot number
let slotNumber = BigInt(377268280);
let blockTime = await rpc.getBlockTime(slotNumber).send();

console.log("Block time:", blockTime);
```

```ts !!request title="web3.js"
import { Connection, clusterApiUrl } from "@solana/web3.js";

const connection = new Connection(clusterApiUrl("devnet"), "confirmed");

// !hover slot number
let slotNumber = 377268280;
let blockTime = await connection.getBlockTime(slotNumber);

console.log("Block time:", blockTime);
```

```rs !!request title="Rust"
use anyhow::Result;
use solana_client::nonblocking::rpc_client::RpcClient;
use solana_sdk::commitment_config::CommitmentConfig;

#[tokio::main]
async fn main() -> Result<()> {
    let client = RpcClient::new_with_commitment(
        String::from("https://api.devnet.solana.com"),
        CommitmentConfig::confirmed(),
    );

    // !hover slot number
    let slot_number = 377268280;

    let block_time = client.get_block_time(slot_number).await?;

    println!("Blocks time: {:?}", block_time);

    Ok(())
}
```

### !params

#### !! slot number

!type u64
!required

Block number, identified by Slot

### !!result available

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover result
  "result": 1574721591,
  "id": 1
}
```

!type i64

Estimated production time, as Unix timestamp (seconds since the Unix epoch)

### !!result unavailable

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover(1:4) result
  "error": {
    "code": -32004,
    "message": "Block not available for slot 150"
  },
  "id": 1
}
```

!type object

Error object

</APIMethod>
---
title: getClusterNodes
hideTableOfContents: true
h1: getClusterNodes RPC Method
---

Returns information about all the nodes participating in the cluster

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "getClusterNodes"
}
```

```ts !!request title="Kit"
import { createSolanaRpc } from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

let nodes = await rpc.getClusterNodes().send();

console.log(nodes);
```

```ts !!request title="web3.js"
import { Connection, clusterApiUrl } from "@solana/web3.js";

const connection = new Connection(clusterApiUrl("devnet"), "confirmed");

let nodes = await connection.getClusterNodes();

console.log(nodes);
```

```rs !!request title="Rust"
use anyhow::Result;
use solana_client::nonblocking::rpc_client::RpcClient;
use solana_sdk::commitment_config::CommitmentConfig;

#[tokio::main]
async fn main() -> Result<()> {
    let client = RpcClient::new_with_commitment(
        String::from("https://api.devnet.solana.com"),
        CommitmentConfig::confirmed(),
    );

    let block_time = client.get_cluster_nodes().await?;

    println!("{:#?}", block_time);

    Ok(())
}
```

### !params

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover(1:9) result
  "result": [
    {
      // !hover featureSet
      "featureSet": 3073396398,
      // !hover gossip
      "gossip": "10.239.6.48:8001",
      // !hover pubkey
      "pubkey": "9QzsJf7LPLj8GkXbYT3LFDKqsj2hHG7TA3xinJHu8epQ",
      // !hover rpc
      "rpc": "10.239.6.48:8899",
      // !hover shredVersion
      "shredVersion": 2405,
      // !hover tpu
      "tpu": "10.239.6.48:8856",
      // !hover version
      "version": "1.0.0 c375ce1f"
    }
  ],
  "id": 1
}
```

!type array

The result field will be an array of JSON objects, each with the following sub
fields:

##### !! featureSet

!type u32 | null

The unique identifier of the node's feature set

##### !! gossip

!type string | null

Gossip network address for the node

##### !! pubkey

!type string

Node public key, as base-58 encoded string

##### !! rpc

!type string | null

JSON RPC network address for the node, or `null` if the JSON RPC service is not
enabled


##### !! shredVersion

!type u16 | null

The shred version the node has been configured to use

##### !! tpu

!type string | null

TPU network address for the node

##### !! version

!type string | null

The software version of the node, or `null` if the version information is not
available

</APIMethod>
---
title: getEpochInfo
hideTableOfContents: true
h1: getEpochInfo RPC Method
---

Returns information about the current epoch

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "getEpochInfo",
  "params": [
    // !hover(1:3) 0
    {
      // !hover commitment
      "commitment": "finalized"
    }
  ]
}
```

```ts !!request title="Kit"
import { createSolanaRpc } from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

let epochInfo = await rpc.getEpochInfo().send();

console.log(epochInfo);
```

```ts !!request title="web3.js"
import { Connection, clusterApiUrl } from "@solana/web3.js";

const connection = new Connection(clusterApiUrl("devnet"), "confirmed");

let epochInfo = await connection.getEpochInfo();

console.log(epochInfo);
```

```rs !!request title="Rust"
use anyhow::Result;
use solana_client::nonblocking::rpc_client::RpcClient;
use solana_sdk::commitment_config::CommitmentConfig;

#[tokio::main]
async fn main() -> Result<()> {
    let client = RpcClient::new_with_commitment(
        String::from("https://api.devnet.solana.com"),
        CommitmentConfig::confirmed(),
    );

    let epoch_info = client.get_epoch_info().await?;

    println!("{:#?}", epoch_info);

    Ok(())
}
```

### !params

#### !! 0

!type object

Configuration object.

##### !! commitment

!type string

The commitment describes how finalized a block is at that point in time. See
[Configuring State Commitment](/docs/rpc#configuring-state-commitment).

##### !! minContextSlot

!type number

The minimum slot that the request can be evaluated at.

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover(1:8) result
  "result": {
    // !hover absoluteSlot
    "absoluteSlot": 166598,
    // !hover blockHeight
    "blockHeight": 166500,
    // !hover epoch
    "epoch": 27,
    // !hover slotIndex
    "slotIndex": 2790,
    // !hover slotsInEpoch
    "slotsInEpoch": 8192,
    // !hover transactionCount
    "transactionCount": 22661093
  },
  "id": 1
}
```

!type object

The result field will be an object with the following fields:

##### !! absoluteSlot

!type u64

The current slot

##### !! blockHeight

!type u64

The current block height

##### !! epoch

!type u64

The current epoch

##### !! slotIndex

!type u64

The current slot relative to the start of the current epoch

##### !! slotsInEpoch

!type u64

The number of slots in this epoch

##### !! transactionCount

!type u64 | null

Total number of transactions processed without error since genesis

</APIMethod>
---
title: getEpochSchedule
hideTableOfContents: true
h1: getEpochSchedule RPC Method
---

Returns the epoch schedule information from this cluster

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "getEpochSchedule"
}
```

```ts !!request title="Kit"
import { createSolanaRpc } from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

let epochSchedule = await rpc.getEpochSchedule().send();

console.log(epochSchedule);
```

```ts !!request title="web3.js"
import { Connection, clusterApiUrl } from "@solana/web3.js";

const connection = new Connection(clusterApiUrl("devnet"), "confirmed");

let epochSchedule = await connection.getEpochSchedule();

console.log(epochSchedule);
```

```rs !!request title="Rust"
use anyhow::Result;
use solana_client::nonblocking::rpc_client::RpcClient;
use solana_sdk::commitment_config::CommitmentConfig;

#[tokio::main]
async fn main() -> Result<()> {
    let client = RpcClient::new_with_commitment(
        String::from("https://api.devnet.solana.com"),
        CommitmentConfig::confirmed(),
    );

    let epoch_schedule = client.get_epoch_schedule().await?;

    println!("{:#?}", epoch_schedule);

    Ok(())
}
```

### !params

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover(1:7) result
  "result": {
    // !hover firstNormalEpoch
    "firstNormalEpoch": 8,
    // !hover firstNormalSlot
    "firstNormalSlot": 8160,
    // !hover leaderScheduleSlotOffset
    "leaderScheduleSlotOffset": 8192,
    // !hover slotsPerEpoch
    "slotsPerEpoch": 8192,
    // !hover warmup
    "warmup": true
  },
  "id": 1
}
```

!type object

The result field will be an object with the following fields:

##### !! firstNormalEpoch

!type u64

First normal-length epoch, `log2(slotsPerEpoch) - log2(MINIMUM_SLOTS_PER_EPOCH)`

##### !! firstNormalSlot

!type u64

Minimum number of slots in an epoch,
`MINIMUM_SLOTS_PER_EPOCH * (2.pow(firstNormalEpoch) - 1)`

##### !! leaderScheduleSlotOffset

!type u64

The number of slots before beginning of an epoch to calculate a leader schedule
for that epoch.

##### !! slotsPerEpoch

!type u64

The maximum number of slots in each epoch.

##### !! warmup

!type bool

Whether epochs start short and grow.

</APIMethod>
---
title: getFeeForMessage
hideTableOfContents: true
h1: getFeeForMessage RPC Method
---

Get the fee the network will charge for a particular Message

<Callout type="warn" title={"Version Restriction"}>
  This method is only available in `solana-core` v1.9 or newer. Please use
  [getFees](/docs/rpc/deprecated/getfees) for `solana-core` v1.8 and below.
</Callout>

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "getFeeForMessage",
  "params": [
    // !hover message
    "AQABAgIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEBAQAA",
    // !hover(1:3) 1
    {
      // !hover commitment
      "commitment": "processed"
    }
  ]
}
```

```ts !!request title="Kit"
import {
  createSolanaRpc,
  getBase64Encoder,
  type TransactionMessageBytesBase64,
} from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

// !hover message
let message =
  "AQABAgIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEBAQAA";

let fee = await rpc
  .getFeeForMessage(message as TransactionMessageBytesBase64)
  .send();

console.log(fee);
```

```ts !!request title="web3.js"
import { Connection, Message, clusterApiUrl } from "@solana/web3.js";

const connection = new Connection(clusterApiUrl("devnet"), "confirmed");

// !hover message
let b64Message =
  "AQABAgIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEBAQAA";
let message = Message.from(Buffer.from(b64Message, "base64"));

let fee = await connection.getFeeForMessage(message);

console.log(fee);
```

```rs !!request title="Rust"
use anyhow::Result;
use base64::{Engine as _, engine::general_purpose};

use solana_client::nonblocking::rpc_client::RpcClient;
use solana_sdk::{commitment_config::CommitmentConfig, message::Message};

#[tokio::main]
async fn main() -> Result<()> {
    let client = RpcClient::new_with_commitment(
        String::from("https://api.devnet.solana.com"),
        CommitmentConfig::confirmed(),
    );

    // !hover message
    let base_64_message = "AQABAgIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEBAQAA";
    let bytes = general_purpose::STANDARD.decode(base_64_message).unwrap();
    let message: Message = bincode::deserialize(&bytes).unwrap();

    let fee = client.get_fee_for_message(&message).await?;

    println!("{:#?}", fee);

    Ok(())
}
```

### !params

#### !! message

!type string
!required

Base-64 encoded Message

#### !! 1

!type object

Configuration object.

##### !! commitment

!type string

The commitment describes how finalized a block is at that point in time. See
[Configuring State Commitment](/docs/rpc#configuring-state-commitment).

##### !! minContextSlot

!type number

The minimum slot that the request can be evaluated at.

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  "result": {
    "context": { "slot": 5068 },
    // !hover result
    "value": 5000
  },
  "id": 1
}
```

!type u64 | null

Fee corresponding to the message at the specified blockhash

</APIMethod>
---
title: getFirstAvailableBlock
hideTableOfContents: true
h1: getFirstAvailableBlock RPC Method
---

Returns the slot of the lowest confirmed block that has not been purged from the
ledger

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "getFirstAvailableBlock"
}
```

```ts !!request title="Kit"
import { createSolanaRpc } from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

let firstAvailableBlock = await rpc.getFirstAvailableBlock().send();

console.log(firstAvailableBlock);
```

```ts !!request title="web3.js"
import { Connection, clusterApiUrl } from "@solana/web3.js";

const connection = new Connection(clusterApiUrl("devnet"), "confirmed");

let firstAvailableBlock = await connection.getFirstAvailableBlock();

console.log(firstAvailableBlock);
```

```rs !!request title="Rust"
use anyhow::Result;
use solana_client::nonblocking::rpc_client::RpcClient;
use solana_sdk::commitment_config::CommitmentConfig;

#[tokio::main]
async fn main() -> Result<()> {
    let client = RpcClient::new_with_commitment(
        String::from("https://api.devnet.solana.com"),
        CommitmentConfig::confirmed(),
    );

    let first_available_block = client.get_first_available_block().await?;

    println!("{:#?}", first_available_block);

    Ok(())
}
```

### !params

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover result
  "result": 250000,
  "id": 1
}
```

!type u64

Slot

</APIMethod>
---
title: getGenesisHash
hideTableOfContents: true
h1: getGenesisHash RPC Method
---

Returns the genesis hash

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "getGenesisHash"
}
```

```ts !!request title="Kit"
import { createSolanaRpc } from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

let genesisHash = await rpc.getGenesisHash().send();

console.log(genesisHash);
```

```ts !!request title="web3.js"
import { Connection, clusterApiUrl } from "@solana/web3.js";

const connection = new Connection(clusterApiUrl("devnet"), "confirmed");

let genesisHash = await connection.getGenesisHash();

console.log(genesisHash);
```

```rs !!request title="Rust"
use anyhow::Result;
use solana_client::nonblocking::rpc_client::RpcClient;
use solana_sdk::commitment_config::CommitmentConfig;

#[tokio::main]
async fn main() -> Result<()> {
    let client = RpcClient::new_with_commitment(
        String::from("https://api.devnet.solana.com"),
        CommitmentConfig::confirmed(),
    );

    let genesis_hash = client.get_genesis_hash().await?;

    println!("{:#?}", genesis_hash);

    Ok(())
}
```

### !params

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover result
  "result": "GH7ome3EiwEr7tu9JuTh2dpYWBJK3z69Xm1ZE3MEE6JC",
  "id": 1
}
```

!type string

A Hash as base-58 encoded string

</APIMethod>
---
title: getHealth
hideTableOfContents: true
h1: getHealth RPC Method
---

Returns the current health of the node. A healthy node is one that is within
`HEALTH_CHECK_SLOT_DISTANCE` slots of the latest cluster confirmed slot.

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "getHealth"
}
```

```ts !!request title="Kit"
import { createSolanaRpc } from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

let health = await rpc.getHealth().send();

console.log(health);
```

```rs !!request title="Rust"
use anyhow::Result;
use solana_client::nonblocking::rpc_client::RpcClient;
use solana_sdk::commitment_config::CommitmentConfig;

#[tokio::main]
async fn main() -> Result<()> {
    let client = RpcClient::new_with_commitment(
        String::from("https://api.devnet.solana.com"),
        CommitmentConfig::confirmed(),
    );

    let health = client.get_health().await?;

    println!("{:#?}", health);

    Ok(())
}
```

### !params

### !!result Healthy

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover result
  "result": "ok",
  "id": 1
}
```

!type string

If the node is healthy: "ok"

### !!result Unhealthy

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover(1:5) result
  "error": {
    "code": -32005,
    "message": "Node is unhealthy",
    "data": { "numSlotsBehind": 42 }
  },
  "id": 1
}
```

!type object

If the node is unhealthy, a JSON RPC error response is returned. The specifics
of the error response are **UNSTABLE** and may change in the future

</APIMethod>
---
title: getHighestSnapshotSlot
hideTableOfContents: true
h1: getHighestSnapshotSlot RPC Method
---

Returns the highest slot information that the node has snapshots for.

This will find the highest full snapshot slot, and the highest incremental
snapshot slot _based on_ the full snapshot slot, if there is one.

<Callout type="warn" title={"Version Restriction"}>
  This method is only available in `solana-core` v1.9 or newer. Please use
  [getSnapshotSlot](/docs/rpc/http/getsnapshotslot) for `solana-core` v1.8 and
  below.
</Callout>

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "getHighestSnapshotSlot"
}
```

```ts !!request title="Kit"
import { createSolanaRpc } from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

let hightestSnapshotSlot = await rpc.getHighestSnapshotSlot().send();

console.log(hightestSnapshotSlot);
```

```rs !!request title="Rust"
use anyhow::Result;
use solana_client::nonblocking::rpc_client::RpcClient;
use solana_sdk::commitment_config::CommitmentConfig;

#[tokio::main]
async fn main() -> Result<()> {
    let client = RpcClient::new_with_commitment(
        String::from("https://api.devnet.solana.com"),
        CommitmentConfig::confirmed(),
    );

    let highest_snapshot_slot = client.get_highest_snapshot_slot().await?;

    println!("{:#?}", highest_snapshot_slot);

    Ok(())
}
```

### !params

### !!result Snapshot

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover(1:4) result
  "result": {
    // !hover full
    "full": 100,
    // !hover incremental
    "incremental": 110
  },
  "id": 1
}
```

!type object

When the node has a snapshot, this returns a JSON object with the following
fields:

##### !! full

!type u64

The highest full snapshot slot

##### !! incremental

!type u64 | null

The highest incremental snapshot slot _based on_ `full`

### !!result No Snapshot

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover(1:4) result
  "error": {
    "code": -32008,
    "message": "No snapshot"
  },
  "id": 1
}
```

!type object

If the node has no snapshot, a JSON RPC error response is returned.

</APIMethod>
---
title: getIdentity
hideTableOfContents: true
h1: getIdentity RPC Method
---

Returns the identity pubkey for the current node

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "getIdentity"
}
```

```ts !!request title="Kit"
import { createSolanaRpc } from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

let identity = await rpc.getIdentity().send();

console.log(identity);
```

```rs !!request title="Rust"
use anyhow::Result;
use solana_client::nonblocking::rpc_client::RpcClient;
use solana_sdk::commitment_config::CommitmentConfig;

#[tokio::main]
async fn main() -> Result<()> {
    let client = RpcClient::new_with_commitment(
        String::from("https://api.devnet.solana.com"),
        CommitmentConfig::confirmed(),
    );

    let identity = client.get_identity().await?;

    println!("{:#?}", identity);

    Ok(())
}
```

### !params

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover(1:3) result
  "result": {
    // !hover identity
    "identity": "2r1F4iWqVcb8M1DbAjQuFpebkQHY9hcVU4WuW2DJBppN"
  },
  "id": 1
}
```

!type object

The result field will be a JSON object with the following fields:

##### !! identity

!type string

The identity pubkey of the current node (as a base-58 encoded string)

</APIMethod>
---
title: getInflationGovernor
hideTableOfContents: true
h1: getInflationGovernor RPC Method
---

Returns the current inflation governor

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "getInflationGovernor",
  "params": [
    // !hover(1:3) 0
    {
      // !hover commitment
      "commitment": "finalized"
    }
  ]
}
```

```ts !!request title="Kit"
import { createSolanaRpc, type Commitment } from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

// !hover commitment
let commitment: Commitment = "finalized";
let inflationGovener = await rpc.getInflationGovernor({ commitment }).send();

console.log(inflationGovener);
```

```ts !!request title="web3.js"
import { Connection, clusterApiUrl } from "@solana/web3.js";

const connection = new Connection(clusterApiUrl("devnet"), "confirmed");

// !hover commitment
let commitment = "finalized";
let inflationGovener = await connection.getInflationGovernor();

console.log(inflationGovener);
```

```rs !!request title="Rust"
use anyhow::Result;
use solana_client::nonblocking::rpc_client::RpcClient;
use solana_sdk::commitment_config::CommitmentConfig;

#[tokio::main]
async fn main() -> Result<()> {
    let client = RpcClient::new_with_commitment(
        String::from("https://api.devnet.solana.com"),
        CommitmentConfig::confirmed(),
    );

    let inflation_govener = client.get_inflation_governor().await?;

    println!("{:#?}", inflation_govener);

    Ok(())
}
```

### !params

#### !! 0

!type object

Configuration object.

##### !! commitment

!type string

The commitment describes how finalized a block is at that point in time. See
[Configuring State Commitment](/docs/rpc#configuring-state-commitment).

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover(1:7) result
  "result": {
    // !hover foundation
    "foundation": 0.05,
    // !hover foundationTerm
    "foundationTerm": 7,
    // !hover initial
    "initial": 0.15,
    // !hover taper
    "taper": 0.15,
    // !hover terminal
    "terminal": 0.015
  },
  "id": 1
}
```

!type object

The result field will be a JSON object with the following fields:

##### !! foundation

!type f64

Percentage of total inflation allocated to the foundation

##### !! foundationTerm

!type f64

Duration of foundation pool inflation in years

##### !! initial

!type f64

Initial inflation percentage from time 0

##### !! taper

!type f64

Rate per year at which inflation is lowered. (Rate reduction is derived using
the target slot time in genesis config)

##### !! terminal

!type f64

Terminal inflation percentage

</APIMethod>
---
title: getInflationRate
hideTableOfContents: true
h1: getInflationRate RPC Method
---

Returns the specific inflation values for the current epoch

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "getInflationRate"
}
```

```ts !!request title="Kit"
import { createSolanaRpc } from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

let inflationRate = await rpc.getInflationRate().send();

console.log(inflationRate);
```

```ts !!request title="web3.js"
import { Connection, clusterApiUrl } from "@solana/web3.js";

const connection = new Connection(clusterApiUrl("devnet"), "confirmed");

let inflationRate = await connection.getInflationRate();

console.log(inflationRate);
```

```rs !!request title="Rust"
use anyhow::Result;
use solana_client::nonblocking::rpc_client::RpcClient;
use solana_sdk::commitment_config::CommitmentConfig;

#[tokio::main]
async fn main() -> Result<()> {
    let client = RpcClient::new_with_commitment(
        String::from("https://api.devnet.solana.com"),
        CommitmentConfig::confirmed(),
    );

    let inflation_rate = client.get_inflation_rate().await?;

    println!("{:#?}", inflation_rate);

    Ok(())
}
```

### !params

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover(1:6) result
  "result": {
    // !hover total
    "total": 0.149,
    // !hover validator
    "validator": 0.148,
    // !hover foundation
    "foundation": 0.001,
    // !hover epoch
    "epoch": 100
  },
  "id": 1
}
```

!type object

The result field will be a JSON object with the following fields:

##### !! total

!type f64

Total inflation

##### !! validator

!type f64

Inflation allocated to validators

##### !! foundation

!type f64

Inflation allocated to the foundation

##### !! epoch

!type u64

Epoch for which these values are valid

</APIMethod>
---
title: getInflationReward
hideTableOfContents: true
h1: getInflationReward RPC Method
---

Returns the inflation / staking reward for a list of addresses for an epoch

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "getInflationReward",
  "params": [
    // !hover(1:4) 0
    [
      "6dmNQ5jwLeLk5REvio1JcMshcbvkYMwy26sJ8pbkvStu",
      "BGsqMegLpV6n6Ve146sSX2dTjUMj3M92HnU8BbNRMhF2"
    ],
    // !hover(1:3) 1
    {
      // !hover epoch
      "epoch": 800,
      // !hover commitment
      "commitment": "finalized"
    }
  ]
}
```

```ts !!request title="Kit"
import { address, createSolanaRpc } from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

// !hover(1:4) 0
let addresses = [
  address("6dmNQ5jwLeLk5REvio1JcMshcbvkYMwy26sJ8pbkvStu"),
  address("BGsqMegLpV6n6Ve146sSX2dTjUMj3M92HnU8BbNRMhF2"),
];

// !hover epoch
let epoch = BigInt(2);

let inflationReward = await rpc.getInflationReward(addresses, { epoch }).send();

console.log(inflationReward);
```

```ts !!request title="web3.js"
import { Connection, PublicKey, clusterApiUrl } from "@solana/web3.js";

const connection = new Connection(clusterApiUrl("devnet"), "confirmed");

// !hover(1:4) 0
let addresses = [
  new PublicKey("6dmNQ5jwLeLk5REvio1JcMshcbvkYMwy26sJ8pbkvStu"),
  new PublicKey("BGsqMegLpV6n6Ve146sSX2dTjUMj3M92HnU8BbNRMhF2"),
];

// !hover epoch
let epoch = 2;

let inflationReward = await connection.getInflationReward(addresses, epoch);

console.log(inflationReward);
```

```rs !!request title="Rust"
use anyhow::Result;
use solana_client::nonblocking::rpc_client::RpcClient;
use solana_sdk::{commitment_config::CommitmentConfig, pubkey};

#[tokio::main]
async fn main() -> Result<()> {
    let client = RpcClient::new_with_commitment(
        String::from("https://api.devnet.solana.com"),
        CommitmentConfig::confirmed(),
    );

    // !hover(1:4) 0
    let addresses = [
        pubkey!("6dmNQ5jwLeLk5REvio1JcMshcbvkYMwy26sJ8pbkvStu"),
        pubkey!("BGsqMegLpV6n6Ve146sSX2dTjUMj3M92HnU8BbNRMhF2"),
    ];

    // !hover epoch
    let epoch = 2;

    let inflation_reward = client.get_inflation_reward(&addresses, Some(epoch)).await?;

    println!("{:#?}", inflation_reward);

    Ok(())
}
```

### !params

#### !! 0

!type array

An array of addresses to query, as base-58 encoded strings

#### !! 1

!type object

Configuration object containing the following fields:

##### !! commitment

!type string

The commitment describes how finalized a block is at that point in time. See
[Configuring State Commitment](/docs/rpc#configuring-state-commitment).

##### !! epoch

!type u64

An epoch for which the reward occurs. If omitted, the previous epoch will be
used

##### !! minContextSlot

!type number

The minimum slot that the request can be evaluated at

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover(1:9) result
  "result": [
    {
      // !hover epoch
      "epoch": 2,
      // !hover effectiveSlot
      "effectiveSlot": 224,
      // !hover amount
      "amount": 2500,
      // !hover postBalance
      "postBalance": 499999442500
    },
    null
  ],
  "id": 1
}
```

!type array

The result field will be a JSON array of objects containing:

##### !! epoch

!type u64

Epoch for which reward occurred

##### !! effectiveSlot

!type u64

The slot in which the rewards are effective

##### !! amount

!type u64

Reward amount in lamports

##### !! postBalance

!type u64

Post balance of the account in lamports

##### !! commission

!type u8 | undefined

Vote account commission when the reward was credited

</APIMethod>
---
title: getLargestAccounts
hideTableOfContents: true
h1: getLargestAccounts RPC Method
---

Returns the 20 largest accounts, by lamport balance (results may be cached up to
two hours)

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "getLargestAccounts",
  "params": [
    // !hover(1:3) 0
    {
      // !hover commitment
      "commitment": "finalized"
    }
  ]
}
```

```ts !!request title="Kit"
import { createSolanaRpc } from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

let largestAccounts = await rpc.getLargestAccounts().send();

console.log(largestAccounts);
```

```ts !!request title="web3.js"
import {
  Connection,
  clusterApiUrl,
  type GetLargestAccountsConfig,
} from "@solana/web3.js";

const connection = new Connection(clusterApiUrl("devnet"), "confirmed");

// !hover(1:4) 0
let config: GetLargestAccountsConfig = {
  // !hover commitment
  commitment: "finalized",
  // !hover filter
  filter: "circulating",
};

let largestAccounts = await connection.getLargestAccounts(config);

console.log(largestAccounts);
```

```rs !!request title="Rust"
use anyhow::Result;
use solana_client::{
    nonblocking::rpc_client::RpcClient,
    rpc_config::{RpcLargestAccountsConfig, RpcLargestAccountsFilter},
};
use solana_sdk::commitment_config::CommitmentConfig;

#[tokio::main]
async fn main() -> Result<()> {
    let client = RpcClient::new_with_commitment(
        String::from("https://api.devnet.solana.com"),
        CommitmentConfig::confirmed(),
    );

    // !hover(1:5) 0
    let config = RpcLargestAccountsConfig {
        // !hover commitment
        commitment: CommitmentConfig::finalized().into(),
        // !hover filter
        filter: RpcLargestAccountsFilter::Circulating.into(),
        sort_results: true.into(),
    };
    let largest_accounts = client.get_largest_accounts_with_config(config).await?;

    println!("{:#?}", largest_accounts);

    Ok(())
}
```

### !params

#### !! 0

!type object

Configuration object containing the following fields:

##### !! commitment

!type string

The commitment describes how finalized a block is at that point in time. See
[Configuring State Commitment](/docs/rpc#configuring-state-commitment).

##### !! filter

!type string
!values circulating nonCirculating

Filter results by account type

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  "result": {
    "context": { "slot": 54 },
    "value": [
      {
        // !hover address
        "address": "99P8ZgtJYe1buSK8JXkvpLh8xPsCFuLYhz9hQFNw93WJ",
        // !hover lamports
        "lamports": 999974
      },
      {
        "address": "uPwWLo16MVehpyWqsLkK3Ka8nLowWvAHbBChqv2FZeL",
        "lamports": 42
      }
    ]
  },
  "id": 1
}
```

!type array

The result will be an RpcResponse JSON object with `value` equal to an array of
objects containing:

##### !! address

!type string

Base-58 encoded address of the account

##### !! lamports

!type u64

Number of lamports in the account

</APIMethod>
---
title: getLatestBlockhash
hideTableOfContents: true
h1: getLatestBlockhash RPC Method
---

Returns the latest blockhash

<Callout type="warn" title={"Version Restriction"}>
  This method is only available in `solana-core` v1.9 or newer. Please use
  [getRecentBlockhash](/docs/rpc/http/getrecentblockhash) for `solana-core` v1.8
  and below.
</Callout>

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "getLatestBlockhash",
  "params": [
    // !hover(1:3) 0
    {
      // !hover commitment
      "commitment": "processed"
    }
  ]
}
```

```ts !!request title="Kit"
import { createSolanaRpc, type Commitment } from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

// !hover commitment
let commitment: Commitment = "processed";
let latestBlockhash = await rpc.getLatestBlockhash({ commitment }).send();

console.log(latestBlockhash);
```

```ts !!request title="web3.js"
import { Connection, clusterApiUrl, type Commitment } from "@solana/web3.js";

const connection = new Connection(clusterApiUrl("devnet"), "confirmed");

// !hover commitment
let commitment: Commitment = "processed";
let latestBlockhash = await connection.getLatestBlockhash(commitment);

console.log(latestBlockhash);
```

```rs !!request title="Rust"
use anyhow::Result;
use solana_client::nonblocking::rpc_client::RpcClient;
use solana_sdk::commitment_config::CommitmentConfig;

#[tokio::main]
async fn main() -> Result<()> {
    let client = RpcClient::new_with_commitment(
        String::from("https://api.devnet.solana.com"),
        CommitmentConfig::confirmed(),
    );

    // !hover commitment
    let commitment = CommitmentConfig::processed();
    let latest_blockhash = client
        .get_latest_blockhash_with_commitment(commitment)
        .await?;

    println!("{:#?}", latest_blockhash);

    Ok(())
}
```

### !params

#### !! 0

!type object

Configuration object containing the following fields:

##### !! commitment

!type string

The commitment describes how finalized a block is at that point in time. See
[Configuring State Commitment](/docs/rpc#configuring-state-commitment).

##### !! minContextSlot

!type number

The minimum slot that the request can be evaluated at

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  "result": {
    "context": {
      "slot": 2792
    },
    // !hover(1:4) result
    "value": {
      // !hover blockhash
      "blockhash": "EkSnNWid2cvwEVnVx9aBqawnmiCNiDgp3gUdkDPTKN1N",
      // !hover lastValidBlockHeight
      "lastValidBlockHeight": 3090
    }
  },
  "id": 1
}
```

!type object

RpcResponse JSON object with `value` field set to a JSON object including:

##### !! blockhash

!type string

A Hash as base-58 encoded string

##### !! lastValidBlockHeight

!type u64

Last [block height](/docs/references/terminology#block-height) at which the
blockhash will be valid

</APIMethod>
---
title: getLeaderSchedule
hideTableOfContents: true
h1: getLeaderSchedule RPC Method
---

Returns the leader schedule for an epoch

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "getLeaderSchedule",
  "params": [
    // !hover slot number
    null,
    // !hover(1:3) 1
    {
      // !hover commitment
      "commitment": "processed",
      // !hover identity
      "identity": "dv2eQHeP4RFrJZ6UeiZWoc3XTtmtZCUKxxCApCDcRNV"
    }
  ]
}
```


```ts !!request title="Kit"
import { address, createSolanaRpc, type Commitment } from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

// !hover slot number
let slotNumber = null;

// !hover identity
let identity = address("dv1ZAGvdsz5hHLwWXsVnM94hWf1pjbKVau1QVkaMJ92");
// !hover commitment
let commitment: Commitment = "finalized";

let leaderSchedule = await rpc
  .getLeaderSchedule(slotNumber, { identity, commitment })
  .send();

console.log(leaderSchedule);
```

```ts !!request title="web3.js"
import { Connection, clusterApiUrl } from "@solana/web3.js";

const connection = new Connection(clusterApiUrl("devnet"), "confirmed");

let leaderSchedule = await connection.getLeaderSchedule();

console.log(leaderSchedule);
```

```rs !!request title="Rust"
use anyhow::Result;
use solana_client::{nonblocking::rpc_client::RpcClient, rpc_config::RpcLeaderScheduleConfig};
use solana_sdk::commitment_config::CommitmentConfig;

#[tokio::main]
async fn main() -> Result<()> {
    let client = RpcClient::new_with_commitment(
        String::from("https://api.devnet.solana.com"),
        CommitmentConfig::confirmed(),
    );

    // !hover slot number
    let slot_number = None;
    // !hover(1:4) 1
    let config = RpcLeaderScheduleConfig {
        // !hover identity
        identity: String::from("dv1ZAGvdsz5hHLwWXsVnM94hWf1pjbKVau1QVkaMJ92").into(),
        // !hover commitment
        commitment: CommitmentConfig::finalized().into(),
    };
    let leader_schedule = client
        .get_leader_schedule_with_config(slot_number, config)
        .await?;

    println!("{:#?}", leader_schedule);

    Ok(())
}
```

### !params

#### !! slot number

!type u64

Fetch the leader schedule for the epoch that corresponds to the provided slot.
If unspecified, the leader schedule for the current epoch is fetched.

#### !! 1

!type object

Configuration object containing the following fields:

##### !! commitment

!type string

The commitment describes how finalized a block is at that point in time. See
[Configuring State Commitment](/docs/rpc#configuring-state-commitment).

##### !! identity

!type string

Only return results for this validator identity (base-58 encoded)

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover(1:8) result
  "result": {
    "4Qkev8aNZcqFNSRhQzwyLMFSsi94jHqE8WNVTJzTP99F": [
      0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20,
      21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38,
      39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56,
      57, 58, 59, 60, 61, 62, 63
    ]
  },
  "id": 1
}
```

!type object | null

Returns `null` if requested epoch is not found, otherwise returns an object
where:

- Keys are validator identities (as base-58 encoded strings)
- Values are arrays of leader slot indices relative to the first slot in the
  requested epoch

</APIMethod>
---
title: getMaxRetransmitSlot
hideTableOfContents: true
h1: getMaxRetransmitSlot RPC Method
---

Get the max slot seen from retransmit stage.

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "getMaxRetransmitSlot"
}
```

```ts !!request title="Kit"
import { createSolanaRpc } from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

let maxRetransmitSlot = await rpc.getMaxRetransmitSlot().send();

console.log(maxRetransmitSlot);
```

```rs !!request title="Rust"
use anyhow::Result;
use solana_client::nonblocking::rpc_client::RpcClient;
use solana_sdk::commitment_config::CommitmentConfig;

#[tokio::main]
async fn main() -> Result<()> {
    let client = RpcClient::new_with_commitment(
        String::from("https://api.devnet.solana.com"),
        CommitmentConfig::confirmed(),
    );

    let max_retransmit_slot = client.get_max_retransmit_slot().await?;

    println!("{:#?}", max_retransmit_slot);

    Ok(())
}
```

### !params

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover result
  "result": 1234,
  "id": 1
}
```

!type u64

Slot number

</APIMethod>
---
title: getMaxShredInsertSlot
hideTableOfContents: true
h1: getMaxShredInsertSlot RPC Method
---

Get the max slot seen from after shred insert.

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "getMaxShredInsertSlot"
}
```

```ts !!request title="Kit"
import { createSolanaRpc } from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

let maxShredInsertSlot = await rpc.getMaxShredInsertSlot().send();

console.log(maxShredInsertSlot);
```

```rs !!request title="Rust"
use anyhow::Result;
use solana_client::nonblocking::rpc_client::RpcClient;
use solana_sdk::commitment_config::CommitmentConfig;

#[tokio::main]
async fn main() -> Result<()> {
    let client = RpcClient::new_with_commitment(
        String::from("https://api.devnet.solana.com"),
        CommitmentConfig::confirmed(),
    );

    let max_shred_insert_slot = client.get_max_shred_insert_slot().await?;

    println!("{:#?}", max_shred_insert_slot);

    Ok(())
}
```

### !params

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover result
  "result": 1234,
  "id": 1
}
```

!type u64

Slot number

</APIMethod>
---
title: getMinimumBalanceForRentExemption
hideTableOfContents: true
h1: getMinimumBalanceForRentExemption RPC Method
---

Returns minimum balance required to make account rent exempt.

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "getMinimumBalanceForRentExemption",
  "params": [
    // !hover length
    50,
    // !hover(1:3) 1
    {
      // !hover commitment
      "commitment": "processed",
    }
  ]
}
```

```ts !!request title="Kit"
import { createSolanaRpc } from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

// !hover length
let dataLength = BigInt(50);
let minBalForRentExemption = await rpc
  .getMinimumBalanceForRentExemption(dataLength)
  .send();

console.log(minBalForRentExemption);
```

```ts !!request title="web3.js"
import { Connection, clusterApiUrl } from "@solana/web3.js";

const connection = new Connection(clusterApiUrl("devnet"), "confirmed");

// !hover length
let dataLength = 50;
let minBalForRentExemption =
  await connection.getMinimumBalanceForRentExemption(dataLength);

console.log(minBalForRentExemption);
```

```rs !!request title="Rust"
use anyhow::Result;
use solana_client::nonblocking::rpc_client::RpcClient;
use solana_sdk::commitment_config::CommitmentConfig;

#[tokio::main]
async fn main() -> Result<()> {
    let client = RpcClient::new_with_commitment(
        String::from("https://api.devnet.solana.com"),
        CommitmentConfig::confirmed(),
    );

    // !hover length
    let data_len = 50;

    let min_bal_for_rent_exemption = client
        .get_minimum_balance_for_rent_exemption(data_len)
        .await?;

    println!("{:#?}", min_bal_for_rent_exemption);

    Ok(())
}
```

### !params

#### !! length

!type usize
!required

The Account's data length

#### !! 1

!type object

Configuration object containing the following fields:

##### !! commitment

!type string

The commitment describes how finalized a block is at that point in time. See
[Configuring State Commitment](/docs/rpc#configuring-state-commitment).

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover result
  "result": 500,
  "id": 1
}
```

!type u64

Minimum lamports required in the Account to remain rent free

</APIMethod>
---
title: getMultipleAccounts
hideTableOfContents: true
h1: getMultipleAccounts RPC Method
---

Returns the account information for a list of Pubkeys.

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "getMultipleAccounts",
  "params": [
    // !hover(1:4) 0
    [
      "vines1vzrYbzLMRdu58ou5XTby4qAqVRLmqo36NKPTg",
      "4fYNw3dojWmQ4dXtSGE9epjRGy9pFSx62YypT7avPYvA"
    ],
    // !hover(1:3) 1
    {
      // !hover encoding
      "encoding": "base58",
      // !hover commitment
      "commitment": "finalized"
    }
  ]
}
```

```ts !!request title="Kit"
import { address, createSolanaRpc } from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

// !hover(1:4) 0
let addresses = [
  address("vines1vzrYbzLMRdu58ou5XTby4qAqVRLmqo36NKPTg"),
  address("4fYNw3dojWmQ4dXtSGE9epjRGy9pFSx62YypT7avPYvA"),
];

// !hover(1:3) 1
let config = {
  // !hover encoding
  encoding: "base58",
  // !hover commitment
  commitment: "finalized",
};

let accounts = await rpc.getMultipleAccounts(addresses, config).send();

console.log(accounts);
```

```ts !!request title="web3.js"
import {
  Connection,
  PublicKey,
  clusterApiUrl,
  type GetMultipleAccountsConfig,
} from "@solana/web3.js";

const connection = new Connection(clusterApiUrl("devnet"), "confirmed");

// !hover(1:4) 0
let addresses = [
  new PublicKey("vines1vzrYbzLMRdu58ou5XTby4qAqVRLmqo36NKPTg"),
  new PublicKey("4fYNw3dojWmQ4dXtSGE9epjRGy9pFSx62YypT7avPYvA"),
];

// !hover(1:3) 1
let config: GetMultipleAccountsConfig = {
  // !hover commitment
  commitment: "finalized",
};

let accounts = await connection.getMultipleAccountsInfo(addresses, config);

console.log(accounts);
```

```rs !!request title="Rust"
use anyhow::Result;
use solana_account_decoder::UiAccountEncoding;
use solana_client::{nonblocking::rpc_client::RpcClient, rpc_config::RpcAccountInfoConfig};
use solana_sdk::{commitment_config::CommitmentConfig, pubkey};

#[tokio::main]
async fn main() -> Result<()> {
    let client = RpcClient::new_with_commitment(
        String::from("https://api.devnet.solana.com"),
        CommitmentConfig::confirmed(),
    );

    // !hover(1:4) 0
    let addresses = [
        pubkey!("vines1vzrYbzLMRdu58ou5XTby4qAqVRLmqo36NKPTg"),
        pubkey!("4fYNw3dojWmQ4dXtSGE9epjRGy9pFSx62YypT7avPYvA"),
    ];

    // !hover(1:6) 1
    let config = RpcAccountInfoConfig {
        // !hover encoding
        encoding: UiAccountEncoding::Base58.into(),
        // !hover dataSlice
        data_slice: None,
        // !hover commitment
        commitment: CommitmentConfig::finalized().into(),
        // !hover minContextSlot
        min_context_slot: None,
    };

    let accounts = client
        .get_multiple_accounts_with_config(&addresses, config)
        .await?;

    println!("{:#?}", accounts);

    Ok(())
}
```

### !params

#### !! 0

!type array
!required

An array of Pubkeys to query, as base-58 encoded strings (up to a maximum
of 100)

#### !! 1

!type object

Configuration object containing the following fields:

##### !! commitment

!type string

The commitment describes how finalized a block is at that point in time. See
[Configuring State Commitment](/docs/rpc#configuring-state-commitment).

##### !! minContextSlot

!type number

The minimum slot that the request can be evaluated at

##### !! dataSlice

!type object

Request a slice of the account's data.

- `length: <usize>` - number of bytes to return
- `offset: <usize>` - byte offset from which to start reading

<Callout type="info">
  Data slicing is only available for `base58`, `base64`, or `base64+zstd`
  encodings.
</Callout>

##### !! encoding

!type string
!values jsonParsed base58 base64 base64+zstd
!default base64

Encoding format for the returned Account data

- `base58` is slow and limited to less than 129 bytes of Account data.
- `base64` will return base64 encoded data for Account data of any size.
- `base64+zstd` compresses the Account data using
  [Zstandard](https://facebook.github.io/zstd/) and base64-encodes the result.
- `jsonParsed` encoding attempts to use program-specific state parsers to return
  more human-readable and explicit account state data.
- If `jsonParsed` is requested but a parser cannot be found, the field falls
  back to `base64` encoding, detectable when the `data` field is type
  `<string>`.

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  "result": {
    "context": { "apiVersion": "2.0.15", "slot": 341197247 },
    // !hover(1:18) result
    "value": [
      {
        // !hover data
        "data": ["", "base58"],
        // !hover executable
        "executable": false,
        // !hover lamports
        "lamports": 88849814690250,
        // !hover owner
        "owner": "11111111111111111111111111111111",
        // !hover rentEpoch
        "rentEpoch": 18446744073709551615,
        // !hover space
        "space": 0
      },
      {
        "data": ["", "base58"],
        "executable": false,
        "lamports": 998763433,
        "owner": "2WRuhE4GJFoE23DYzp2ij6ZnuQ8p9mJeU6gDgfsjR4or",
        "rentEpoch": 18446744073709551615,
        "space": 0
      }
    ]
  },
  "id": 1
}
```

!type array

The result will be an array containing either:

- `null` - if the account at that Pubkey doesn't exist, or
- Account objects with the following fields:

##### !! data

!type [string,encoding] | object

Data associated with the account, either as encoded binary data or JSON format
`{<program>: <state>}` - depending on encoding parameter

##### !! executable

!type bool

Boolean indicating if the account contains a program (and is strictly read-only)

##### !! lamports

!type u64

Number of lamports assigned to this account

##### !! owner

!type string

Base-58 encoded Pubkey of the program this account has been assigned to

##### !! rentEpoch

!type u64

The epoch at which this account will next owe rent

##### !! space

!type u64

The data size of the account

</APIMethod>
---
title: getProgramAccounts
hideTableOfContents: true
h1: getProgramAccounts RPC Method
---

Returns all accounts owned by the provided program Pubkey

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "getProgramAccounts",
  "params": [
    // !hover pubkey
    "4Nd1mBQtrMJVYVfKf2PJy9NZUZdTAsp7D4xWLs4gDB4T",
    // !hover(1:11) 1
    {
      // !hover commitment
      "commitment": "finalized",
      // !hover(1:9) filters
      "filters": [
        { "dataSize": 17 },
        {
          "memcmp": {
            "offset": 4,
            "bytes": "3Mc6vR"
          }
        }
      ]
    }
  ]
}
```

```ts !!request title="Kit"
import { address, createSolanaRpc } from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

// !hover pubkey
let program = address("4Nd1mBQtrMJVYVfKf2PJy9NZUZdTAsp7D4xWLs4gDB4T");

let accounts = await rpc
  .getProgramAccounts(
    program,
    // !hover(1:15) 1
    {
      // !hover commitment
      commitment: "finalized",
      // !hover(1:12) filters
      filters: [
        {
          dataSize: BigInt(17),
        },
        {
          memcmp: {
            bytes: "3Mc6vR",
            offset: BigInt(4),
          },
        },
      ],
    },
  )
  .send();

console.log(accounts);
```

```ts !!request title="web3.js"
import {
  Connection,
  PublicKey,
  clusterApiUrl,
  type GetProgramAccountsConfig,
} from "@solana/web3.js";

const connection = new Connection(clusterApiUrl("devnet"), "confirmed");

// !hover pubkey
let programId = new PublicKey("4Nd1mBQtrMJVYVfKf2PJy9NZUZdTAsp7D4xWLs4gDB4T");

// !hover(1:15) 1
let config: GetProgramAccountsConfig = {
  // !hover commitment
  commitment: "finalized",
  // !hover(1:12) filters
  filters: [
    {
      dataSize: 17,
    },
    {
      memcmp: {
        bytes: "3Mc6vR",
        offset: 4,
      },
    },
  ],
};

let accounts = await connection.getProgramAccounts(programId, config);

console.log(accounts);
```

```rs !!request title="Rust"
use anyhow::Result;
use solana_client::{
    nonblocking::rpc_client::RpcClient,
    rpc_config::{RpcAccountInfoConfig, RpcProgramAccountsConfig},
    rpc_filter::{Memcmp, MemcmpEncodedBytes, RpcFilterType},
};
use solana_sdk::{commitment_config::CommitmentConfig, pubkey};

#[tokio::main]
async fn main() -> Result<()> {
    let client = RpcClient::new_with_commitment(
        String::from("https://api.devnet.solana.com"),
        CommitmentConfig::confirmed(),
    );

    // !hover pubkey
    let program = pubkey!("4Nd1mBQtrMJVYVfKf2PJy9NZUZdTAsp7D4xWLs4gDB4T");

    // !hover(1:18) 1
    let config = RpcProgramAccountsConfig {
        // !hover(1:8) filters
        filters: vec![
            RpcFilterType::DataSize(17),
            RpcFilterType::Memcmp(Memcmp::new(
                4,
                MemcmpEncodedBytes::Base64("3Mc6vR".to_string()),
            )),
        ]
        .into(),
        account_config: RpcAccountInfoConfig {
            // !hover encoding
            encoding: None,
            // !hover dataSlice
            data_slice: None,
            // !hover commitment
            commitment: None,
            // !hover minContextSlot
            min_context_slot: None,
        },
        // !hover withContext
        with_context: None,
        sort_results: true.into(),
    };

    let accounts = client
        .get_program_accounts_with_config(&program, config)
        .await?;

    println!("{:#?}", accounts);

    Ok(())
}

```

### !params

#### !! pubkey

!type string
!required

Pubkey of program, as base-58 encoded string

#### !! 1

!type object

Configuration object containing the following fields:

##### !! commitment

!type string

The commitment describes how finalized a block is at that point in time. See
[Configuring State Commitment](/docs/rpc#configuring-state-commitment).

##### !! minContextSlot

!type number

The minimum slot that the request can be evaluated at

##### !! withContext

!type bool

Wrap the result in an RpcResponse JSON object

##### !! encoding

!type string
!values jsonParsed base58 base64 base64+zstd
!default json

Encoding format for the returned Account data

- `base58` is slow and limited to less than 129 bytes of Account data.
- `base64` will return base64 encoded data for Account data of any size.
- `base64+zstd` compresses the Account data using
  [Zstandard](https://facebook.github.io/zstd/) and base64-encodes the result.
- `jsonParsed` encoding attempts to use program-specific state parsers to return
  more human-readable and explicit account state data.
- If `jsonParsed` is requested but a parser cannot be found, the field falls
  back to `base64` encoding, detectable when the `data` field is type
  `<string>`.

##### !! dataSlice

!type object

Request a slice of the account's data.

- `length: <usize>` - number of bytes to return
- `offset: <usize>` - byte offset from which to start reading

<Callout type="info">
  Data slicing is only available for `base58`, `base64`, or `base64+zstd`
  encodings.
</Callout>

##### !! filters

!type array

Filter results using up to 4 filter objects.

<Callout type="info">
  The resultant account(s) must meet **ALL** filter criteria to be included in
  the returned results
</Callout>

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover(1:12) result
  "result": [
    {
      // !hover pubkey
      "pubkey": "CxELquR1gPP8wHe33gZ4QxqGB3sZ9RSwsJ2KshVewkFY",
      // !hover(1:8) account
      "account": {
        // !hover data
        "data": "2R9jLfiAQ9bgdcw6h8s44439",
        // !hover executable
        "executable": false,
        // !hover lamports
        "lamports": 15298080,
        // !hover owner
        "owner": "4Nd1mBQtrMJVYVfKf2PJy9NZUZdTAsp7D4xWLs4gDB4T",
        // !hover rentEpoch
        "rentEpoch": 28,
        // !hover space
        "space": 42
      }
    }
  ],
  "id": 1
}
```

!type array

By default, returns an array of JSON objects. If `withContext` flag is set, the
array will be wrapped in an RpcResponse JSON object.

Each object contains:

##### !! pubkey

!type string

The account Pubkey as base-58 encoded string

##### !! account

!type object

A JSON object containing:

- `lamports: <u64>` - number of lamports assigned to this account, as a u64
- `owner: <string>` - base-58 encoded Pubkey of the program this account has
  been assigned to
- `data: <[string,encoding]|object>` - data associated with the account, either
  as encoded binary data or JSON format `{<program>: <state>}` - depending on
  encoding parameter
- `executable: <bool>` - boolean indicating if the account contains a program
  (and is strictly read-only)
- `rentEpoch: <u64>` - the epoch at which this account will next owe rent, as
  u64
- `space: <u64>` - the data size of the account

</APIMethod>
---
title: getRecentPerformanceSamples
hideTableOfContents: true
h1: getRecentPerformanceSamples RPC Method
---

Returns a list of recent performance samples, in reverse slot order. Performance
samples are taken every 60 seconds and include the number of transactions and
slots that occur in a given time window.

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "getRecentPerformanceSamples",
  "params": [
    // !hover number of samples
    2
  ]
}
```

```ts !!request title="Kit"
import { createSolanaRpc } from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

// !hover number of samples
let limit = 2;

let performanceSamples = await rpc.getRecentPerformanceSamples(limit).send();

console.log(performanceSamples);
```

```ts !!request title="web3.js"
import { Connection, clusterApiUrl } from "@solana/web3.js";

const connection = new Connection(clusterApiUrl("devnet"), "confirmed");

// !hover number of samples
let limit = 2;

let performanceSamples = await connection.getRecentPerformanceSamples(limit);

console.log(performanceSamples);
```

```rs !!request title="Rust"
use anyhow::Result;
use solana_client::nonblocking::rpc_client::RpcClient;
use solana_sdk::commitment_config::CommitmentConfig;

#[tokio::main]
async fn main() -> Result<()> {
    let client = RpcClient::new_with_commitment(
        String::from("https://api.devnet.solana.com"),
        CommitmentConfig::confirmed(),
    );

// !hover number of samples
    let limit = 2;
    let performance_samples = client.get_recent_performance_samples(limit.into()).await?;

    println!("{:#?}", performance_samples);

    Ok(())
}
```

### !params

#### !! number of samples

!type usize

Number of samples to return (maximum 720)

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover(1:16) result
  "result": [
    {
      // !hover slot
      "slot": 348125,
      // !hover numTransactions
      "numTransactions": 126,
      // !hover numSlots
      "numSlots": 126,
      // !hover samplePeriodSecs
      "samplePeriodSecs": 60,
      // !hover numNonVoteTransactions
      "numNonVoteTransactions": 1
    },
    {
      "slot": 347999,
      "numTransactions": 126,
      "numSlots": 126,
      "samplePeriodSecs": 60,
      "numNonVoteTransactions": 1
    }
  ],
  "id": 1
}
```

!type array

An array of performance sample objects containing:

##### !! slot

!type u64

Slot in which sample was taken at

##### !! numTransactions

!type u64

Number of transactions processed during the sample period

##### !! numSlots

!type u64

Number of slots completed during the sample period

##### !! samplePeriodSecs

!type u16

Number of seconds in a sample window

##### !! numNonVoteTransactions

!type u64

Number of non-vote transactions processed during the sample period

<Callout type="info">
  `numNonVoteTransactions` is present starting with v1.15. To get a number of
  voting transactions compute: `numTransactions - numNonVoteTransactions`
</Callout>

</APIMethod>
---
title: getRecentPrioritizationFees
hideTableOfContents: true
h1: getRecentPrioritizationFees RPC Method
---

Returns a list of prioritization fees from recent blocks.

<Callout type="info">
  Currently, a node's prioritization-fee cache stores data from up to 150
  blocks.
</Callout>

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "getRecentPrioritizationFees",
  "params": [
    // !hover address
    ["CxELquR1gPP8wHe33gZ4QxqGB3sZ9RSwsJ2KshVewkFY"]
  ]
}
```

```ts !!request title="Kit"
import { address, createSolanaRpc } from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

// !hover address
let addresses = [address("CxELquR1gPP8wHe33gZ4QxqGB3sZ9RSwsJ2KshVewkFY")];
let prioritizationFees = await rpc
  .getRecentPrioritizationFees(addresses)
  .send();

console.log(prioritizationFees);
```

```ts !!request title="web3.js"
import { Connection, PublicKey, clusterApiUrl } from "@solana/web3.js";

const connection = new Connection(clusterApiUrl("devnet"), "confirmed");

// !hover address
let addresses = [new PublicKey("CxELquR1gPP8wHe33gZ4QxqGB3sZ9RSwsJ2KshVewkFY")];

let prioritizationFees = await connection.getRecentPrioritizationFees({
  lockedWritableAccounts: addresses,
});

console.log(prioritizationFees);
```

```rs !!request title="Rust"
use anyhow::Result;
use solana_client::nonblocking::rpc_client::RpcClient;
use solana_sdk::{commitment_config::CommitmentConfig, pubkey};

#[tokio::main]
async fn main() -> Result<()> {
    let client = RpcClient::new_with_commitment(
        String::from("https://api.devnet.solana.com"),
        CommitmentConfig::confirmed(),
    );

    // !hover address
    let addresses = [pubkey!("CxELquR1gPP8wHe33gZ4QxqGB3sZ9RSwsJ2KshVewkFY")];
    let prioritization_fees = client.get_recent_prioritization_fees(&addresses).await?;

    println!("{:#?}", prioritization_fees);

    Ok(())
}
```

### !params

#### !! address

!type array

An array of Account addresses (up to a maximum of 128 addresses), as base-58
encoded strings

<Callout type="info">
  If this parameter is provided, the response will reflect a fee to land a
  transaction locking all of the provided accounts as writable.
</Callout>

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover(1:22) result
  "result": [
    {
      // !hover slot
      "slot": 348125,
      // !hover prioritizationFee
      "prioritizationFee": 0
    },
    {
      "slot": 348126,
      "prioritizationFee": 1000
    },
    {
      "slot": 348127,
      "prioritizationFee": 500
    },
    {
      "slot": 348128,
      "prioritizationFee": 0
    },
    {
      "slot": 348129,
      "prioritizationFee": 1234
    }
  ],
  "id": 1
}
```

!type array

An array of prioritization fee objects containing:

##### !! slot

!type u64

Slot in which the fee was observed

##### !! prioritizationFee

!type u64

The per-compute-unit fee paid by at least one successfully landed transaction,
specified in increments of micro-lamports (0.000001 lamports)

</APIMethod>
---
title: getSignaturesForAddress
hideTableOfContents: true
h1: getSignaturesForAddress RPC Method
---

Returns signatures for confirmed transactions that include the given address in
their `accountKeys` list. Returns signatures backwards in time from the provided
signature or most recent confirmed block

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "getSignaturesForAddress",
  "params": [
    // !hover address
    "Vote111111111111111111111111111111111111111",
    // !hover(1:6) 1
    {
      // !hover commitment
      "commitment": "finalized",
      // !hover limit
      "limit": 1
    }
  ]
}
```

```ts !!request title="Kit"
import { address, createSolanaRpc } from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

// !hover address
let addr = address("Vote111111111111111111111111111111111111111");

// !hover(1:3) 1
let signaturesForConfig = {
  // !hover limit
  limit: 1,
};

let signatures = await rpc
  .getSignaturesForAddress(addr, signaturesForConfig)
  .send();

console.log(signatures);
```

```ts !!request title="web3.js"
import {
  Connection,
  PublicKey,
  clusterApiUrl,
  type SignaturesForAddressOptions,
} from "@solana/web3.js";

const connection = new Connection(clusterApiUrl("devnet"), "confirmed");

// !hover(1:3) 1
let signaturesOptions: SignaturesForAddressOptions = {
  // !hover limit
  limit: 1,
};

// !hover address
let address = new PublicKey("Vote111111111111111111111111111111111111111");
let signatures = await connection.getSignaturesForAddress(
  address,
  signaturesOptions,
);

console.log(signatures);
```

```rs !!request title="Rust"
use anyhow::Result;
use solana_client::{
    nonblocking::rpc_client::RpcClient, rpc_client::GetConfirmedSignaturesForAddress2Config,
};
use solana_sdk::{commitment_config::CommitmentConfig, pubkey};

#[tokio::main]
async fn main() -> Result<()> {
    let client = RpcClient::new_with_commitment(
        String::from("https://api.devnet.solana.com"),
        CommitmentConfig::confirmed(),
    );

    // !hover address
    let address = pubkey!("Vote111111111111111111111111111111111111111");

    // !hover(1:6) 1
    let signatures_for_config = GetConfirmedSignaturesForAddress2Config {
        // !hover before
        before: None,
        // !hover until
        until: None,
        // !hover limit
        limit: Some(1),
        // !hover commitment
        commitment: CommitmentConfig::finalized().into(),
    };

    let signatures = client
        .get_signatures_for_address_with_config(&address, signatures_for_config)
        .await?;

    println!("{:#?}", signatures);

    Ok(())
}
```

### !params

#### !! address

!type string
!required

Account address as base-58 encoded string

#### !! 1

!type object

Configuration object containing the following fields:

##### !! commitment

!type string

The commitment describes how finalized a block is at that point in time. See
[Configuring State Commitment](/docs/rpc#configuring-state-commitment).

##### !! minContextSlot

!type number

The minimum slot that the request can be evaluated at

##### !! limit

!type number

Maximum transaction signatures to return (between 1 and 1,000).

Default: `1000`

##### !! before

!type string

Start searching backwards from this transaction signature. If not provided the
search starts from the top of the highest max confirmed block.

##### !! until

!type string

Search until this transaction signature, if found before limit reached

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover(1:10) result
  "result": [
    {
      // !hover signature
      "signature": "5h6xBEauJ3PK6SWCZ1PGjBvj8vDdWG3KpwATGy1ARAXFSDwt8GFXM7W5Ncn16wmqokgpiKRLuS83KUxyZyv2sUYv",
      // !hover slot
      "slot": 114,
      // !hover err
      "err": null,
      // !hover memo
      "memo": null,
      // !hover blockTime
      "blockTime": null,
      // !hover confirmationStatus
      "confirmationStatus": "finalized"
    }
  ],
  "id": 1
}
```

!type array

An array of transaction signature information objects, ordered from **newest**
to **oldest** transaction, containing:

##### !! signature

!type string

Transaction signature as base-58 encoded string

##### !! slot

!type u64

The slot that contains the block with the transaction

##### !! err

!type object | null

Error if transaction failed, null if transaction succeeded. See
[TransactionError definitions](https://github.com/solana-labs/solana/blob/c0c60386544ec9a9ec7119229f37386d9f070523/sdk/src/transaction/error.rs#L13)
for more info.

##### !! memo

!type string | null

Memo associated with the transaction, null if no memo is present

##### !! blockTime

!type i64 | null

Estimated production time, as Unix timestamp (seconds since the Unix epoch) of
when transaction was processed. null if not available.

##### !! confirmationStatus

!type string | null

The transaction's cluster confirmation status; Either `processed`, `confirmed`,
or `finalized`. See [Commitment](/docs/rpc/#configuring-state-commitment) for
more on optimistic confirmation.

</APIMethod>
---
title: getSignatureStatuses
hideTableOfContents: true
h1: getSignatureStatuses RPC Method
---

Returns the statuses of a list of signatures. Each signature must be a
[txid](/docs/references/terminology#transaction-id), the first signature of a
transaction.

<Callout type="info">
  Unless the `searchTransactionHistory` configuration parameter is included,
  this method only searches the recent status cache of signatures, which retains
  statuses for all active slots plus `MAX_RECENT_BLOCKHASHES` rooted slots.
</Callout>

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "getSignatureStatuses",
  "params": [
    // !hover(1:3) 0
    [
      "5VERv8NMvzbJMEkV8xnrLkEaWRtSz9CosKDYjCJjBRnbJLgp8uirBgmQpjKhoR4tjF3ZpRzrFmBV6UjKdiSZkQUW"
    ],
    // !hover(1:3) 1
    {
      // !hover searchTransactionHistory
      "searchTransactionHistory": true
    }
  ]
}
```

```ts !!request title="Kit"
import { createSolanaRpc, type Signature } from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

// !hover(1:3) 0
let signatures = [
  "4cdd1oX7cfVALfr26tP52BZ6cSzrgnNGtYD7BFhm6FFeZV5sPTnRvg6NRn8yC6DbEikXcrNChBM5vVJnTgKhGhVu" as unknown as Signature,
];

// !hover(1:3) 1
let config = {
  // !hover searchTransactionHistory
  searchTransactionHistory: true,
};

let signatureStatus = await rpc.getSignatureStatuses(signatures, config).send();

console.log(signatureStatus);
```

```ts !!request title="web3.js"
import {
  Connection,
  clusterApiUrl,
  type SignatureStatusConfig,
} from "@solana/web3.js";

const connection = new Connection(clusterApiUrl("devnet"), "confirmed");

// !hover(1:3) 0
let signatures = [
  "4cdd1oX7cfVALfr26tP52BZ6cSzrgnNGtYD7BFhm6FFeZV5sPTnRvg6NRn8yC6DbEikXcrNChBM5vVJnTgKhGhVu",
];

// !hover(1:3) 1
let config: SignatureStatusConfig = {
  // !hover searchTransactionHistory
  searchTransactionHistory: true,
};

let signatureStatus = await connection.getSignatureStatuses(signatures, config);
console.log(signatureStatus);
```

```rs !!request title="Rust"
use anyhow::Result;
use solana_client::nonblocking::rpc_client::RpcClient;
use solana_sdk::{commitment_config::CommitmentConfig, signature::Signature};
use std::str::FromStr;

#[tokio::main]
async fn main() -> Result<()> {
    let client = RpcClient::new_with_commitment(
        String::from("https://api.devnet.solana.com"),
        CommitmentConfig::confirmed(),
    );

    // !hover(1:3) 0
    let signatures_str = [
        "4cdd1oX7cfVALfr26tP52BZ6cSzrgnNGtYD7BFhm6FFeZV5sPTnRvg6NRn8yC6DbEikXcrNChBM5vVJnTgKhGhVu",
    ];
    let signatures = signatures_str.map(|sig| Signature::from_str(sig).unwrap());

    let signature_status = client
        .get_signature_statuses_with_history(&signatures)
        .await?;

    println!("{:#?}", signature_status);

    Ok(())
}
```

### !params

#### !! 0

!type array
!required

An array of transaction signatures to confirm, as base-58 encoded strings (up to
a maximum of 256)

#### !! 1

!type object

Configuration object containing the following fields:

##### !! searchTransactionHistory

!type bool

if `true` - a Solana node will search its ledger cache for any signatures not
found in the recent status cache

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  "result": {
    "context": {
      "slot": 82
    },
    // !hover(1:12) result
    "value": [
      {
        // !hover slot
        "slot": 48,
        // !hover confirmations
        "confirmations": null,
        // !hover err
        "err": null,
        // !hover status
        "status": {
          "Ok": null
        },
        // !hover confirmationStatus
        "confirmationStatus": "finalized"
      },
      null
    ]
  },
  "id": 1
}
```

!type array

An array of `RpcResponse<object>` consisting of either `null` or an object
containing the following fields:

##### !! slot

!type u64

The slot the transaction was processed

##### !! confirmations

!type usize | null

Number of blocks since signature confirmation, `null` if rooted, as well as
finalized by a supermajority of the cluster

##### !! err

!type object | null

Error if transaction failed, `null` if transaction succeeded. See
[TransactionError definitions](https://github.com/anza-xyz/solana-sdk/blob/50dfbd088c51b7229c67d432d8c8801dafaa7904/transaction-error/src/lib.rs#L15)

##### !! status

!type object

**DEPRECATED** Transaction status

- `"Ok": <null>` - Transaction was successful
- `"Err": <ERR>` - Transaction failed with TransactionError

##### !! confirmationStatus

!type string | null

The transaction's cluster confirmation status; Either `processed`, `confirmed`,
or `finalized`. See [Commitment](/docs/rpc/#configuring-state-commitment) for
more on optimistic confirmation.

</APIMethod>
---
title: getSlot
hideTableOfContents: true
h1: getSlot RPC Method
---

Returns the slot that has reached the
[given or default commitment level](/docs/rpc/#configuring-state-commitment)

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "getSlot",
  "params": [
    // !hover(1:3) 0
    {
      // !hover commitment
      "commitment": "finalized"
    }
  ]
}
```

```ts !!request title="Kit"
import { createSolanaRpc } from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

let slot = await rpc.getSlot().send();

console.log(slot);
```

```ts !!request title="web3.js"
import { Connection, clusterApiUrl, type GetSlotConfig } from "@solana/web3.js";

const connection = new Connection(clusterApiUrl("devnet"), "confirmed");

// !hover(1:3)  0
let config: GetSlotConfig = {
  // !hover  commitment
  commitment: "finalized",
};

let slot = await connection.getSlot(config);

console.log(slot);
```

```rs !!request title="Rust"
use anyhow::Result;
use solana_client::nonblocking::rpc_client::RpcClient;
use solana_sdk::commitment_config::CommitmentConfig;

#[tokio::main]
async fn main() -> Result<()> {
    let client = RpcClient::new_with_commitment(
        String::from("https://api.devnet.solana.com"),
        CommitmentConfig::confirmed(),
    );

    let slot = client.get_slot().await?;

    println!("{}", slot);

    Ok(())
}
```

### !params

#### !! 0

!type object

Configuration object containing the following fields:

##### !! commitment

!type string

The commitment describes how finalized a block is at that point in time. See
[Configuring State Commitment](/docs/rpc#configuring-state-commitment).

##### !! minContextSlot

!type number

The minimum slot that the request can be evaluated at

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover result
  "result": 1234,
  "id": 1
}
```

!type u64

Current slot

</APIMethod>
---
title: getSlotLeader
hideTableOfContents: true
h1: getSlotLeader RPC Method
---

Returns the current slot leader

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "getSlotLeader",
  "params": [
    // !hover(1:3) 0
    {
      // !hover commitment
      "commitment": "finalized"
    }
  ]
}
```

```ts !!request title="Kit"
import { createSolanaRpc } from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

let slotLeader = await rpc.getSlotLeader().send();

console.log(slotLeader);
```

```ts !!request title="web3.js"
import { Connection, clusterApiUrl } from "@solana/web3.js";

const connection = new Connection(clusterApiUrl("devnet"), "confirmed");

let slotLeader = await connection.getSlotLeader();

console.log(slotLeader);
```

### !params

#### !! 0

!type object

Configuration object containing the following fields:

##### !! commitment

!type string

The commitment describes how finalized a block is at that point in time. See
[Configuring State Commitment](/docs/rpc#configuring-state-commitment).

##### !! minContextSlot

!type number

The minimum slot that the request can be evaluated at

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover result
  "result": "ENvAW7JScgYq6o4zKZwewtkzzJgDzuJAFxYasvmEQdpS",
  "id": 1
}
```

!type string

Node identity Pubkey as base-58 encoded string

</APIMethod>
---
title: getSlotLeaders
hideTableOfContents: true
h1: getSlotLeaders RPC Method
---

Returns the slot leaders for a given slot range

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "getSlotLeaders",
  "params": [
    // !hover start slot
    100,
    // !hover limit
    10
  ]
}
```

```ts !!request title="Kit"
import { createSolanaRpc } from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

// !hover start slot
let startSlot = BigInt(378037836);
// !hover limit
let limit = 10;

let slotLeaders = await rpc.getSlotLeaders(startSlot, limit).send();

console.log(slotLeaders);
```

```ts !!request title="web3.js"
import { Connection, clusterApiUrl } from "@solana/web3.js";

const connection = new Connection(clusterApiUrl("devnet"), "confirmed");

// !hover start slot
let startSlot = 378037836;
// !hover limit
let limit = 10;

let slotLeaders = await connection.getSlotLeaders(startSlot, limit);

console.log(slotLeaders);
```

```rs !!request title="Rust"
use anyhow::Result;
use solana_client::nonblocking::rpc_client::RpcClient;
use solana_sdk::commitment_config::CommitmentConfig;

#[tokio::main]
async fn main() -> Result<()> {
    let client = RpcClient::new_with_commitment(
        String::from("https://api.devnet.solana.com"),
        CommitmentConfig::confirmed(),
    );

    // !hover start slot
    let start_slot = 378037836;
    // !hover limit
    let limit = 10;

    let slot_leaders = client.get_slot_leaders(start_slot, limit).await?;

    println!("{:#?}", slot_leaders);

    Ok(())
}
```

### !params

#### !! start slot

!type u64
!required

Start slot, as u64 integer

#### !! limit

!type u64
!required

Limit, as u64 integer (between 1 and 5,000)

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover(1:12) result
  "result": [
    "ChorusmmK7i1AxXeiTtQgQZhQNiXYU84ULeaYF1EH15n",
    "ChorusmmK7i1AxXeiTtQgQZhQNiXYU84ULeaYF1EH15n",
    "ChorusmmK7i1AxXeiTtQgQZhQNiXYU84ULeaYF1EH15n",
    "ChorusmmK7i1AxXeiTtQgQZhQNiXYU84ULeaYF1EH15n",
    "Awes4Tr6TX8JDzEhCZY2QVNimT6iD1zWHzf1vNyGvpLM",
    "Awes4Tr6TX8JDzEhCZY2QVNimT6iD1zWHzf1vNyGvpLM",
    "Awes4Tr6TX8JDzEhCZY2QVNimT6iD1zWHzf1vNyGvpLM",
    "Awes4Tr6TX8JDzEhCZY2QVNimT6iD1zWHzf1vNyGvpLM",
    "DWvDTSh3qfn88UoQTEKRV2JnLt5jtJAVoiCo3ivtMwXP",
    "DWvDTSh3qfn88UoQTEKRV2JnLt5jtJAVoiCo3ivtMwXP"
  ],
  "id": 1
}
```

!type array

Array of Node identity public keys as base-58 encoded strings.

</APIMethod>
---
title: getStakeMinimumDelegation
hideTableOfContents: true
h1: getStakeMinimumDelegation RPC Method
---

Returns the stake minimum delegation, in lamports.

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "getStakeMinimumDelegation",
  "params": [
    // !hover(1:3) 0
    {
      // !hover commitment
      "commitment": "finalized"
    }
  ]
}
```

```ts !!request title="Kit"
import { createSolanaRpc } from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

let stakeMinDelegation = await rpc.getStakeMinimumDelegation().send();

console.log(stakeMinDelegation);
```

```ts !!request title="web3.js"
import { Connection, clusterApiUrl } from "@solana/web3.js";

const connection = new Connection(clusterApiUrl("devnet"), "confirmed");

let stakeMinDelegation = await connection.getStakeMinimumDelegation();

console.log(stakeMinDelegation);
```

```rs !!request title="Rust"
use anyhow::Result;
use solana_client::nonblocking::rpc_client::RpcClient;
use solana_sdk::commitment_config::CommitmentConfig;

#[tokio::main]
async fn main() -> Result<()> {
    let client = RpcClient::new_with_commitment(
        String::from("https://api.devnet.solana.com"),
        CommitmentConfig::confirmed(),
    );

    let min_stake_delegation = client.get_stake_minimum_delegation().await?;

    println!("{}", min_stake_delegation);

    Ok(())
}
```

### !params

#### !! 0

!type object

Configuration object containing the following fields:

##### !! commitment

!type string

The commitment describes how finalized a block is at that point in time. See
[Configuring State Commitment](/docs/rpc#configuring-state-commitment).

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  "result": {
    "context": { "slot": 501 },
    // !hover result
    "value": 1000000000
  },
  "id": 1
}
```

!type u64

The stake minimum delegation, in lamports

</APIMethod>
---
title: getSupply
hideTableOfContents: true
h1: getSupply RPC Method
---

Returns information about the current supply.

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "getSupply",
  "params": [
    // !hover(1:3) 0
    {
      // !hover commitment
      "commitment": "finalized"
    }
  ]
}
```

```ts !!request title="Kit"
import { createSolanaRpc } from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

let supply = await rpc.getSupply().send();

console.log(supply);
```

```ts !!request title="web3.js"
import { Connection, clusterApiUrl } from "@solana/web3.js";

const connection = new Connection(clusterApiUrl("devnet"), "confirmed");

let supply = await connection.getSupply();

console.log(supply);
```

### !params

#### !! 0

!type object

Configuration object containing the following fields:

##### !! commitment

!type string

The commitment describes how finalized a block is at that point in time. See
[Configuring State Commitment](/docs/rpc#configuring-state-commitment).

##### !! excludeNonCirculatingAccountsList

!type bool

Exclude non circulating accounts list from response

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  "result": {
    "context": { "slot": 1114 },
    // !hover(1:11) result
    "value": {
      // !hover total
      "total": 1016000,
      // !hover circulating
      "circulating": 16000,
      // !hover nonCirculating
      "nonCirculating": 1000000,
      // !hover(1:6) nonCirculatingAccounts
      "nonCirculatingAccounts": [
        "FEy8pTbP5fEoqMV1GdTz83byuA8EKByqYat1PKDgVAq5",
        "9huDUZfxoJ7wGMTffUE7vh1xePqef7gyrLJu9NApncqA",
        "3mi1GmwEE3zo2jmfDuzvjSX9ovRXsDUKHvsntpkhuLJ9",
        "BYxEJTDerkaRWBem3XgnVcdhppktBXa2HbkHPKj2Ui4Z"
      ]
    }
  },
  "id": 1
}
```

!type object

The result will be a JSON object containing:

##### !! circulating

!type u64

Circulating supply in lamports

##### !! nonCirculating

!type u64

Non-circulating supply in lamports

##### !! nonCirculatingAccounts

!type array

An array of account addresses of non-circulating accounts, as strings. If
`excludeNonCirculatingAccountsList` is enabled, the returned array will be
empty.

##### !! total

!type u64

Total supply in lamports

</APIMethod>
---
title: getTokenAccountBalance
hideTableOfContents: true
h1: getTokenAccountBalance RPC Method
---

Returns the token balance of an SPL Token account.

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "getTokenAccountBalance",
  "params": [
    // !hover pubkey
    "7fUAJdStEuGbc3sM84cKRL6yYaaSstyLSU4ve5oovLS7",
    {
      // !hover commitment
      "commitment": "finalized"
    }
  ]
}
```

```ts !!request title="Kit"
import { address, createSolanaRpc } from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

// !hover pubkey
let tokenAddress = address("48gpnn8nsmkvkgso7462Z1nFhUrprGQ71u1YLBPzizbY");

let tokenBalance = await rpc.getTokenAccountBalance(tokenAddress).send();

console.log(tokenBalance);
```

```ts !!request title="web3.js"
import { Connection, PublicKey, clusterApiUrl } from "@solana/web3.js";

const connection = new Connection(clusterApiUrl("devnet"), "confirmed");

// !hover pubkey
let tokenAddress = new PublicKey(
  "48gpnn8nsmkvkgso7462Z1nFhUrprGQ71u1YLBPzizbY",
);

let tokenBalance = await connection.getTokenAccountBalance(tokenAddress);

console.log(tokenBalance);
```

```rs !!request title="Rust"
use anyhow::Result;
use solana_client::nonblocking::rpc_client::RpcClient;
use solana_sdk::{commitment_config::CommitmentConfig, pubkey};

#[tokio::main]
async fn main() -> Result<()> {
    let client = RpcClient::new_with_commitment(
        String::from("https://api.devnet.solana.com"),
        CommitmentConfig::confirmed(),
    );

    // !hover pubkey
    let token_address = pubkey!("48gpnn8nsmkvkgso7462Z1nFhUrprGQ71u1YLBPzizbY");
    let token_acc_bal = client.get_token_account_balance(&token_address).await?;

    println!("{:#?}", token_acc_bal);

    Ok(())
}
```

### !params

#### !! pubkey

!type string
!required

Pubkey of Token account to query, as base-58 encoded string

#### !! 1

!type object

Configuration object containing the following fields:

##### !! commitment

!type string

The commitment describes how finalized a block is at that point in time. See
[Configuring State Commitment](/docs/rpc#configuring-state-commitment).

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  "result": {
    "context": { "slot": 1114 },
    // !hover(1:6) value
    "value": {
      // !hover amount
      "amount": "9864",
      // !hover decimals
      "decimals": 2,
      // !hover uiAmount
      "uiAmount": 98.64,
      // !hover uiAmountString
      "uiAmountString": "98.64"
    }
  },
  "id": 1
}
```

!type object

The result will be a JSON object containing:

##### !! amount

!type string

The raw balance without decimals, a string representation of u64

##### !! decimals

!type u8

Number of base 10 digits to the right of the decimal place

##### !! uiAmount

!type number | null

The balance, using mint-prescribed decimals **DEPRECATED**

##### !! uiAmountString

!type string

The balance as a string, using mint-prescribed decimals

</APIMethod>

<Callout type="info">
  For more details on returned data, the [Token Balances
  Structure](/docs/rpc/json-structures#token-balances) response from
  [getBlock](/docs/rpc/http/getblock) follows a similar structure.
</Callout>
---
title: getTokenAccountsByDelegate
hideTableOfContents: true
h1: getTokenAccountsByDelegate RPC Method
---

Returns all SPL Token accounts by approved Delegate.

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "getTokenAccountsByDelegate",
  "params": [
    // !hover pubkey
    "4Nd1mBQtrMJVYVfKf2PJy9NZUZdTAsp7D4xWLs4gDB4T",
    // !hover(1:3) 1
    {
      // !hover programId
      "programId": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
    },
    // !hover(1:3) 2
    {
      // !hover commitment
      "commitment": "finalized",
      // !hover encoding
      "encoding": "jsonParsed"
    }
  ]
}
```

```ts !!request title="Kit"
import { address, createSolanaRpc } from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

// !hover pubkey
let delegate = address("4kg8oh3jdNtn7j2wcS7TrUua31AgbLzDVkBZgTAe44aF");

// !hover programId
let tokenProgram = address("TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA");

let tokenAccByDelegate = await rpc
  .getTokenAccountsByDelegate(delegate, { programId: tokenProgram })
  .send();

console.log(tokenAccByDelegate);
```

```rs !!request title="Rust"
use anyhow::Result;
use solana_client::{nonblocking::rpc_client::RpcClient, rpc_request::TokenAccountsFilter};
use solana_sdk::{commitment_config::CommitmentConfig, pubkey};

#[tokio::main]
async fn main() -> Result<()> {
    let client = RpcClient::new_with_commitment(
        String::from("https://api.devnet.solana.com"),
        CommitmentConfig::confirmed(),
    );

    // !hover pubkey
    let delegate = pubkey!("4kg8oh3jdNtn7j2wcS7TrUua31AgbLzDVkBZgTAe44aF");

    // !hover programId
    let token_program = pubkey!("TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA");

    let token_acc_by_del = client
        .get_token_accounts_by_delegate_with_commitment(
            &delegate,
            TokenAccountsFilter::ProgramId(token_program),
            CommitmentConfig::finalized(),
        )
        .await?;

    println!("{:#?}", token_acc_by_del);

    Ok(())
```

### !params

#### !! pubkey

!type string
!required

Pubkey of account delegate to query, as base-58 encoded string

#### !! 1

!type object
!required

A JSON object with one of the following fields:

##### !! mint

!type string

Pubkey of the specific token Mint to limit accounts to, as base-58 encoded
string; or

##### !! programId

!type string

Pubkey of the Token program that owns the accounts, as base-58 encoded string

#### !! 2

!type object

Configuration object containing the following fields:

##### !! commitment

!type string

The commitment describes how finalized a block is at that point in time. See
[Configuring State Commitment](/docs/rpc#configuring-state-commitment).

##### !! minContextSlot

!type number

The minimum slot that the request can be evaluated at

##### !! dataSlice

!type object

Request a slice of the account's data.

- `length: <usize>` - number of bytes to return
- `offset: <usize>` - byte offset from which to start reading

<Callout type="info">
  Data slicing is only available for `base58`, `base64`, or `base64+zstd`
  encodings.
</Callout>

##### !! encoding

!type string
!values base58 base64 base64+zstd jsonParsed

Encoding format for Account data

- `base58` is slow and limited to less than 129 bytes of Account data.
- `base64` will return base64 encoded data for Account data of any size.
- `base64+zstd` compresses the Account data using
  [Zstandard](https://facebook.github.io/zstd/) and base64-encodes the result.
- `jsonParsed` encoding attempts to use program-specific state parsers to return
  more human-readable and explicit account state data.
- If `jsonParsed` is requested but a parser cannot be found, the field falls
  back to `base64` encoding, detectable when the `data` field is type `string`.

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  "result": {
    "context": { "slot": 1114 },
    "value": [
      {
        // !hover pubkey
        "pubkey": "28YTZEwqtMHWrhWcvv34se7pjS7wctgqzCPB3gReCFKp",
        // !hover(1:33) account
        "account": {
          "data": {
            "program": "spl-token",
            "parsed": {
              "info": {
                "tokenAmount": {
                  "amount": "1",
                  "decimals": 1,
                  "uiAmount": 0.1,
                  "uiAmountString": "0.1"
                },
                "delegate": "4Nd1mBQtrMJVYVfKf2PJy9NZUZdTAsp7D4xWLs4gDB4T",
                "delegatedAmount": {
                  "amount": "1",
                  "decimals": 1,
                  "uiAmount": 0.1,
                  "uiAmountString": "0.1"
                },
                "state": "initialized",
                "isNative": false,
                "mint": "3wyAj7Rt1TWVPZVteFJPLa26JmLvdb1CAKEFZm3NY75E",
                "owner": "CnPoSPKXu7wJqxe59Fs72tkBeALovhsCxYeFwPCQH9TD"
              },
              "type": "account"
            },
            "space": 165
          },
          "executable": false,
          "lamports": 1726080,
          "owner": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA",
          "rentEpoch": 4,
          "space": 165
        }
      }
    ]
  },
  "id": 1
}
```

!type array

An array of JSON objects containing:

##### !! pubkey

!type string

The account Pubkey as base-58 encoded string

##### !! account

!type object

A JSON object containing:

- `lamports: <u64>` - number of lamports assigned to this account, as a u64
- `owner: <string>` - base-58 encoded Pubkey of the program this account has
  been assigned to
- `data: <object>` - Token state data associated with the account, either as
  encoded binary data or in JSON format `{<program>: <state>}`
- `executable: <bool>` - boolean indicating if the account contains a program
  (and is strictly read-only)
- `rentEpoch: <u64>` - the epoch at which this account will next owe rent, as
  u64
- `space: <u64>` - the data size of the account

When the data is requested with the `jsonParsed` encoding a format similar to
that of the [Token Balances Structure](/docs/rpc/json-structures#token-balances)
can be expected inside the structure, both for the `tokenAmount` and the
`delegatedAmount` - with the latter being an optional object.

</APIMethod>
---
title: getTokenAccountsByOwner
hideTableOfContents: true
h1: getTokenAccountsByOwner RPC Method
---

Returns all SPL Token accounts by token owner.

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "getTokenAccountsByOwner",
  "params": [
    // !hover pubkey
    "A1TMhSGzQxMr1TboBKtgixKz1sS6REASMxPo1qsyTSJd",
    // !hover(1:3) 1
    {
      // !hover programId
      "programId": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
    },
    // !hover(1:3) 2
    {
      // !hover commitment
      "commitment": "finalized",
      // !hover encoding
      "encoding": "jsonParsed"
    }
  ]
}
```

```ts !!request title="Kit"
import { address, createSolanaRpc } from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

// !hover pubkey
let owner = address("4kg8oh3jdNtn7j2wcS7TrUua31AgbLzDVkBZgTAe44aF");

// !hover programId
let tokenProgram = address("TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA");

let tokenAccounts = await rpc
  .getTokenAccountsByOwner(
    owner,
    { programId: tokenProgram },
    // !hover encoding
    { encoding: "base64" },
  )
  .send();

console.log(tokenAccounts);
```

```ts !!request title="web3.js"
import { Connection, PublicKey, clusterApiUrl } from "@solana/web3.js";

const connection = new Connection(clusterApiUrl("devnet"), "confirmed");

// !hover pubkey
let owner = new PublicKey("4kg8oh3jdNtn7j2wcS7TrUua31AgbLzDVkBZgTAe44aF");

// !hover programId
let tokenProgram = new PublicKey("TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA");

let tokenAccounts = await connection.getTokenAccountsByOwner(owner, {
  programId: tokenProgram,
});

console.log(tokenAccounts);
```

```rs !!request title="Rust"
use anyhow::Result;
use solana_client::{nonblocking::rpc_client::RpcClient, rpc_request::TokenAccountsFilter};
use solana_sdk::{commitment_config::CommitmentConfig, pubkey};

#[tokio::main]
async fn main() -> Result<()> {
    let client = RpcClient::new_with_commitment(
        String::from("https://api.devnet.solana.com"),
        CommitmentConfig::confirmed(),
    );

    // !hover pubkey
    let owner = pubkey!("4kg8oh3jdNtn7j2wcS7TrUua31AgbLzDVkBZgTAe44aF");

    // !hover programId
    let token_program = pubkey!("TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA");

    let token_accounts = client
        .get_token_accounts_by_owner(&owner, TokenAccountsFilter::ProgramId(token_program))
        .await?;

    println!("{:#?}", token_accounts);

    Ok(())
}
```

### !params

#### !! pubkey

!type string
!required

Pubkey of account owner to query, as base-58 encoded string

#### !! 1

!type object
!required

A JSON object with one of the following fields:

##### !! mint

!type string

Pubkey of the specific token Mint to limit accounts to, as base-58 encoded
string

##### !! programId

!type string

Pubkey of the Token program that owns the accounts, as base-58 encoded string

#### !! 2

!type object

Configuration object containing the following fields:

##### !! commitment

!type string

The commitment describes how finalized a block is at that point in time. See
[Configuring State Commitment](/docs/rpc#configuring-state-commitment).

##### !! minContextSlot

!type number

The minimum slot that the request can be evaluated at

##### !! dataSlice

!type object

Request a slice of the account's data.

- `length: <usize>` - number of bytes to return
- `offset: <usize>` - byte offset from which to start reading

<Callout type="info">
  Data slicing is only available for `base58`, `base64`, or `base64+zstd`
  encodings.
</Callout>

##### !! encoding

!type string
!values base58 base64 base64+zstd jsonParsed

Encoding format for Account data

- `base58` is slow and limited to less than 129 bytes of Account data.
- `base64` will return base64 encoded data for Account data of any size.
- `base64+zstd` compresses the Account data using
  [Zstandard](https://facebook.github.io/zstd/) and base64-encodes the result.
- `jsonParsed` encoding attempts to use program-specific state parsers to return
  more human-readable and explicit account state data.
- If `jsonParsed` is requested but a parser cannot be found, the field falls
  back to `base64` encoding, detectable when the `data` field is type `string`.

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  "result": {
    "context": { "apiVersion": "2.0.15", "slot": 341197933 },
    "value": [
      {
        // !hover pubkey
        "pubkey": "BGocb4GEpbTFm8UFV2VsDSaBXHELPfAXrvd4vtt8QWrA",
        // !hover(1:27) account
        "account": {
          "data": {
            "program": "spl-token",
            "parsed": {
              "info": {
                "isNative": false,
                "mint": "2cHr7QS3xfuSV8wdxo3ztuF4xbiarF6Nrgx3qpx3HzXR",
                "owner": "A1TMhSGzQxMr1TboBKtgixKz1sS6REASMxPo1qsyTSJd",
                "state": "initialized",
                "tokenAmount": {
                  "amount": "420000000000000",
                  "decimals": 6,
                  "uiAmount": 420000000.0,
                  "uiAmountString": "420000000"
                }
              },
              "type": "account"
            },
            "space": 165
          },
          "executable": false,
          "lamports": 2039280,
          "owner": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA",
          "rentEpoch": 18446744073709551615,
          "space": 165
        }
      }
    ]
  },
  "id": 1
}
```

!type array

An array of JSON objects containing:

##### !! pubkey

!type string

The account Pubkey as base-58 encoded string

##### !! account

!type object

A JSON object containing:

- `lamports: <u64>` - number of lamports assigned to this account, as a u64
- `owner: <string>` - base-58 encoded Pubkey of the program this account has
  been assigned to
- `data: <object>` - Token state data associated with the account, either as
  encoded binary data or in JSON format `{<program>: <state>}`
- `executable: <bool>` - boolean indicating if the account contains a program
  (and is strictly read-only)
- `rentEpoch: <u64>` - the epoch at which this account will next owe rent, as
  u64
- `space: <u64>` - the data size of the account

When the data is requested with the `jsonParsed` encoding a format similar to
that of the [Token Balances Structure](/docs/rpc/json-structures#token-balances)
can be expected inside the structure, both for the `tokenAmount` and the
`delegatedAmount` - with the latter being an optional object.

</APIMethod>
---
title: getTokenLargestAccounts
hideTableOfContents: true
h1: getTokenLargestAccounts RPC Method
---

Returns the 20 largest accounts of a particular SPL Token type.

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "getTokenLargestAccounts",
  "params": [
    // !hover pubkey
    "3wyAj7Rt1TWVPZVteFJPLa26JmLvdb1CAKEFZm3NY75E",
    // !hover(1:3) 1
    {
      // !hover commitment
      "commitment": "finalized"
    }
  ]
}
```

```ts !!request title="Kit"
import { address, createSolanaRpc } from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

// !hover pubkey
let mint = address("Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr");

let largestHolders = await rpc.getTokenLargestAccounts(mint).send();

console.log(largestHolders);
```

```ts !!request title="web3.js"
import { Connection, PublicKey, clusterApiUrl } from "@solana/web3.js";

const connection = new Connection(clusterApiUrl("devnet"), "confirmed");

// !hover pubkey
let mint = new PublicKey!("Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr");

let largestHolders = await connection.getTokenLargestAccounts(mint);

console.log(largestHolders);
```

```rs !!request title="Rust"
use anyhow::Result;
use solana_client::nonblocking::rpc_client::RpcClient;
use solana_sdk::{commitment_config::CommitmentConfig, pubkey};

#[tokio::main]
async fn main() -> Result<()> {
    let client = RpcClient::new_with_commitment(
        String::from("https://api.devnet.solana.com"),
        CommitmentConfig::confirmed(),
    );

    // !hover pubkey
    let mint = pubkey!("Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr");

    let largest_holders = client.get_token_largest_accounts(&mint).await?;

    println!("{:#?}", largest_holders);

    Ok(())
}
```

### !params

#### !! pubkey

!type string
!required

Pubkey of the token Mint to query, as base-58 encoded string

#### !! 1

!type object

Configuration object containing the following fields:

##### !! commitment

!type string

The commitment describes how finalized a block is at that point in time. See
[Configuring State Commitment](/docs/rpc#configuring-state-commitment).

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  "result": {
    "context": { "slot": 1114 },
    // !hover(1:16) result
    "value": [
      {
        // !hover address
        "address": "FYjHNoFtSQ5uijKrZFyYAxvEr87hsKXkXcxkcmkBAf4r",
        // !hover amount
        "amount": "771",
        // !hover decimals
        "decimals": 2,
        // !hover uiAmount
        "uiAmount": 7.71,
        // !hover uiAmountString
        "uiAmountString": "7.71"
      },
      {
        "address": "BnsywxTcaYeNUtzrPxQUvzAWxfzZe3ZLUJ4wMMuLESnu",
        "amount": "229",
        "decimals": 2,
        "uiAmount": 2.29,
        "uiAmountString": "2.29"
      }
    ]
  },
  "id": 1
}
```

!type array

An array of JSON objects containing:

##### !! address

!type string

The address of the token account

##### !! amount

!type string

The raw token account balance without decimals, a string representation of u64

##### !! decimals

!type u8

Number of base 10 digits to the right of the decimal place

##### !! uiAmount

!type number | null

The token account balance, using mint-prescribed decimals **DEPRECATED**

##### !! uiAmountString

!type string

The token account balance as a string, using mint-prescribed decimals

</APIMethod>
---
title: getTokenSupply
hideTableOfContents: true
h1: getTokenSupply RPC Method
---

Returns the total supply of an SPL Token type.

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "getTokenSupply",
  "params": [
    // !hover pubkey
    "3wyAj7Rt1TWVPZVteFJPLa26JmLvdb1CAKEFZm3NY75E",
    // !hover(1:3) 1
    {
      // !hover commitment
      "commitment": "finalized"
    }
  ]
}
```

```ts !!request title="Kit"
import { address, createSolanaRpc } from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

// !hover pubkey
let mint = address("Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr");

let tokenSupply = await rpc.getTokenSupply(mint).send();

console.log(tokenSupply);
```

```ts !!request title="web3.js"
import { Connection, PublicKey, clusterApiUrl } from "@solana/web3.js";

const connection = new Connection(clusterApiUrl("devnet"), "confirmed");

// !hover pubkey
let mint = new PublicKey!("Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr");

let tokenSupply = await connection.getTokenSupply(mint);

console.log(tokenSupply);
```

```rs !!request title="Rust"
use anyhow::Result;
use solana_client::nonblocking::rpc_client::RpcClient;
use solana_sdk::{commitment_config::CommitmentConfig, pubkey};

#[tokio::main]
async fn main() -> Result<()> {
    let client = RpcClient::new_with_commitment(
        String::from("https://api.devnet.solana.com"),
        CommitmentConfig::confirmed(),
    );

    // !hover pubkey
    let mint = pubkey!("Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr");

    let token_supply = client.get_token_supply(&mint).await?;

    println!("{:#?}", token_supply);

    Ok(())
}
```

### !params

#### !! pubkey

!type string
!required

Pubkey of the token Mint to query, as base-58 encoded string

#### !! 1

!type object

Configuration object containing the following fields:

##### !! commitment

!type string

The commitment describes how finalized a block is at that point in time. See
[Configuring State Commitment](/docs/rpc#configuring-state-commitment).

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  "result": {
    "context": { "slot": 1114 },
    // !hover(1:6) result
    "value": {
      // !hover amount
      "amount": "100000",
      // !hover decimals
      "decimals": 2,
      // !hover uiAmount
      "uiAmount": 1000,
      // !hover uiAmountString
      "uiAmountString": "1000"
    }
  },
  "id": 1
}
```

!type object

A JSON object containing:

##### !! amount

!type string

The raw total token supply without decimals, a string representation of u64

##### !! decimals

!type u8

Number of base 10 digits to the right of the decimal place

##### !! uiAmount

!type number | null
!deprecated

The total token supply, using mint-prescribed decimals

##### !! uiAmountString

!type string

The total token supply as a string, using mint-prescribed decimals

</APIMethod>
---
title: getTransaction
hideTableOfContents: true
h1: getTransaction RPC Method
---

Returns transaction details for a confirmed transaction

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "getTransaction",
  "params": [
    // !hover signature
    "5Pj5fCupXLUePYn18JkY8SrRaWFiUctuDTRwvUy2ML9yvkENLb1QMYbcBGcBXRrSVDjp7RjUwk9a3rLC6gpvtYpZ",
    // !hover(1:5) config
    {
      // !hover commitment
      "commitment": "confirmed",
      // !hover maxSupportedTransactionVersion
      "maxSupportedTransactionVersion": 0,
      // !hover encoding
      "encoding": "json"
    }
  ]
}
```

```ts !!request title="Kit"
import { createSolanaRpc, type Signature } from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

// !hover signature
let signature =
  "5zSQuTcWsPy2cVAshBXWuJJXLwMD1GbgMpz3iq4xgwiV1s6mxYRbYb7qBiRGZd1xvDcYhQQRBKoNcnW8eKtcyZWg";

let transaction = await rpc.getTransaction(signature as Signature).send();

console.log(transaction);
```

```ts !!request title="web3.js"
import {
  Connection,
  PublicKey,
  clusterApiUrl,
  type GetVersionedTransactionConfig,
} from "@solana/web3.js";

const connection = new Connection(clusterApiUrl("devnet"), "confirmed");

// !hover signature
let signature =
  "5zSQuTcWsPy2cVAshBXWuJJXLwMD1GbgMpz3iq4xgwiV1s6mxYRbYb7qBiRGZd1xvDcYhQQRBKoNcnW8eKtcyZWg";

// !hover(1:3) 1
let config: GetVersionedTransactionConfig = {
  // !hover commitment
  commitment: "finalized",
  // !hover maxSupportedTransactionVersion
  maxSupportedTransactionVersion: 0,
};

let transaction = await connection.getTransaction(signature, config);

console.log(transaction);
```

```rs !!request title="Rust"
use anyhow::Result;
use solana_client::{nonblocking::rpc_client::RpcClient, rpc_config::RpcTransactionConfig};
use solana_sdk::{commitment_config::CommitmentConfig, signature::Signature};
use solana_transaction_status_client_types::UiTransactionEncoding;
use std::str::FromStr;

#[tokio::main]
async fn main() -> Result<()> {
    let client = RpcClient::new_with_commitment(
        String::from("https://api.devnet.solana.com"),
        CommitmentConfig::confirmed(),
    );

    // !hover(1:3) signature
    let tx_sig = Signature::from_str(
        "5zSQuTcWsPy2cVAshBXWuJJXLwMD1GbgMpz3iq4xgwiV1s6mxYRbYb7qBiRGZd1xvDcYhQQRBKoNcnW8eKtcyZWg",
    )?;

    // !hover(1:5) 1
    let config = RpcTransactionConfig {
        // !hover commitment
        commitment: CommitmentConfig::finalized().into(),
        // !hover encoding
        encoding: UiTransactionEncoding::Base64.into(),
        // !hover maxSupportedTransactionVersion
        max_supported_transaction_version: Some(0),
    };

    let transaction = client.get_transaction_with_config(&tx_sig, config).await?;

    println!("{:#?}", transaction);

    Ok(())
}
```

### !params

#### !! signature

!type string
!required

Transaction signature, as base-58 encoded string

#### !! config

!type object

Configuration object containing the following fields:

##### !! commitment

!type string
!values confirmed finalized
!default finalized

The commitment describes how finalized a block is at that point in time. See
[Configuring State Commitment](/docs/rpc#configuring-state-commitment).

- `processed` is not supported.

##### !! maxSupportedTransactionVersion

!type number
!values 0
!default 0

Currently, the only valid value for this parameter is `0`.
Setting it to `0` allows you to fetch all transactions, including both Versioned and legacy transactions.

This parameter determines the maximum transaction version that will be returned in the response.
If you request a transaction with a higher version than this value, an error will be returned.
If you omit this parameter, only legacy transactions will be returned—any versioned transaction will result in an error.


##### !! encoding

!type string
!values json jsonParsed base64 base58
!default json

Encoding for the returned Transaction

- `jsonParsed` encoding attempts to use program-specific state parsers to return
  more human-readable and explicit data in the
  `transaction.message.instructions` list.
- If `jsonParsed` is requested but a parser cannot be found, the instruction
  falls back to regular JSON encoding (`accounts`, `data`, and `programIdIndex`
  fields).

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover(1:64) result
  "result": {
    // !hover blockTime
    "blockTime": 1746479684,
    // !hover(1:30) meta
    // !collapse(1:30) collapsed
    "meta": {
      "computeUnitsConsumed": 150,
      "err": null,
      "fee": 5000,
      "innerInstructions": [],
      "loadedAddresses": {
        "readonly": [],
        "writable": []
      },
      "logMessages": [
        "Program 11111111111111111111111111111111 invoke [1]",
        "Program 11111111111111111111111111111111 success"
      ],
      "postBalances": [
        989995000,
        10000000,
        1
      ],
      "postTokenBalances": [],
      "preBalances": [
        1000000000,
        0,
        1
      ],
      "preTokenBalances": [],
      "rewards": [],
      "status": {
        "Ok": null
      }
    },
    // !hover slot
    "slot": 378917547,
    // !hover(1:29) transaction
    // !collapse(1:29) collapsed
    "transaction": {
      "message": {
        "accountKeys": [
          "7BvfixZx7Rwywf6EJFgRW6acEQ2FLSFJr4n3kLLVeEes",
          "6KtbxYovphtE3eHjPjr2sWwDfgaDwtAn2FcojDyzZWT6",
          "11111111111111111111111111111111"
        ],
        "header": {
          "numReadonlySignedAccounts": 0,
          "numReadonlyUnsignedAccounts": 1,
          "numRequiredSignatures": 1
        },
        "instructions": [
          {
            "accounts": [
              0,
              1
            ],
            "data": "3Bxs4NN8M2Yn4TLb",
            "programIdIndex": 2,
            "stackHeight": null
          }
        ],
        "recentBlockhash": "23dwTHxFhSzqohXhdni5LwpuSRpgN36YvVMCAM2VXQSf"
      },
      "signatures": [
        "5Pj5fCupXLUePYn18JkY8SrRaWFiUctuDTRwvUy2ML9yvkENLb1QMYbcBGcBXRrSVDjp7RjUwk9a3rLC6gpvtYpZ"
      ]
    },
    // !hover version
    "version": "legacy"
  },
  "id": 1
}
```

!type object | null

Returns `null` if transaction is not found or not confirmed, otherwise returns
an object containing:

##### !! blockTime

!type i64 | null

Estimated production time, as Unix timestamp (seconds since the Unix epoch) of
when the transaction was processed. null if not available

##### !! meta

!type object | null

Transaction status
[metadata object](/docs/rpc/json-structures#transaction-status-metadata) or
`null`.

##### !! slot

!type u64

The slot this transaction was processed in

##### !! transaction

!type object | [string,encoding]

[Transaction](/docs/rpc/json-structures#transactions) object, either in JSON
format or encoded binary data, depending on encoding parameter

##### !! version

!type "legacy" | number | undefined

Transaction version. Undefined if `maxSupportedTransactionVersion` is not set in
request params.

</APIMethod>
---
title: getTransactionCount
hideTableOfContents: true
h1: getTransactionCount RPC Method
---

Returns the current Transaction count from the ledger

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "getTransactionCount",
  "params": [
    // !hover(1:3) 0
    {
      // !hover commitment
      "commitment": "finalized"
    }
  ]
}
```

```ts !!request title="Kit"
import { createSolanaRpc } from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

let txCount = await rpc.getTransactionCount().send();

console.log(txCount);
```

```ts !!request title="web3.js"
import { Connection, clusterApiUrl } from "@solana/web3.js";

const connection = new Connection(clusterApiUrl("devnet"), "confirmed");

let txCount = await connection.getTransactionCount();

console.log(txCount);
```

```rs !!request title="Rust"
use anyhow::Result;
use solana_client::nonblocking::rpc_client::RpcClient;
use solana_sdk::commitment_config::CommitmentConfig;

#[tokio::main]
async fn main() -> Result<()> {
    let client = RpcClient::new_with_commitment(
        String::from("https://api.devnet.solana.com"),
        CommitmentConfig::confirmed(),
    );

    let tx_count = client.get_transaction_count().await?;

    println!("{:#?}", tx_count);

    Ok(())
}
```

### !params

#### !! 0

!type object
!optional

Configuration object containing the following fields:

##### !! commitment

!type string

The commitment describes how finalized a block is at that point in time. See
[Configuring State Commitment](/docs/rpc#configuring-state-commitment).

##### !! minContextSlot

!type number

The minimum slot that the request can be evaluated at

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover result
  "result": 268,
  "id": 1
}
```

!type u64

The current Transaction count from the ledger

</APIMethod>
---
title: getVersion
hideTableOfContents: true
h1: getVersion RPC Method
---

Returns the current Solana version running on the node

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "getVersion"
}
```

```ts !!request title="Kit"
import { createSolanaRpc } from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

let version = await rpc.getVersion().send();

console.log(version);
```

```ts !!request title="web3.js"
import { Connection, clusterApiUrl } from "@solana/web3.js";

const connection = new Connection(clusterApiUrl("devnet"), "confirmed");

let version = await connection.getVersion();

console.log(version);
```

```rs !!request title="Rust"
use anyhow::Result;
use solana_client::nonblocking::rpc_client::RpcClient;
use solana_sdk::commitment_config::CommitmentConfig;

#[tokio::main]
async fn main() -> Result<()> {
    let client = RpcClient::new_with_commitment(
        String::from("https://api.devnet.solana.com"),
        CommitmentConfig::confirmed(),
    );

    let version = client.get_version().await?;

    println!("{}", version);

    Ok(())
}
```

### !params

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover(1:4) result
  "result": {
    // !hover solana-core
    "solana-core": "1.16.7",
    // !hover feature-set
    "feature-set": 2891131721
  },
  "id": 1
}
```

!type object

A JSON object containing:

##### !! solana-core

!type string

Software version of solana-core

##### !! feature-set

!type u32

Unique identifier of the current software's feature set

</APIMethod>
---
title: getVoteAccounts
hideTableOfContents: true
h1: getVoteAccounts RPC Method
---

Returns the account info and associated stake for all the voting accounts in the
current bank.

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "getVoteAccounts",
  "params": [
    // !hover(1:3) 0
    {
      // !hover commitment
      "commitment": "finalized",
      // !hover votePubkey
      "votePubkey": "i7NyKBMJCA9bLM2nsGyAGCKHECuR2L5eh4GqFciuwNT"
    }
  ]
}
```

```ts !!request title="Kit"
import { address, createSolanaRpc } from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

// !hover votePubkey
let votePubkey = address("5ZWgXcyqrrNpQHCme5SdC5hCeYb2o3fEJhF7Gok3bTVN");

let voteAccounts = await rpc
  .getVoteAccounts({
    votePubkey,
  })
  .send();

console.log(voteAccounts);
```

```ts !!request title="web3.js"
import { Connection, PublicKey, clusterApiUrl } from "@solana/web3.js";

const connection = new Connection(clusterApiUrl("devnet"), "confirmed");

let version = await connection.getVoteAccounts();

console.log(version);
```

```rs !!request title="Rust"
use anyhow::Result;
use solana_client::{nonblocking::rpc_client::RpcClient, rpc_config::RpcGetVoteAccountsConfig};
use solana_sdk::commitment_config::CommitmentConfig;

#[tokio::main]
async fn main() -> Result<()> {
    let client = RpcClient::new_with_commitment(
        String::from("https://api.devnet.solana.com"),
        CommitmentConfig::confirmed(),
    );

    // !hover votePubkey
    let vote_pubkey = String::from("5ZWgXcyqrrNpQHCme5SdC5hCeYb2o3fEJhF7Gok3bTVN");

    let config = RpcGetVoteAccountsConfig {
        vote_pubkey: Some(vote_pubkey),
        commitment: CommitmentConfig::finalized().into(),
        keep_unstaked_delinquents: None,
        delinquent_slot_distance: None,
    };

    let vote_accounts = client.get_vote_accounts_with_config(config).await?;

    println!("{:#?}", vote_accounts);

    Ok(())
}
```

### !params

#### !! 0

!type object
!optional

Configuration object containing the following fields:

##### !! commitment

!type string

The commitment describes how finalized a block is at that point in time. See
[Configuring State Commitment](/docs/rpc#configuring-state-commitment).

##### !! votePubkey

!type string

Only return results for this validator vote address (base-58 encoded)

##### !! keepUnstakedDelinquents

!type bool

Do not filter out delinquent validators with no stake

##### !! delinquentSlotDistance

!type u64

Specify the number of slots behind the tip that a validator must fall to be
considered delinquent. **NOTE:** For the sake of consistency between ecosystem
products, _it is **not** recommended that this argument be specified._

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover(1:21) result
  "result": {
    "current": [
      {
        // !hover activatedStake
        "activatedStake": 38263229364446900,
        // !hover commission
        "commission": 95,
        // !hover(1:7) epochCredits
        "epochCredits": [
          [902, 1383125544, 1376213656],
          [903, 1390037304, 1383125544],
          [904, 1396949288, 1390037304],
          [905, 1403861272, 1396949288],
          [906, 1406766600, 1403861272]
        ],
        // !hover epochVoteAccount
        "epochVoteAccount": true,
        // !hover lastVote
        "lastVote": 391573587,
        // !hover nodePubkey
        "nodePubkey": "dv2eQHeP4RFrJZ6UeiZWoc3XTtmtZCUKxxCApCDcRNV",
        // !hover rootSlot
        "rootSlot": 391573556,
        // !hover votePubkey
        "votePubkey": "i7NyKBMJCA9bLM2nsGyAGCKHECuR2L5eh4GqFciuwNT"
      }
    ],
    "delinquent": []
  },
  "id": 1
}
```

!type object

The result field will be a JSON object of `current` and `delinquent` accounts,
each containing an array of JSON objects with the following sub fields:

##### !! activatedStake

!type u64

The stake, in lamports, delegated to this vote account and active in this epoch

##### !! commission

!type number

Percentage (0-100) of rewards payout owed to the vote account

##### !! epochCredits

!type array

Latest history of earned credits for up to five epochs, as an array of arrays
containing: `[epoch, credits, previousCredits]`

##### !! epochVoteAccount

!type bool

Whether the vote account is staked for this epoch

##### !! lastVote

!type u64

Most recent slot voted on by this vote account

##### !! nodePubkey

!type string

Validator identity, as base-58 encoded string

##### !! rootSlot

!type u64

Current root slot for this vote account

##### !! votePubkey

!type string

Vote account address, as base-58 encoded string


</APIMethod>
---
title: HTTP Methods
seoTitle: Solana RPC HTTP Methods
hideTableOfContents: false
h1: Solana RPC HTTP Methods
---

Solana nodes accept HTTP requests using the
[JSON-RPC 2.0](https://www.jsonrpc.org/specification) specification.

> For JavaScript applications, use the
> [@solana/web3.js](https://github.com/solana-labs/solana-web3.js) library as a
> convenient interface for the RPC methods to interact with a Solana node. For
> an PubSub connection to a Solana node, use the
> [Websocket API](/docs/rpc/websocket/).

## RPC HTTP Endpoint

Default port: `8899`

- http://localhost:8899
- http://192.168.1.88:8899

## Request Formatting

To make a JSON-RPC request, send an HTTP POST request with a
`Content-Type: application/json` header. The JSON request data should contain 4
fields:

- `jsonrpc: <string>` - set to `"2.0"`
- `id: <string | number | null>` - a unique identifier for the request,
  generated by the client. Typically a string or number, though null is
  technically allowed but not advised
- `method: <string>` - a string containing the method to be invoked
- `params: <array>` - a JSON array of ordered parameter values

Example using curl:

```shell
curl https://api.devnet.solana.com -s -X POST -H "Content-Type: application/json" -d '
  {
    "jsonrpc": "2.0",
    "id": 1,
    "method": "getBalance",
    "params": [
      "83astBRguLMdt2h5U1Tpdq5tjFoJ6noeGwaY3mDLVcri"
    ]
  }
'
```

The response output will be a JSON object with the following fields:

- `jsonrpc: <string>` - matching the request specification
- `id: <number>` - matching the request identifier
- `result: <array|number|object|string>` - requested data or success
  confirmation

Requests can be sent in batches by sending an array of JSON-RPC request objects
as the data for a single POST.

### Example Request

The commitment parameter should be included as the last element in the `params`
array:

```shell
curl https://api.devnet.solana.com -s -X POST -H "Content-Type: application/json" -d '
  {
    "jsonrpc": "2.0",
    "id": 1,
    "method": "getBalance",
    "params": [
      "83astBRguLMdt2h5U1Tpdq5tjFoJ6noeGwaY3mDLVcri",
      {
        "commitment": "finalized"
      }
    ]
  }
'
```

## Definitions

- Hash: A SHA-256 hash of a chunk of data.
- Pubkey: The public key of a Ed25519 key-pair.
- Transaction: A list of Solana instructions signed by a client keypair to
  authorize those actions.
- Signature: An Ed25519 signature of transaction's payload data including
  instructions. This can be used to identify transactions.

## Health Check

Although not a JSON RPC API, a `GET /health` at the RPC HTTP Endpoint provides a
health-check mechanism for use by load balancers or other network
infrastructure. This request will always return a HTTP 200 OK response with a
body of "ok", "behind" or "unknown":

- `ok`: The node is within `HEALTH_CHECK_SLOT_DISTANCE` slots from the latest
  cluster confirmed slot
- `behind { distance }`: The node is behind `distance` slots from the latest
  cluster confirmed slot where `distance > HEALTH_CHECK_SLOT_DISTANCE`
- `unknown`: The node is unable to determine where it stands in relation to the
  cluster
---
title: isBlockhashValid
hideTableOfContents: true
h1: isBlockhashValid RPC Method
---

Returns whether a blockhash is still valid or not

<Callout type="warn" title={"Version Restriction"}>
  This method is only available in `solana-core` v1.9 or newer. Please use
  [getFeeCalculatorForBlockhash](/docs/rpc/http/getfeecalculatorforblockhash)
  for `solana-core` v1.8 and below.
</Callout>

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 45,
  "method": "isBlockhashValid",
  "params": [
    // !hover blockhash
    "J7rBdM6AecPDEZp8aPq5iPSNKVkU5Q76F3oAV4eW5wsW",
    // !hover(1:3) config
    {
      // !hover commitment
      "commitment": "processed"
    }
  ]
}
```

```ts !!request title="Kit"
import { createSolanaRpc, type Blockhash } from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

// !hover blockhash
let blockhash = "J7rBdM6AecPDEZp8aPq5iPSNKVkU5Q76F3oAV4eW5wsW";

let isValid = await rpc.isBlockhashValid(blockhash as Blockhash).send();

console.log(isValid);
```

```ts !!request title="web3.js"
import { Connection, clusterApiUrl } from "@solana/web3.js";

const connection = new Connection(clusterApiUrl("devnet"), "confirmed");

// !hover blockhash
let blockhash = "J7rBdM6AecPDEZp8aPq5iPSNKVkU5Q76F3oAV4eW5wsW";

let isValid = await connection.isBlockhashValid(blockhash);

console.log(isValid);
```

```rs !!request title="Rust"
use std::str::FromStr;

use anyhow::Result;
use solana_client::nonblocking::rpc_client::RpcClient;
use solana_sdk::{commitment_config::CommitmentConfig, hash::Hash};

#[tokio::main]
async fn main() -> Result<()> {
    let client = RpcClient::new_with_commitment(
        String::from("https://api.devnet.solana.com"),
        CommitmentConfig::confirmed(),
    );

    // !hover blockhash
    let blockhash = Hash::from_str("J7rBdM6AecPDEZp8aPq5iPSNKVkU5Q76F3oAV4eW5wsW")?;

    let is_valid = client
        .is_blockhash_valid(&blockhash, CommitmentConfig::finalized())
        .await?;

    println!("{:#?}", is_valid);

    Ok(())
}
```

### !params

#### !! blockhash

!type string
!required

The blockhash of the block to evaluate, as base-58 encoded string

#### !! config

!type object

Configuration object containing the following fields:

##### !! commitment

!type string

The commitment describes how finalized a block is at that point in time. See
[Configuring State Commitment](/docs/rpc#configuring-state-commitment).

##### !! minContextSlot

!type number

The minimum slot that the request can be evaluated at

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  "result": {
    "context": { "slot": 2483 },
    // !hover result
    "value": false
  },
  "id": 45
}
```

!type bool

Whether the blockhash is still valid

</APIMethod>
{
  "title": "HTTP Methods",
  "pages": [
    "getaccountinfo",
    "getbalance",
    "getblock",
    "getblockcommitment",
    "getblockheight",
    "getblockproduction",
    "getblocks",
    "getblockswithlimit",
    "getblocktime",
    "getclusternodes",
    "getepochinfo",
    "getepochschedule",
    "getfeeformessage",
    "getfirstavailableblock",
    "getgenesishash",
    "gethealth",
    "gethighestsnapshotslot",
    "getidentity",
    "getinflationgovernor",
    "getinflationrate",
    "getinflationreward",
    "getlargestaccounts",
    "getlatestblockhash",
    "getleaderschedule",
    "getmaxretransmitslot",
    "getmaxshredinsertslot",
    "getminimumbalanceforrentexemption",
    "getmultipleaccounts",
    "getprogramaccounts",
    "getrecentperformancesamples",
    "getrecentprioritizationfees",
    "getsignaturesforaddress",
    "getsignaturestatuses",
    "getslot",
    "getslotleader",
    "getslotleaders",
    "getstakeminimumdelegation",
    "getsupply",
    "gettokenaccountbalance",
    "gettokenaccountsbydelegate",
    "gettokenaccountsbyowner",
    "gettokenlargestaccounts",
    "gettokensupply",
    "gettransaction",
    "gettransactioncount",
    "getversion",
    "getvoteaccounts",
    "isblockhashvalid",
    "minimumledgerslot",
    "requestairdrop",
    "sendtransaction",
    "simulatetransaction"
  ],
  "defaultOpen": true
}
---
title: minimumLedgerSlot
hideTableOfContents: true
h1: minimumLedgerSlot RPC Method
---

Returns the lowest slot that the node has information about in its ledger.

<Callout type="info">
  This value may increase over time if the node is configured to purge older
  ledger data
</Callout>

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "minimumLedgerSlot"
}
```

```ts !!request title="Kit"
import { createSolanaRpc } from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

let minLedgerSlot = await rpc.minimumLedgerSlot().send();

console.log(minLedgerSlot);
```

```ts !!request title="web3.js"
import { Connection, clusterApiUrl } from "@solana/web3.js";

const connection = new Connection(clusterApiUrl("devnet"), "confirmed");

let minLedgerSlot = await connection.getMinimumLedgerSlot();

console.log(minLedgerSlot);
```

```rs !!request title="Rust"
use anyhow::Result;
use solana_client::nonblocking::rpc_client::RpcClient;
use solana_sdk::commitment_config::CommitmentConfig;

#[tokio::main]
async fn main() -> Result<()> {
    let client = RpcClient::new_with_commitment(
        String::from("https://api.devnet.solana.com"),
        CommitmentConfig::confirmed(),
    );

    let min_ledger_slot = client.minimum_ledger_slot().await?;

    println!("{}", min_ledger_slot);

    Ok(())
}
```

### !params

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover result
  "result": 1234,
  "id": 1
}
```

!type u64

The minimum ledger slot number

</APIMethod>
---
title: requestAirdrop
hideTableOfContents: true
h1: requestAirdrop RPC Method
---

Requests an airdrop of lamports to a Pubkey

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "requestAirdrop",
  "params": [
    // !hover pubkey
    "83astBRguLMdt2h5U1Tpdq5tjFoJ6noeGwaY3mDLVcri",
    // !hover lamports
    1000000000,
    // !hover(1:3) config
    {
      // !hover commitment
      "commitment": "finalized"
    }
  ]
}
```

```ts !!request title="Kit"
import { address, createSolanaRpc, lamports } from "@solana/kit";
import { LAMPORTS_PER_SOL } from "@solana/web3.js";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

// !hover pubkey
let receiver = address("4kg8oh3jdNtn7j2wcS7TrUua31AgbLzDVkBZgTAe44aF");

// !hover lamports
let airdropAmt = lamports(BigInt(1 * LAMPORTS_PER_SOL));

let signature = await rpc.requestAirdrop(receiver, airdropAmt).send();

console.log(signature);
```

```ts !!request title="web3.js"
import {
  Connection,
  LAMPORTS_PER_SOL,
  PublicKey,
  clusterApiUrl,
} from "@solana/web3.js";

const connection = new Connection(clusterApiUrl("devnet"), "confirmed");

// !hover pubkey
let receiver = new PublicKey("4kg8oh3jdNtn7j2wcS7TrUua31AgbLzDVkBZgTAe44aF");

// !hover lamports
let airdropAmt = 1 * LAMPORTS_PER_SOL;

let sig = await connection.requestAirdrop(receiver, airdropAmt);

console.log(sig);
```

```rs !!request title="Rust"
use anyhow::Result;
use solana_client::nonblocking::rpc_client::RpcClient;
use solana_sdk::{commitment_config::CommitmentConfig, native_token::LAMPORTS_PER_SOL, pubkey};

#[tokio::main]
async fn main() -> Result<()> {
    let client = RpcClient::new_with_commitment(
        String::from("https://api.devnet.solana.com"),
        CommitmentConfig::confirmed(),
    );

    // !hover pubkey
    let receiver = pubkey!("4kg8oh3jdNtn7j2wcS7TrUua31AgbLzDVkBZgTAe44aF");

    // !hover lamports
    let lamports = 1 * LAMPORTS_PER_SOL;

    let transaction_signature = client.request_airdrop(&receiver, lamports).await?;
    loop {
        if client.confirm_transaction(&transaction_signature).await? {
            break;
        }
    }

    println!("{}", transaction_signature);

    Ok(())
}
```

### !params

#### !! pubkey

!type string
!required

Pubkey of account to receive lamports, as a base-58 encoded string

#### !! lamports

!type u64
!required

Amount of lamports to airdrop

#### !! config

!type object

Configuration object containing the following fields:

##### !! commitment

!type string

The commitment describes how finalized a block is at that point in time. See
[Configuring State Commitment](/docs/rpc#configuring-state-commitment).

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover result
  "result": "5VERv8NMvzbJMEkV8xnrLkEaWRtSz9CosKDYjCJjBRnbJLgp8uirBgmQpjKhoR4tjF3ZpRzrFmBV6UjKdiSZkQUW",
  "id": 1
}
```

!type string

Transaction Signature of the airdrop, as a base-58 encoded string

</APIMethod>
---
title: sendTransaction
hideTableOfContents: true
h1: sendTransaction RPC Method
---

Submits a signed transaction to the cluster for processing.

This method does not alter the transaction in any way; it relays the transaction
created by clients to the node as-is.

If the node's rpc service receives the transaction, this method immediately
succeeds, without waiting for any confirmations. A successful response from this
method does not guarantee the transaction is processed or confirmed by the
cluster.

While the rpc service will reasonably retry to submit it, the transaction could
be rejected if transaction's `recent_blockhash` expires before it lands.

Use [`getSignatureStatuses`](/docs/rpc/http/getsignaturestatuses) to ensure a
transaction is processed and confirmed.

Before submitting, the following preflight checks are performed:

1. The transaction signatures are verified
2. The transaction is simulated against the bank slot specified by the preflight
   commitment. On failure an error will be returned. Preflight checks may be
   disabled if desired. It is recommended to specify the same commitment and
   preflight commitment to avoid confusing behavior.

The returned signature is the first signature in the transaction, which is used
to identify the transaction
([transaction id](/docs/references/terminology#transaction-id)). This identifier
can be easily extracted from the transaction data before submission.

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "sendTransaction",
  "params": [
    // !hover transaction
    "4hXTCkRzt9WyecNzV1XPgCDfGAZzQKNxLXgynz5QDuWWPSAZBZSHptvWRL3BjCvzUXRdKvHL2b7yGrRQcWyaqsaBCncVG7BFggS8w9snUts67BSh3EqKpXLUm5UMHfD7ZBe9GhARjbNQMLJ1QD3Spr6oMTBU6EhdB4RD8CP2xUxr2u3d6fos36PD98XS6oX8TQjLpsMwncs5DAMiD4nNnR8NBfyghGCWvCVifVwvA8B8TJxE1aiyiv2L429BCWfyzAme5sZW8rDb14NeCQHhZbtNqfXhcp2tAnaAT"
  ]
}
```

```ts !!request title="Kit"
import {
  createSolanaRpc,
  type Base64EncodedWireTransaction,
} from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

// !hover transaction
const base64Tx =
  "AbC/XNkPUUZ7/51SaG1wbG0ojrWHIGzVL73M8hRnDr73RkBAZc0ZnikluvcCeprAmqHDJrcPxPUbvEJMVBIiVQeAAQABAzfDSQC/GjcggrLsDpYz7jAlT+Gca846HqtFb8UQMM9cCWPIi4AX32PV8HrY7/1WgoRc3IATttceZsUMeQ1qx7UAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIgsVWEgMTiOYp63gTtuYGw+izfm6wKQdivpiXQBpNnYAQICAAEMAgAAAEBCDwAAAAAAAA==";

const signature = await rpc
  .sendTransaction(base64Tx as Base64EncodedWireTransaction, {
    encoding: "base64",
  })
  .send();

console.log(signature);
```

```ts !!request title="web3.js"
import {
  Connection,
  VersionedTransaction,
  clusterApiUrl,
} from "@solana/web3.js";

const connection = new Connection(clusterApiUrl("devnet"), "confirmed");

const base64Tx =
  "AbuRLtc5C9bZtAUT4F4Y2H5SRRUK1HwOFZOK3V4qm/78MDJt+M2de/RCCaI3iTyodDepmrkUWbss0XRHS0lk5AOAAQABAzfDSQC/GjcggrLsDpYz7jAlT+Gca846HqtFb8UQMM9cCWPIi4AX32PV8HrY7/1WgoRc3IATttceZsUMeQ1qx7UAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD2dTRgcJmzcoGH1R3c2WqtHah2H19KvbC1p6BxLDqfoAQICAAEMAgAAAADKmjsAAAAAAA==";

// !hover transaction
let tx = VersionedTransaction.deserialize(Buffer.from(base64Tx, "base64"));

let sig = await connection.sendTransaction(tx);

console.log(sig);
```

```rs !!request title="Rust"
use anyhow::Result;
use base64::{Engine as _, engine::general_purpose};
use solana_client::{nonblocking::rpc_client::RpcClient, rpc_config::RpcSendTransactionConfig};
use solana_sdk::{
    commitment_config::{CommitmentConfig, CommitmentLevel},
    transaction::VersionedTransaction,
};
use solana_transaction_status_client_types::UiTransactionEncoding;

#[tokio::main]
async fn main() -> Result<()> {
    let client = RpcClient::new_with_commitment(
        String::from("https://api.devnet.solana.com"),
        CommitmentConfig::confirmed(),
    );

    // !hover transaction
    let b64_tx = "AbuRLtc5C9bZtAUT4F4Y2H5SRRUK1HwOFZOK3V4qm/78MDJt+M2de/RCCaI3iTyodDepmrkUWbss0XRHS0lk5AOAAQABAzfDSQC/GjcggrLsDpYz7jAlT+Gca846HqtFb8UQMM9cCWPIi4AX32PV8HrY7/1WgoRc3IATttceZsUMeQ1qx7UAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD2dTRgcJmzcoGH1R3c2WqtHah2H19KvbC1p6BxLDqfoAQICAAEMAgAAAADKmjsAAAAAAA==";
    let tx_bytes = general_purpose::STANDARD.decode(b64_tx).unwrap();
    let tx: VersionedTransaction = bincode::deserialize(&tx_bytes).unwrap();

    // !hover(1:7) config
    let config = RpcSendTransactionConfig {
        // !hover skipPreflight
        skip_preflight: true,
        // !hover preflightCommitment
        preflight_commitment: CommitmentLevel::Finalized.into(),
        // !hover encoding
        encoding: UiTransactionEncoding::Base64.into(),
        // !hover maxRetries
        max_retries: None,
        // !hover  minContextSlot
        min_context_slot: None,
    };

    match client.send_transaction_with_config(&tx, config).await {
        Ok(signature) => println!("Transaction Signature: {}", signature),
        Err(err) => eprintln!("Error transferring tokens: {}", err),
    }

    Ok(())
}
```

### !params

#### !! transaction

!type string
!required

Fully-signed Transaction, as encoded string.

#### !! config

!type object

Configuration object containing the following fields:

##### !! encoding

!type string
!values base58 base64
!default base58

Encoding used for the transaction data. Values: `base58` (_slow_,
**DEPRECATED**), or `base64`.

##### !! skipPreflight

!type bool

When `true`, skip the preflight transaction checks. Default: `false`.

##### !! preflightCommitment

!type string

Commitment level to use for preflight. See
[Configuring State Commitment](/docs/rpc/index.mdx#configuring-state-commitment).
Default `finalized`.

##### !! maxRetries

!type usize

Maximum number of times for the RPC node to retry sending the transaction to the
leader. If this parameter not provided, the RPC node will retry the transaction
until it is finalized or until the blockhash expires.

##### !! minContextSlot

!type number
!optional

Set the minimum slot at which to perform preflight transaction checks

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover result
  "result": "2id3YC2jK9G5Wo2phDx4gJVAew8DcY5NAojnVuao8rkxwPYPe8cSwE5GzhEgJA2y8fVjDEo6iR6ykBvDxrTQrtpb",
  "id": 1
}
```

!type string

First Transaction Signature embedded in the transaction, as base-58 encoded
string ([transaction id](/docs/references/terminology#transaction-id))

</APIMethod>
---
title: simulateTransaction
hideTableOfContents: true
h1: simulateTransaction RPC Method
---

Simulate sending a transaction

<APIMethod>

```jsonc !!request curl
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "simulateTransaction",
  "params": [
    // !hover transaction
    "AQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAEEjNmKiZGiOtSZ+g0//wH5kEQo3+UzictY+KlLV8hjXcs44M/Xnr+1SlZsqS6cFMQc46yj9PIsxqkycxJmXT+veJjIvefX4nhY9rY+B5qreeqTHu4mG6Xtxr5udn4MN8PnBt324e51j94YQl285GzN2rYa/E2DuQ0n/r35KNihi/zamQ6EeyeeVDvPVgUO2W3Lgt9hT+CfyqHvIa11egFPCgEDAwIBAAkDZAAAAAAAAAA=",
    // !hover(1:5) config
    {
      // !hover commitment
      "commitment": "confirmed",
      // !hover encoding
      "encoding": "base64",
      // !hover replaceRecentBlockhash
      "replaceRecentBlockhash": true
    }
  ]
}
```

```ts !!request title="Kit"
import {
  createSolanaRpc,
  type Base64EncodedWireTransaction,
} from "@solana/kit";

const rpc_url = "https://api.devnet.solana.com";
const rpc = createSolanaRpc(rpc_url);

// !hover(1:2) transaction
const base64Tx: Base64EncodedWireTransaction =
  "AQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAEEjNmKiZGiOtSZ+g0//wH5kEQo3+UzictY+KlLV8hjXcs44M/Xnr+1SlZsqS6cFMQc46yj9PIsxqkycxJmXT+veJjIvefX4nhY9rY+B5qreeqTHu4mG6Xtxr5udn4MN8PnBt324e51j94YQl285GzN2rYa/E2DuQ0n/r35KNihi/zamQ6EeyeeVDvPVgUO2W3Lgt9hT+CfyqHvIa11egFPCgEDAwIBAAkDZAAAAAAAAAA=" as Base64EncodedWireTransaction;

// !hover(1:9) config
let simulateTxConfig = {
  // !hover commitment
  commitment: "finalized",
  // !hover encoding
  encoding: "base64",
  // !hover replaceRecentBlockhash
  replaceRecentBlockhash: true,
  // !hover sigVerify
  sigVerify: false,
  // !hover minContextSlot
  minContextSlot: undefined,
  // !hover innerInstructions
  innerInstructions: undefined,
  // !hover accounts
  accounts: undefined,
};

let simulateResult = await rpc
  .simulateTransaction(base64Tx, simulateTxConfig)
  .send();

console.log(simulateResult);
```

```ts !!request title="web3.js"
import {
  Connection,
  VersionedTransaction,
  clusterApiUrl,
  type SimulateTransactionConfig,
} from "@solana/web3.js";

const connection = new Connection(clusterApiUrl("devnet"), "confirmed");

// !hover(1:2) transaction
const base64Tx =
  "AQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAEEjNmKiZGiOtSZ+g0//wH5kEQo3+UzictY+KlLV8hjXcs44M/Xnr+1SlZsqS6cFMQc46yj9PIsxqkycxJmXT+veJjIvefX4nhY9rY+B5qreeqTHu4mG6Xtxr5udn4MN8PnBt324e51j94YQl285GzN2rYa/E2DuQ0n/r35KNihi/zamQ6EeyeeVDvPVgUO2W3Lgt9hT+CfyqHvIa11egFPCgEDAwIBAAkDZAAAAAAAAAA=";

let tx = VersionedTransaction.deserialize(Buffer.from(base64Tx, "base64"));

// !hover(1:9) config
let simulateTxConfig: SimulateTransactionConfig = {
  // !hover commitment
  commitment: "finalized",
  // !hover replaceRecentBlockhash
  replaceRecentBlockhash: true,
  // !hover sigVerify
  sigVerify: false,
  // !hover minContextSlot
  minContextSlot: undefined,
  // !hover innerInstructions
  innerInstructions: undefined,
  // !hover accounts
  accounts: undefined,
};

let simulateResult = await connection.simulateTransaction(tx, simulateTxConfig);

console.log(simulateResult);
```

```rs !!request title="Rust"
use anyhow::Result;
use base64::{Engine as _, engine::general_purpose};
use solana_client::{nonblocking::rpc_client::RpcClient, rpc_config::RpcSimulateTransactionConfig};
use solana_sdk::{commitment_config::CommitmentConfig, transaction::VersionedTransaction};
use solana_transaction_status_client_types::UiTransactionEncoding;

#[tokio::main]
async fn main() -> Result<()> {
    let client = RpcClient::new_with_commitment(
        String::from("https://api.devnet.solana.com"),
        CommitmentConfig::confirmed(),
    );

    // !hover(1:2) transaction
    let b64_tx = "AQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAEEjNmKiZGiOtSZ+g0//wH5kEQo3+UzictY+KlLV8hjXcs44M/Xnr+1SlZsqS6cFMQc46yj9PIsxqkycxJmXT+veJjIvefX4nhY9rY+B5qreeqTHu4mG6Xtxr5udn4MN8PnBt324e51j94YQl285GzN2rYa/E2DuQ0n/r35KNihi/zamQ6EeyeeVDvPVgUO2W3Lgt9hT+CfyqHvIa11egFPCgEDAwIBAAkDZAAAAAAAAAA=";
    let tx_bytes = general_purpose::STANDARD.decode(b64_tx).unwrap();
    let tx: VersionedTransaction = bincode::deserialize(&tx_bytes).unwrap();

    // !hover(1:9) config
    let config = RpcSimulateTransactionConfig {
        // !hover commitment
        commitment: CommitmentConfig::finalized().into(),
        // !hover encoding
        encoding: UiTransactionEncoding::Base64.into(),
        // !hover replaceRecentBlockhash
        replace_recent_blockhash: true,
        // !hover sigVerify
        sig_verify: false,
        // !hover minContextSlot
        min_context_slot: None,
        // !hover innerInstructions
        inner_instructions: false,
        // !hover accounts
        accounts: None,
    };

    let simulate_result = client.simulate_transaction_with_config(&tx, config).await?;

    println!("{:#?}", simulate_result);

    Ok(())
}
```

### !params

#### !! transaction

!type string
!required

Transaction, as an encoded string.

<Callout type="info">
  The transaction must have a valid blockhash, but is not required to be signed.
</Callout>

#### !! config

!type object
!optional

Configuration object containing the following fields:

##### !! commitment

!type string

Commitment level to simulate the transaction at. See
[Configuring State Commitment](/docs/rpc/index.mdx#configuring-state-commitment).
Default `finalized`.

##### !! encoding

!type string
!values base58 base64
!default base58

Encoding used for the transaction data. Values: `base58` (_slow_,
**DEPRECATED**), or `base64`.


##### !! replaceRecentBlockhash

!type bool
!defaultValue false

If `true` the transaction recent blockhash will be replaced with the most recent
blockhash (conflicts with `sigVerify`)

##### !! sigVerify

!type bool
!defaultValue false

If `true` the transaction signatures will be verified (conflicts with
`replaceRecentBlockhash`)

##### !! minContextSlot

!type number
!optional

The minimum slot that the request can be evaluated at


##### !! innerInstructions

!type bool
!defaultValue false

If `true` the response will include
[inner instructions](/docs/rpc/json-structures#inner-instructions). These inner
instructions will be `jsonParsed` where possible, otherwise `json`.

##### !! accounts

!type object
!optional

Accounts configuration object containing the following fields:

- `addresses`: An array of accounts to return, as base-58 encoded strings
- `encoding`: Encoding for returned Account data. Note: `jsonParsed` encoding
  attempts to use program-specific state parsers to return more human-readable
  and explicit account state data. If `jsonParsed` is requested but a
  [parser cannot be found](https://github.com/solana-labs/solana/blob/cfd0a00ae2ba85a6d76757df8b4fa38ed242d185/account-decoder/src/parse_account_data.rs#L98-L100),
  the field falls back to `base64` encoding, detectable when the returned
  `accounts.data` field is type `string`.

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  "result": {
    "context": {
      "apiVersion": "2.3.3",
      "slot": 393226680
    },
    // !hover(1:18) value
    "value": {
      // !hover accounts
      "accounts": null,
      // !hover err
      "err": null,
      // !hover innerInstructions
      "innerInstructions": null,
      // !hover loadedAccountsDataSize
      "loadedAccountsDataSize": 413,
      // !hover(1:6) logs
      "logs": [
        "Program TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb invoke [1]",
        "Program log: Instruction: Transfer",
        "Program TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb consumed 1714 of 200000 compute units",
        "Program TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb success"
      ],
      // !hover(1:4) replacementBlockhash
      "replacementBlockhash": {
        "blockhash": "6oFLsE7kmgJx9PjR4R63VRNtpAVJ648gCTr3nq5Hihit",
        "lastValidBlockHeight": 381186895
      },
      // !hover returnData
      "returnData": null,
      // !hover unitsConsumed
      "unitsConsumed": 1714
    }
  },
  "id": 1
}
```

!type object

The result will contain:

##### !! accounts

!type array|null

Array of accounts with the same length as the `accounts.addresses` array in the
request. Each element is either:

- `null` - if the account doesn't exist or if `err` is not null
- An object containing:
  - `lamports: <u64>` - number of lamports assigned to this account
  - `owner: <string>` - base-58 encoded Pubkey of the program this account has
    been assigned to
  - `data: <[string, encoding]|object>` - data associated with the account,
    either as encoded binary data or JSON format `{<program>: <state>}`
  - `executable: <bool>` - boolean indicating if the account contains a program
  - `rentEpoch: <u64>` - the epoch at which this account will next owe rent

##### !! err

!type object|string|null

Error if transaction failed, null if transaction succeeded. See
[TransactionError definitions](https://github.com/solana-labs/solana/blob/c0c60386544ec9a9ec7119229f37386d9f070523/sdk/src/transaction/error.rs#L13)

##### !! innerInstructions

!type object|undefined

Defined only if `innerInstructions` was set to `true`. The value is a list of
[inner instructions](/docs/rpc/json-structures#inner-instructions).

##### !! loadedAccountsDataSize

!type u32|undefined

The number of bytes of all accounts loaded by this transaction

##### !! logs

!type array|null

Array of log messages the transaction instructions output during execution, null
if simulation failed before the transaction was able to execute

##### !! replacementBlockhash

!type object|null

The blockhash used to simulate the transaction, containing:

- `blockhash: <string>` - the blockhash used to simulate the transaction
- `lastValidBlockHeight: <u64>` - the last valid block height at which the
  blockhash is valid

##### !! returnData

!type object|null

The most-recent return data generated by an instruction in the transaction,
containing:

- `programId: <string>` - the program that generated the return data, as base-58
  encoded Pubkey
- `data: <[string, encoding]>` - the return data itself, as base-64 encoded
  binary data

##### !! unitsConsumed

!type u64|undefined

The number of compute budget units consumed during the processing of this
transaction

</APIMethod>
---
title: voteSubscribe
hideTableOfContents: true
h1: voteSubscribe RPC Method
---

Subscribe to receive notification anytime a new vote is observed in gossip.
These votes are pre-consensus therefore there is no guarantee these votes will
enter the ledger.

<Callout type="warn" title={"Unstable Method"}>
  This subscription is unstable and only available if the validator was started
  with the `--rpc-pubsub-enable-vote-subscription` flag. The format of this
  subscription may change in the future.
</Callout>

<APIMethod>

```jsonc !!request
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "voteSubscribe"
}
```

### !params

**None**

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover result
  "result": 0,
  "id": 1
}
```

!type integer

subscription id (needed to unsubscribe)

</APIMethod>

#### Notification Format:

The notification will be an object with the following fields:

- `hash: <string>` - The vote hash
- `slots: <array>` - The slots covered by the vote, as an array of u64 integers
- `timestamp: <i64|null>` - The timestamp of the vote
- `signature: <string>` - The signature of the transaction that contained this
  vote
- `votePubkey: <string>` - The public key of the vote account, as base-58
  encoded string

```json
{
  "jsonrpc": "2.0",
  "method": "voteNotification",
  "params": {
    "result": {
      "hash": "8Rshv2oMkPu5E4opXTRyuyBeZBqQ4S477VG26wUTFxUM",
      "slots": [1, 2],
      "timestamp": null
    },
    "subscription": 0
  }
}
```
---
title: voteUnsubscribe
hideTableOfContents: true
h1: voteUnsubscribe RPC Method
---

Unsubscribe from vote notifications

<APIMethod>

```jsonc !!request
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "voteUnsubscribe",
  "params": [
    // !hover 0
    0
  ]
}
```

### !params

#### !! 0

!type integer  
!required

subscription id to cancel

### !!result

```jsonc !response
{
  "jsonrpc": "2.0",
  // !hover result
  "result": true,
  "id": 1
}
```

!type boolean

unsubscribe success message

</APIMethod>