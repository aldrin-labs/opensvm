# Block Explorer Routes Steering

## Routes Covered
- `/block/[slot]` - Individual block details
- `/block/[slot]/opengraph-image` - Block social sharing images
- `/blocks` - Block list and exploration

## Block Detail Page (`/block/[slot]`)

### Purpose
Display comprehensive information about a specific Solana block including metadata, transactions, validator info, and performance metrics.

### Key Components Required
- **BlockDetails**: Main component showing block metadata
- **TransactionsInBlock**: List of all transactions in the block
- **ValidatorInfo**: Information about the block producer
- **BlockRewards**: Rewards calculation and distribution
- **BlockNavigation**: Previous/next block navigation

### Data Requirements
```typescript
interface BlockData {
  slot: number;
  blockhash: string;
  parentSlot: number;
  blockTime: number | null;
  blockHeight: number;
  transactions: Transaction[];
  rewards: Reward[];
  validator: ValidatorInfo;
  metrics: BlockMetrics;
}

interface BlockMetrics {
  transactionCount: number;
  successfulTransactions: number;
  failedTransactions: number;
  totalFees: number;
  computeUnitsConsumed: number;
  averageTransactionSize: number;
}
```

### Implementation Guidelines
- Use server-side rendering for SEO and performance
- Implement proper error handling for invalid slots
- Cache block data aggressively (blocks are immutable)
- Show loading states for transaction list
- Implement pagination for blocks with many transactions
- Add breadcrumb navigation (Home > Blocks > Block #12345)

### Performance Considerations
- Lazy load transaction details
- Implement virtual scrolling for large transaction lists
- Use React.memo for transaction list items
- Prefetch adjacent blocks for navigation

### Error Handling
- Invalid slot numbers should show 404
- Network errors should show retry mechanism
- Partial data loading should show what's available

## Block List Page (`/blocks`)

### Purpose
Browse recent blocks with real-time updates, statistics, and search functionality.

### Key Components Required
- **BlockExploreTable**: Main table showing recent blocks
- **NetworkStats**: Real-time network statistics
- **BlockFilters**: Filtering and search options
- **LoadMoreButton**: Pagination for older blocks

### Features to Implement
- Real-time block updates (WebSocket/SSE)
- Auto-refresh every 30 seconds
- Load more functionality for historical blocks
- Block statistics dashboard
- Search by slot number or blockhash
- Export functionality for block data

### Data Structure
```typescript
interface BlockListItem {
  slot: number;
  blockhash: string;
  blockTime: number;
  transactionCount: number;
  validator: string;
  fees: number;
  status: 'confirmed' | 'finalized';
}
```

### Real-time Updates
- Connect to `/api/sse-events/feed` for live block updates
- Update block list without full page refresh
- Show notification for new blocks
- Maintain scroll position during updates

## OpenGraph Images (`/block/[slot]/opengraph-image`)

### Purpose
Generate dynamic social sharing images for block pages.

### Implementation
- Use Next.js ImageResponse API
- Include key block information (slot, time, transaction count)
- Use consistent branding and styling
- Optimize for Twitter/Discord/LinkedIn sharing
- Cache generated images

### Image Content
- Block slot number prominently displayed
- Block timestamp
- Transaction count
- Validator information
- OpenSVM branding

## API Integration

### Required Endpoints
- `GET /api/block?slot={slot}` - Get specific block data
- `GET /api/blocks` - Get recent blocks list
- `GET /api/blocks/stats` - Get block statistics
- `SSE /api/sse-events/feed` - Real-time block updates

### Caching Strategy
- Block data: Cache indefinitely (immutable)
- Block list: Cache for 30 seconds
- Statistics: Cache for 10 seconds
- Use stale-while-revalidate pattern

## Testing Requirements

### Unit Tests
- Block data parsing and validation
- Component rendering with mock data
- Error state handling
- Loading state management

### Integration Tests
- Block page loads correctly with valid slot
- Invalid slots show appropriate errors
- Navigation between blocks works
- Real-time updates function properly

### E2E Tests
- Search for specific block works
- Block list pagination functions
- Social sharing generates correct images
- Mobile responsiveness

## Accessibility Requirements
- Proper heading hierarchy (h1 > h2 > h3)
- ARIA labels for interactive elements
- Keyboard navigation support
- Screen reader compatibility
- High contrast mode support

## Mobile Considerations
- Responsive table design for block list
- Touch-friendly navigation buttons
- Optimized loading for mobile networks
- Simplified view for small screens

## SEO Optimization
- Dynamic meta titles: "Block #12345 | OpenSVM"
- Meta descriptions with block summary
- Structured data for search engines
- Canonical URLs for block pages
- Sitemap inclusion for recent blocks