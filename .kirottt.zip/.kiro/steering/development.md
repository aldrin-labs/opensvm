# OpenSVM Development Patterns & Guidelines

## Code Organization Principles

### Feature-First Architecture
- Organize code by feature/domain rather than technical layer
- Keep related functionality together (components, hooks, utils, types)
- Use barrel exports for clean imports
- Co-locate tests with source code

### Naming Conventions

#### Files and Directories
```
// Components - PascalCase
TransactionTable.tsx
AccountOverview.tsx

// Utilities - camelCase
solanaUtils.ts
formatHelpers.ts

// Directories - kebab-case
transaction-graph/
wallet-path-finding/

// API Routes - kebab-case
account-stats/
token-metadata/

// Types - PascalCase with .types.ts suffix
Transaction.types.ts
Account.types.ts
```

#### Variables and Functions
```typescript
// Variables - camelCase
const accountBalance = 1000;
const isLoading = false;

// Functions - camelCase with descriptive verbs
const fetchAccountData = async () => {};
const parseTransaction = (tx) => {};
const validateSolanaAddress = (address) => {};

// Constants - SCREAMING_SNAKE_CASE
const MAX_RETRY_ATTEMPTS = 3;
const DEFAULT_RPC_TIMEOUT = 5000;

// React Components - PascalCase
const TransactionTable = () => {};
const AccountInfo = () => {};
```

## TypeScript Patterns

### Type Definitions
```typescript
// Base types for blockchain entities
interface SolanaAddress {
  readonly value: string;
  readonly isValid: boolean;
}

interface Transaction {
  signature: string;
  slot: number;
  blockTime: number | null;
  meta: TransactionMeta | null;
  transaction: ParsedTransaction;
}

interface Account {
  address: string;
  lamports: number;
  owner: string;
  executable: boolean;
  rentEpoch: number;
  data: AccountData;
}

// API Response types
interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: ApiError;
  timestamp: number;
  cached?: boolean;
}

interface PaginatedResponse<T> extends ApiResponse<T[]> {
  pagination: {
    page: number;
    limit: number;
    total: number;
    hasNext: boolean;
    hasPrev: boolean;
  };
}
```

### Generic Patterns
```typescript
// Generic data fetching hook
function useAsyncData<T>(
  fetcher: () => Promise<T>,
  deps: React.DependencyList = []
) {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<Error | null>(null);

  const fetchData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await fetcher();
      setData(result);
    } catch (err) {
      setError(err as Error);
    } finally {
      setLoading(false);
    }
  }, deps);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  return { data, loading, error, refetch: fetchData };
}

// Generic table column definition
interface TableColumn<T> {
  key: keyof T;
  header: string;
  render?: (value: T[keyof T], row: T) => React.ReactNode;
  sortable?: boolean;
  width?: string;
}
```

## React Patterns

### Component Structure
```typescript
// Standard component structure
interface ComponentProps {
  // Required props first
  data: SomeData;
  onAction: (id: string) => void;
  
  // Optional props with defaults
  loading?: boolean;
  className?: string;
  
  // Event handlers
  onClick?: (event: React.MouseEvent) => void;
  
  // Children and render props
  children?: React.ReactNode;
  renderItem?: (item: SomeData) => React.ReactNode;
}

const Component: React.FC<ComponentProps> = ({
  data,
  onAction,
  loading = false,
  className,
  onClick,
  children,
  renderItem
}) => {
  // Hooks at the top
  const [localState, setLocalState] = useState();
  const { otherData } = useCustomHook();
  
  // Event handlers
  const handleClick = useCallback((event: React.MouseEvent) => {
    onClick?.(event);
    // Additional logic
  }, [onClick]);
  
  // Effects
  useEffect(() => {
    // Side effects
  }, [data]);
  
  // Early returns for loading/error states
  if (loading) {
    return <LoadingSpinner />;
  }
  
  // Main render
  return (
    <div className={cn('component-base', className)}>
      {children}
      {/* Component content */}
    </div>
  );
};
```

### Custom Hooks Patterns
```typescript
// Data fetching hook
function useSolanaAccount(address: string) {
  return useAsyncData(
    () => fetchAccountData(address),
    [address]
  );
}

// State management hook
function useTransactionFilters() {
  const [filters, setFilters] = useState<TransactionFilters>({
    type: 'all',
    dateRange: 'week',
    minAmount: 0
  });
  
  const updateFilter = useCallback((key: keyof TransactionFilters, value: any) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  }, []);
  
  const resetFilters = useCallback(() => {
    setFilters({
      type: 'all',
      dateRange: 'week',
      minAmount: 0
    });
  }, []);
  
  return { filters, updateFilter, resetFilters };
}

// WebSocket hook
function useRealtimeData<T>(endpoint: string) {
  const [data, setData] = useState<T[]>([]);
  const [connected, setConnected] = useState(false);
  
  useEffect(() => {
    const eventSource = new EventSource(endpoint);
    
    eventSource.onopen = () => setConnected(true);
    eventSource.onmessage = (event) => {
      const newData = JSON.parse(event.data);
      setData(prev => [newData, ...prev.slice(0, 99)]); // Keep last 100
    };
    eventSource.onerror = () => setConnected(false);
    
    return () => {
      eventSource.close();
      setConnected(false);
    };
  }, [endpoint]);
  
  return { data, connected };
}
```

## Error Handling Patterns

### API Error Handling
```typescript
// Centralized error handling
class ApiError extends Error {
  constructor(
    message: string,
    public code: string,
    public status?: number,
    public details?: any
  ) {
    super(message);
    this.name = 'ApiError';
  }
}

// Error boundary for components
class ErrorBoundary extends React.Component<
  { children: React.ReactNode; fallback?: React.ComponentType<any> },
  { hasError: boolean; error?: Error }
> {
  constructor(props: any) {
    super(props);
    this.state = { hasError: false };
  }
  
  static getDerivedStateFromError(error: Error) {
    return { hasError: true, error };
  }
  
  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error('Component error:', error, errorInfo);
    // Report to error tracking service
  }
  
  render() {
    if (this.state.hasError) {
      const Fallback = this.props.fallback || DefaultErrorFallback;
      return <Fallback error={this.state.error} />;
    }
    
    return this.props.children;
  }
}

// Async error handling
const handleAsyncError = (error: unknown, context: string) => {
  const apiError = error instanceof ApiError ? error : new ApiError(
    'Unknown error occurred',
    'UNKNOWN_ERROR',
    undefined,
    error
  );
  
  console.error(`Error in ${context}:`, apiError);
  
  // Report to monitoring service
  if (typeof window !== 'undefined') {
    // Client-side error reporting
  }
  
  return apiError;
};
```

### Validation Patterns
```typescript
// Input validation with Zod
import { z } from 'zod';

const SolanaAddressSchema = z.string()
  .min(32, 'Address too short')
  .max(44, 'Address too long')
  .regex(/^[1-9A-HJ-NP-Za-km-z]+$/, 'Invalid characters in address');

const TransactionSignatureSchema = z.string()
  .length(88, 'Invalid signature length')
  .regex(/^[1-9A-HJ-NP-Za-km-z]+$/, 'Invalid characters in signature');

// Form validation
const AccountFormSchema = z.object({
  address: SolanaAddressSchema,
  label: z.string().min(1, 'Label required').max(50, 'Label too long'),
  tags: z.array(z.string()).max(10, 'Too many tags')
});

type AccountFormData = z.infer<typeof AccountFormSchema>;

// Validation hook
function useFormValidation<T>(schema: z.ZodSchema<T>) {
  const [errors, setErrors] = useState<Record<string, string>>({});
  
  const validate = useCallback((data: unknown): data is T => {
    try {
      schema.parse(data);
      setErrors({});
      return true;
    } catch (error) {
      if (error instanceof z.ZodError) {
        const fieldErrors: Record<string, string> = {};
        error.errors.forEach(err => {
          if (err.path.length > 0) {
            fieldErrors[err.path[0]] = err.message;
          }
        });
        setErrors(fieldErrors);
      }
      return false;
    }
  }, [schema]);
  
  return { errors, validate };
}
```

## Performance Optimization Patterns

### Memoization
```typescript
// Expensive calculations
const MemoizedComponent = React.memo(({ data, filters }) => {
  const processedData = useMemo(() => {
    return data
      .filter(item => matchesFilters(item, filters))
      .sort((a, b) => b.timestamp - a.timestamp);
  }, [data, filters]);
  
  const handleItemClick = useCallback((id: string) => {
    // Handle click
  }, []);
  
  return (
    <div>
      {processedData.map(item => (
        <Item key={item.id} data={item} onClick={handleItemClick} />
      ))}
    </div>
  );
});

// Custom comparison for memo
const arePropsEqual = (prevProps: Props, nextProps: Props) => {
  return (
    prevProps.data.length === nextProps.data.length &&
    prevProps.filters === nextProps.filters
  );
};

const OptimizedComponent = React.memo(Component, arePropsEqual);
```

### Virtual Scrolling
```typescript
// Virtual list for large datasets
function useVirtualList<T>({
  items,
  itemHeight,
  containerHeight,
  overscan = 5
}: {
  items: T[];
  itemHeight: number;
  containerHeight: number;
  overscan?: number;
}) {
  const [scrollTop, setScrollTop] = useState(0);
  
  const visibleRange = useMemo(() => {
    const start = Math.floor(scrollTop / itemHeight);
    const end = Math.min(
      start + Math.ceil(containerHeight / itemHeight) + overscan,
      items.length
    );
    
    return { start: Math.max(0, start - overscan), end };
  }, [scrollTop, itemHeight, containerHeight, items.length, overscan]);
  
  const visibleItems = useMemo(() => {
    return items.slice(visibleRange.start, visibleRange.end).map((item, index) => ({
      item,
      index: visibleRange.start + index
    }));
  }, [items, visibleRange]);
  
  return {
    visibleItems,
    totalHeight: items.length * itemHeight,
    offsetY: visibleRange.start * itemHeight,
    onScroll: (e: React.UIEvent<HTMLDivElement>) => {
      setScrollTop(e.currentTarget.scrollTop);
    }
  };
}
```

## Testing Patterns

### Component Testing
```typescript
// Test utilities
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { jest } from '@jest/globals';

// Mock providers
const TestProviders: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <SolanaProvider>
    <ThemeProvider>
      {children}
    </ThemeProvider>
  </SolanaProvider>
);

// Component test
describe('TransactionTable', () => {
  const mockTransactions = [
    {
      signature: 'test-signature-1',
      slot: 12345,
      blockTime: Date.now(),
      // ... other properties
    }
  ];
  
  it('renders transaction list', async () => {
    render(
      <TransactionTable transactions={mockTransactions} />,
      { wrapper: TestProviders }
    );
    
    expect(screen.getByText('test-signature-1')).toBeInTheDocument();
  });
  
  it('handles loading state', () => {
    render(
      <TransactionTable transactions={[]} loading={true} />,
      { wrapper: TestProviders }
    );
    
    expect(screen.getByTestId('loading-spinner')).toBeInTheDocument();
  });
  
  it('calls onTransactionClick when row is clicked', async () => {
    const onTransactionClick = jest.fn();
    
    render(
      <TransactionTable 
        transactions={mockTransactions} 
        onTransactionClick={onTransactionClick}
      />,
      { wrapper: TestProviders }
    );
    
    fireEvent.click(screen.getByText('test-signature-1'));
    
    await waitFor(() => {
      expect(onTransactionClick).toHaveBeenCalledWith('test-signature-1');
    });
  });
});
```

### API Testing
```typescript
// API route testing
import { createMocks } from 'node-mocks-http';
import handler from '@/app/api/account-stats/[address]/route';

describe('/api/account-stats/[address]', () => {
  it('returns account statistics', async () => {
    const { req, res } = createMocks({
      method: 'GET',
      query: { address: 'test-address' }
    });
    
    await handler(req, res);
    
    expect(res._getStatusCode()).toBe(200);
    
    const data = JSON.parse(res._getData());
    expect(data.success).toBe(true);
    expect(data.data).toHaveProperty('balance');
    expect(data.data).toHaveProperty('transactionCount');
  });
  
  it('handles invalid address', async () => {
    const { req, res } = createMocks({
      method: 'GET',
      query: { address: 'invalid' }
    });
    
    await handler(req, res);
    
    expect(res._getStatusCode()).toBe(400);
    
    const data = JSON.parse(res._getData());
    expect(data.success).toBe(false);
    expect(data.error.code).toBe('INVALID_ADDRESS');
  });
});
```

## Security Patterns

### Input Sanitization
```typescript
// Address validation
function validateSolanaAddress(address: string): string {
  const cleaned = address.trim();
  
  if (!cleaned) {
    throw new Error('Address cannot be empty');
  }
  
  if (!/^[1-9A-HJ-NP-Za-km-z]+$/.test(cleaned)) {
    throw new Error('Invalid characters in address');
  }
  
  if (cleaned.length < 32 || cleaned.length > 44) {
    throw new Error('Invalid address length');
  }
  
  return cleaned;
}

// SQL injection prevention (if using raw queries)
function sanitizeQuery(query: string): string {
  return query.replace(/['"\\]/g, '\\$&');
}

// XSS prevention
function sanitizeHtml(html: string): string {
  return html
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;');
}
```

### Rate Limiting
```typescript
// Simple rate limiter
class RateLimiter {
  private requests = new Map<string, number[]>();
  
  constructor(
    private maxRequests: number,
    private windowMs: number
  ) {}
  
  isAllowed(identifier: string): boolean {
    const now = Date.now();
    const windowStart = now - this.windowMs;
    
    const userRequests = this.requests.get(identifier) || [];
    const validRequests = userRequests.filter(time => time > windowStart);
    
    if (validRequests.length >= this.maxRequests) {
      return false;
    }
    
    validRequests.push(now);
    this.requests.set(identifier, validRequests);
    
    return true;
  }
}

// Usage in API routes
const rateLimiter = new RateLimiter(100, 60000); // 100 requests per minute

export async function GET(request: Request) {
  const ip = request.headers.get('x-forwarded-for') || 'unknown';
  
  if (!rateLimiter.isAllowed(ip)) {
    return Response.json(
      { success: false, error: { code: 'RATE_LIMIT_EXCEEDED' } },
      { status: 429 }
    );
  }
  
  // Handle request
}
```