# OpenSVM Product Overview

OpenSVM is a comprehensive blockchain explorer for the Solana ecosystem that provides detailed insights into transactions, blocks, accounts, programs, and tokens on the Solana blockchain.

## Core Features

- **Blockchain Data Browsing**: Explore blocks, transactions, accounts, programs, and tokens
- **Transaction Visualization**: Interactive visualizations of transaction flows and relationships using D3.js, Cytoscape, and Three.js
- **Wallet Path Finding**: Discover connections between wallets through token transfers
- **AI Assistant**: Natural language explanations of blockchain data and transactions with anomaly detection
- **Network Statistics**: Monitor Solana network performance and health metrics
- **Token Analytics**: Track token transfers, balances, and activities
- **Real-time Event Streaming**: Live monitoring with AI-powered anomaly detection

## Target Users

- Blockchain developers and researchers
- Solana ecosystem participants
- Security analysts and auditors
- DeFi users and traders
- General blockchain enthusiasts

## Key Value Propositions

- Modern, user-friendly interface for exploring Solana blockchain
- AI-powered analysis and explanations of complex blockchain data
- Advanced visualization capabilities for understanding transaction flows
- Real-time monitoring and security alerts
- Comprehensive data coverage across the Solana ecosystem

## Page-Specific Features

### Homepage (`/`)
- **Hero Section**: Main branding and search interface
- **Network Statistics**: Real-time Solana network metrics (TPS, validators, epoch progress)
- **Search Bar**: Universal search with auto-suggestions for transactions, blocks, accounts, tokens
- **Recent Blocks**: Live feed of latest blocks with transaction counts
- **Network Performance Chart**: Visual representation of network health over time
- **AI Assistant Button**: Fixed floating button to access AI chat

### Account Explorer (`/account/[address]`)
- **Account Information**: Basic account details, owner, balance
- **Token Holdings**: List of all SPL tokens held by the account
- **Transaction History**: Paginated list of account transactions
- **Transaction Graph**: Visual representation of account's transaction relationships
- **Account Analytics**: Statistics and insights about account activity
- **Sidebar Ads**: Monetization through relevant service advertisements

### Transaction Explorer (`/tx/[signature]`)
- **Transaction Details**: Complete transaction information and metadata
- **Instruction Breakdown**: Detailed analysis of each transaction instruction
- **Account Changes**: Before/after state changes for all affected accounts
- **Transaction Graph**: Visual flow of the transaction
- **AI Analysis**: Natural language explanation of transaction purpose
- **Related Transactions**: Connections to other related transactions

### Block Explorer (`/block/[slot]`)
- **Block Information**: Block metadata, timestamp, parent hash
- **Transaction List**: All transactions included in the block
- **Block Statistics**: Performance metrics and validation info
- **Validator Information**: Details about the block producer
- **Block Rewards**: Rewards distributed for this block

### Token Explorer (`/token/[mint]`)
- **Token Metadata**: Name, symbol, decimals, supply information
- **Token Statistics**: Holder count, transfer volume, price data
- **Holder Distribution**: Top holders and distribution analysis
- **Transfer History**: Recent token transfers and activity
- **Token Analytics**: Charts showing token metrics over time

### Program Explorer (`/program/[address]`)
- **Program Information**: Program metadata and deployment details
- **Program Instructions**: Available instructions and their usage
- **Program Accounts**: Accounts owned by the program
- **Usage Statistics**: Transaction volume and interaction metrics
- **Code Analysis**: Disassembly and hex view of program bytecode

### Analytics Dashboard (`/analytics`)
- **Network Overview**: High-level Solana network statistics
- **DeFi Analytics**: DeFi protocol metrics and TVL data
- **Token Analytics**: Token market data and trends
- **Validator Analytics**: Validator performance and staking data

### AI Chat Interface (`/chat`)
- **Conversational AI**: Natural language blockchain queries
- **Context Awareness**: AI understands current page context
- **Data Analysis**: AI can analyze and explain blockchain data
- **Anomaly Detection**: AI identifies suspicious patterns
- **Educational Mode**: AI explains blockchain concepts

### Monitoring Dashboard (`/monitoring`)
- **Real-time Alerts**: Live monitoring of network events
- **Anomaly Detection**: AI-powered suspicious activity detection
- **Performance Metrics**: Network health and performance tracking
- **Alert Management**: Configure and manage custom alerts

### Wallet Path Finding (`/wallet-path-finding`)
- **Connection Analysis**: Find relationships between wallet addresses
- **Transaction Paths**: Trace token flows between wallets
- **Network Visualization**: Graph view of wallet connections
- **Path Analytics**: Statistics about connection strength and frequency

### Search Results (`/search`)
- **Universal Search**: Search across all blockchain entities
- **Filtered Results**: Separate results by type (accounts, transactions, tokens, etc.)
- **Search Suggestions**: Auto-complete and suggested searches
- **Advanced Filters**: Filter results by date, amount, type, etc.

### NFT Explorer (`/nfts`)
- **NFT Collections**: Browse and explore NFT collections
- **Trending NFTs**: Popular and trending NFT collections
- **New Collections**: Recently launched NFT projects
- **NFT Analytics**: Floor prices, volume, and market data

### DeFi Analytics (`/defi`)
- **Protocol Analytics**: DeFi protocol performance and metrics
- **TVL Tracking**: Total Value Locked across protocols
- **Yield Farming**: APY and farming opportunity analysis
- **Liquidity Analysis**: Pool liquidity and trading volume

### Network Information (`/networks`)
- **Network Comparison**: Compare different Solana networks (mainnet, devnet, testnet)
- **Network Statistics**: Performance metrics for each network
- **RPC Endpoints**: Available RPC endpoints and their status
- **Network Health**: Real-time network status and alerts