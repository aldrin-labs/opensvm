# Program Explorer Routes Steering

## Routes Covered
- `/program/[address]` - Individual program details
- `/program/[address]/opengraph-image` - Program social sharing images
- `/programs` - Program list and activity metrics

## Program Detail Page (`/program/[address]`)

### Purpose
Comprehensive program analysis including metadata, instruction usage, account ownership, code visualization, and security analysis.

### Key Components Required
- **ProgramDetails**: Main program information display
- **ProgramVisualizer**: Code disassembly and hex view
- **InstructionAnalytics**: Instruction usage statistics
- **AccountOwnership**: Accounts owned by the program
- **ProgramInteractions**: Transaction history and patterns
- **SecurityAnalysis**: Audit information and risk assessment
- **ProgramMetrics**: Performance and usage metrics

### Data Requirements
```typescript
interface ProgramData {
  address: string;
  metadata: ProgramMetadata;
  code: ProgramCode;
  instructions: InstructionData[];
  accounts: OwnedAccount[];
  interactions: ProgramInteraction[];
  security: SecurityAnalysis;
  metrics: ProgramMetrics;
}

interface ProgramMetadata {
  name?: string;
  description?: string;
  version?: string;
  author?: string;
  repository?: string;
  documentation?: string;
  verified: boolean;
  deployedAt: number;
  lastUpdated: number;
  upgradeAuthority?: string;
}

interface ProgramCode {
  size: number;
  hash: string;
  disassembly: DisassemblyInstruction[];
  hexDump: string;
  entryPoints: EntryPoint[];
  dependencies: string[];
}

interface InstructionData {
  discriminator: string;
  name: string;
  usage: InstructionUsage;
  parameters: InstructionParameter[];
  accounts: AccountRequirement[];
}

interface InstructionUsage {
  totalCalls: number;
  uniqueCallers: number;
  averageComputeUnits: number;
  successRate: number;
  last24h: number;
  trend: 'increasing' | 'decreasing' | 'stable';
}

interface OwnedAccount {
  address: string;
  type: 'data' | 'executable' | 'system';
  size: number;
  lamports: number;
  lastModified: number;
  dataHash?: string;
}

interface SecurityAnalysis {
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
  vulnerabilities: Vulnerability[];
  auditReports: AuditReport[];
  upgradeability: UpgradeabilityInfo;
  permissions: Permission[];
}
```

### Implementation Guidelines
- Use server-side rendering for program metadata
- Implement code syntax highlighting for disassembly
- Show progressive loading for different data sections
- Cache program code and metadata (rarely changes)
- Implement search within disassembly code
- Add copy-to-clipboard for addresses and code

### Code Visualization Features
- Hex dump view with address offsets
- Disassembly with instruction highlighting
- Control flow graph visualization
- Jump target highlighting
- Search and navigation within code
- Export functionality for code analysis

### Instruction Analytics
- Usage statistics over time
- Performance metrics per instruction
- Error rate analysis
- Caller distribution
- Compute unit consumption
- Gas optimization suggestions

## Program List Page (`/programs`)

### Purpose
Browse all programs with activity metrics, filtering, and real-time statistics.

### Key Components Required
- **ProgramActivityTable**: Main table with program metrics
- **TopPrograms**: Most active programs section
- **ProgramFilters**: Filtering and search controls
- **NetworkProgramStats**: Overall program statistics
- **ProgramCategories**: Programs grouped by type/category

### Features to Implement
- Real-time activity updates
- Program search by address or name
- Filtering by program type and activity
- Sorting by various metrics
- Program verification status
- Export functionality for program data

### Table Columns
- Program address with name (if available)
- Program type and category
- Total transactions and 24h activity
- Unique users and growth metrics
- Compute units consumed
- Success rate and reliability
- Last activity timestamp
- Verification status

### Program Categories
```typescript
interface ProgramCategory {
  name: string;
  description: string;
  programs: string[];
  totalActivity: number;
  examples: ProgramExample[];
}

const PROGRAM_CATEGORIES = [
  'DeFi Protocols',
  'NFT Marketplaces',
  'Gaming',
  'Social',
  'Infrastructure',
  'Oracles',
  'Bridges',
  'Governance',
  'Utilities',
  'Unknown'
];
```

## OpenGraph Images (`/program/[address]/opengraph-image`)

### Purpose
Generate dynamic social sharing images for program pages.

### Implementation Guidelines
- Include program name or address prominently
- Show program type and category
- Display key metrics (transactions, users)
- Include verification status indicator
- Show activity trend visualization
- Use consistent OpenSVM branding

### Image Content
```typescript
interface ProgramOGData {
  address: string;
  name?: string;
  type: string;
  category: string;
  totalTransactions: number;
  uniqueUsers: number;
  verified: boolean;
  activityTrend: 'up' | 'down' | 'stable';
}
```

## API Integration

### Required Endpoints
- `GET /api/program/[address]` - Get comprehensive program data
- `GET /api/program/[address]/code` - Get program code and disassembly
- `GET /api/program/[address]/instructions` - Get instruction analytics
- `GET /api/program/[address]/accounts` - Get owned accounts
- `GET /api/program/[address]/interactions` - Get interaction history
- `GET /api/programs` - Get program list with metrics
- `GET /api/program-discovery` - Discover new programs
- `GET /api/program-registry` - Get program registry data

### Code Analysis
- Disassemble program bytecode
- Generate control flow graphs
- Identify instruction patterns
- Extract metadata from code
- Perform security analysis

### Caching Strategy
- Program metadata: Cache for 1 hour
- Program code: Cache for 24 hours (immutable unless upgraded)
- Instruction analytics: Cache for 5 minutes
- Account data: Cache for 1 minute
- Interaction history: Cache for 30 seconds

## Testing Requirements

### Unit Tests
- Program address validation
- Code disassembly accuracy
- Instruction parsing correctness
- Security analysis algorithms
- Metrics calculation accuracy

### Integration Tests
- Program page loads with valid address
- Invalid addresses show appropriate errors
- Code visualization renders correctly
- Instruction analytics display properly
- Account ownership is accurate

### E2E Tests
- Program search and navigation
- Code viewer functionality
- Instruction analytics interactions
- Account list navigation
- Security analysis display

## Performance Considerations
- Lazy load heavy components (code viewer, analytics)
- Implement virtual scrolling for large instruction lists
- Use Web Workers for code analysis
- Cache disassembly results
- Optimize bundle size for code highlighting

## Security Considerations
- Validate program addresses before processing
- Sanitize code display to prevent XSS
- Rate limit code analysis requests
- Secure handling of program bytecode
- Prevent code injection in disassembly

## Code Analysis Features

### Disassembly Viewer
```typescript
interface DisassemblyViewer {
  // Core functionality
  displayHexDump: boolean;
  displayAssembly: boolean;
  displayControlFlow: boolean;
  
  // Navigation
  jumpToAddress: (address: string) => void;
  searchInCode: (query: string) => void;
  highlightInstruction: (offset: number) => void;
  
  // Analysis
  findReferences: (address: string) => Reference[];
  analyzeFunction: (entryPoint: string) => FunctionAnalysis;
  detectPatterns: () => CodePattern[];
}

interface FunctionAnalysis {
  entryPoint: string;
  size: number;
  instructions: number;
  complexity: number;
  calls: string[];
  jumps: string[];
  dataReferences: string[];
}
```

### Security Analysis
```typescript
interface SecurityAnalyzer {
  // Vulnerability detection
  detectBufferOverflows: () => Vulnerability[];
  detectIntegerOverflows: () => Vulnerability[];
  detectReentrancy: () => Vulnerability[];
  detectUnauthorizedAccess: () => Vulnerability[];
  
  // Code quality
  analyzeCodeQuality: () => QualityReport;
  checkBestPractices: () => BestPracticeReport;
  auditPermissions: () => PermissionAudit;
}

interface Vulnerability {
  type: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  location: CodeLocation;
  description: string;
  recommendation: string;
  cwe?: string; // Common Weakness Enumeration
}
```

## Accessibility Requirements
- Keyboard navigation for code viewer
- Screen reader support for program metrics
- High contrast mode for code highlighting
- Alternative text for visualizations
- Focus management in modal dialogs

## Mobile Optimization
- Responsive code viewer design
- Touch-friendly navigation controls
- Optimized loading for mobile networks
- Simplified view for small screens
- Horizontal scrolling for code

## SEO Optimization
- Dynamic meta titles with program name
- Rich meta descriptions with program summary
- Structured data for program information
- Canonical URLs for program pages
- Sitemap inclusion for verified programs

## Monitoring and Analytics
- Track program page views and engagement
- Monitor code analysis performance
- Measure user interactions with features
- Track error rates and API failures
- Monitor security analysis accuracy